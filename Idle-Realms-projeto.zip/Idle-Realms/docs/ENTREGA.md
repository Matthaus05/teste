# Idle Realms · entrega 0.1

Esta versão inicia o desenvolvimento da [especificação principal](ESPECIFICACAO.md). O repositório de origem tinha somente um README: não havia motor, jogo anterior, save legado de produção ou personagens a reaproveitar. A entrega estabelece uma versão jogável e uma base modular; o escopo completo do documento permanece em desenvolvimento.

## Implementado

| Área | Comportamento disponível |
| --- | --- |
| Personagens | Guerreiro, Cavaleiro, Mago, Arqueiro, Ladino e Monge; diferenças de silhueta, acessórios, armas, alcance, velocidade e atributos. Criador com nome, três tons de pele e três cores de cabelo. |
| Arte | Pixel art original desenhada por código, com poses articuladas rasterizadas em spritesheets e cache. Quatro direções, oito estados e oito quadros por estado/direção. Árvores, construções, água, ruínas, cristais e criaturas desenhados pelo renderizador. |
| Movimento | Aceleração, desaceleração, diagonal normalizada, caminhada, corrida, animação ligada à distância, colisão com subpassos, busca de rotas A* e câmera de acompanhamento. NPCs percorrem rotas locais. |
| Equipamentos | Dois espaços equipáveis: arma e conjunto de armadura. Três tiers por espaço e classe; troca imediata durante as animações, com efeitos reais em ataque, defesa e vida. Compra com ouro na interface da forja; posse e seleção persistidas. |
| Mundo | Cinco regiões com mapas e obstáculos próprios, portais, NPCs, interações, minimapa e acesso por nível. |
| Combate | Ataques básicos e especiais automáticos, flechas e projéteis mágicos com tempo de viagem, linha de visão, alcance, aquisição de alvo, cooldown, energia, crítico, defesa, esquiva e bloqueio de Cavaleiro. Números de dano, reação dos monstros, efeitos de impacto, regeneração e poções com limite de autocura configurável. |
| Progressão | Experiência, níveis, aumento de atributos, ouro, materiais, quatro missões com recompensas únicas e baús com estado persistente. |
| Masmorra | Expedição finita na Cripta dos Goblins: guardas sem respawn durante a expedição, chefe liberado após derrotá-los e recompensa ao vencer. Inimigos já derrotados são salvos para retomar a expedição após recarregar. Uma nova entrada manual inicia outra expedição. |
| Derrota | Animação de morte e resgate na vila, com custo de 5% do ouro. |
| Persistência | Save local versão 2, migração do formato versão 1 criado pelo projeto, backup válido anterior, tratamento de dados corrompidos, exportação/importação e salvamento automático. Não existe migração de saves de versões externas não fornecidas. |
| Idle | Caça com navegação e cálculo agregado de ausência, limitado a oito horas. Recompensas offline somente com caça ativa nos campos, floresta ou região sombria; não concedem mortes de missão, baús ou conclusão de masmorra. |
| Interface | Menus recolhíveis, painel de personagem, diário, atlas, equipamentos, configurações, controles de toque e joystick. Sons simples de combate opcionais. |
| PWA | Manifest, ícone, Service Worker e cache dos recursos essenciais. O save fica separado do cache. Instalação depende de hospedagem segura e suporte do navegador; não há publicação de produção nesta entrega. |

As cinco regiões são Vila de Avelora (nível 1), Campos Dourados (1), Floresta Sussurrante (3), Cripta dos Goblins (5) e Terras do Eclipse (8).

## Arte e animação: alcance desta passagem

A arte é uma primeira passagem original e funcional, ainda sujeita a direção artística, revisão visual e polimento. Não equivale à produção artística final solicitada. As classes têm desenhos e poses específicos; a troca de equipamento altera peças e armas, além da paleta.

Os estados das spritesheets são `idle`, `walk`, `run`, `attack`, `cast`, `hurt`, `death` e `dodge`, em frente, costas, esquerda e direita. Há suporte gráfico para esses oito estados; isso não significa que todos possuam uma ação independente acionável pelo jogador. A esquiva de combate, por exemplo, é uma resolução probabilística. O conjunto ainda não cobre a lista integral solicitada de três ataques, combo, special separado, block e interação de cada classe.

O runtime compõe camadas e rasteriza os quadros no navegador. Os PNGs em [public/art](../public/art/) são exportações das mesmas rotinas usadas no jogo: seis classes × três conjuntos, com [metadados](../public/art/sprite-meta.json) e [atlas](../public/art/character-atlas.png). As opções de aparência e as combinações de arma/armadura são geradas pelo mesmo sistema. Não foram empregados sprites de terceiros.

## Estrutura e execução

- `src/art/sprites.js`: desenho articulado, camadas, animações, monstros e ícones.
- `src/world.js`: definições dos mapas, terreno, objetos, colisões e navegação.
- `src/progression.js`: classes, atributos, equipamentos, missões, offline e persistência.
- `src/main.js`: loop de jogo, câmera, entidades, combate, controles e interface.
- `public/`: recursos públicos e PWA.
- `tools/serve.mjs`: servidor estático de desenvolvimento, sem dependências de aplicação.
- `tests/`: testes de progressão e geometria/navegação.

Use Node.js 22.8+ e os comandos do [README](../README.md). A escolha de Canvas 2D com módulos ES mantém o jogo sem dependências externas e permite controlar diretamente poses, colisão e composição visual. O motor não depende de imagens de cenário estáticas. Não é necessário executar uma compilação para desenvolver.

## Validação e evidências

| Comando | O que verifica |
| --- | --- |
| `npm run check` | Sintaxe dos módulos centrais, servidor e Service Worker. |
| `npm test` | Atributos das seis classes, níveis, compra/equipamento, missões, save, migração, corrupção, offline e geometria/rotas dos mapas. |
| `npm run test:browser` | Fluxo em Chromium real, renderização, interface e verificações funcionais definidas em `tools/browser-smoke.mjs`. Requer servidor ativo e Chromium instalado. |

A validação final passou: `npm run check`, **23 testes de lógica e navegação** (15 de progressão/persistência e 8 de mapas) e `npm run test:browser` no Chromium real, sem exceções JavaScript.

A regressão de navegador verificou as seis classes iniciando no nível 1 e obtendo mortes/recompensas em auto-caça; diagonal normalizada, colisão, desaceleração e joystick de toque; três armas e três armaduras, compras e retomada de aparência/posição; pausa sem ações de cura/interação; morte por golpe inimigo, animação e resgate com custo de 5%; retomada de uma cripta parcialmente concluída, derrota do chefe e entrega da recompensa; criador/inventário mobile sem rolagem horizontal; e recarga do aplicativo com a rede desativada, usando o Service Worker. Os testes de compra e conteúdo de nível avançado usam fundos/níveis injetados como fixtures explícitas. Isso não equivale a medir o balanceamento de uma campanha inteira. Resultados detalhados: [regressão](../artifacts/regression-report.json) e [smoke](../artifacts/browser-report.json).

As instruções reutilizáveis de inicialização foram salvas no campo `start_skill` do rascunho do ambiente. Nenhum `install_script` foi necessário: a aplicação não tem dependências externas a instalar, e Node está disponível no ambiente preparado. O servidor foi iniciado e as respostas HTTP do HTML, módulo principal, manifest e Service Worker foram verificadas. O acesso de leitura ao GitHub com a autenticação fornecida também foi confirmado. Salvar o rascunho não publica o ambiente: a revisão, o salvamento nas configurações e a publicação pelo usuário ainda são etapas separadas. Não foi validada a restauração em uma nova tarefa.

Estas imagens foram capturadas no navegador executando o jogo, e não são imagens conceituais:

- [Gameplay desktop](../artifacts/gameplay-desktop.png)
- [Gameplay mobile](../artifacts/gameplay-mobile.png)
- [Criador de personagem](../artifacts/character-creator.png)
- [Combate no mapa](../artifacts/combat-desktop.png)
- [Criador no celular](../artifacts/character-creator-mobile.png)
- [Inventário no celular](../artifacts/inventory-mobile.png)
- [Relatório automatizado do navegador](../artifacts/browser-report.json)

A [galeria de equipamentos](../artifacts/equipment-gallery.png) é um atlas rasterizado do renderizador, separado das capturas de gameplay. As capturas registram momentos específicos; não demonstram sozinhas todos os requisitos. O relatório de navegador corresponde à execução que o gerou. Os testes não constituem uma certificação de todos os aparelhos, navegadores, animações ou caminhos previstos na especificação.

## Provisório e pendente

- **Arte final e repertório de animações:** revisar desenho, proporção, leitura e fluidez; ampliar as oito animações atuais para o repertório completo solicitado, com ataques e rotinas profissionais próprias para NPCs e chefes.
- **Personalização:** acrescentar penteados, rostos e roupas iniciais independentes. Hoje o criador oferece nome, classe, tom de pele e cor de cabelo.
- **Equipamentos:** implementar os demais espaços e as 14 camadas independentes, categorias completas, requisitos, efeitos especiais, comparação expandida, venda, organização e raridades adicionais. Os dois espaços atuais representam arma e armadura como conjunto.
- **Classes e habilidades:** as rotas de evolução existem apenas como definições em `EVOLUTION_ROUTES`. Evoluções não são jogáveis; árvores, builds, modificadores, invocações, nove círculos de magia e cerca de 38 caminhos secretos ainda não foram desenvolvidos. Os especiais atuais incluem projétil fortalecido de Mago/Arqueiro, golpes de área com raio e multiplicador diferentes nas classes corpo a corpo e recuperação de vida do Cavaleiro; ainda não formam árvores ou builds completas.
- **Recursos e combate avançado:** ampliar as mecânicas além dos perfis básicos, com tipos de resistência, veneno, maldição, controle, combos e recursos de classe com regras próprias. Mana/Aura/Fúria têm identidade nominal nesta passagem, mas compartilham a regra de energia.
- **Itens e craft:** materiais são coletados e salvos; receitas e fabricação por materiais não existem. A forja atual vende os conjuntos por ouro. Não há loot aleatório de equipamentos com afixos.
- **Masmorras e mundo:** ampliar o ciclo atual com portas, armadilhas funcionais, salas especiais, padrões exclusivos de chefe, objetivos variados, mais missões e regiões futuras. Elementos decorativos não contam como essas mecânicas.
- **Online:** contas, autenticação, sincronização em nuvem, rankings, eventos e validação de recompensas no servidor não foram implementados. O jogo atual é solo e local.
- **PWA e desempenho:** validar instalação em dispositivos reais, atualização entre publicações, acessibilidade e desempenho em celulares intermediários. Os testes de viewport mobile não substituem esses testes de hardware.

A prioridade seguinte continua a especificação: revisar os seis personagens em movimento e combate, completar animações e peças independentes, e só então ampliar as rotas de progressão e o conteúdo.
