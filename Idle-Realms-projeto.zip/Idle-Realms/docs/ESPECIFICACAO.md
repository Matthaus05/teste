# IDLE REALMS — PROMPT MESTRE DEFINITIVO DE DESENVOLVIMENTO

## MISSÃO PRINCIPAL

Você será responsável pelo desenvolvimento completo do meu jogo **Idle Realms**, um RPG Idle de fantasia medieval em pixel art, jogável em navegadores de computador e celular.

**QUERO QUE VOCÊ DESENVOLVA O JOGO DE VERDADE. NÃO QUERO APENAS UM PLANO, UMA EXPLICAÇÃO, UM PROTÓTIPO VISUAL OU UMA LISTA DE RECOMENDAÇÕES.**

Você deve analisar o código existente, corrigir seus problemas, substituir os sistemas inadequados e implementar diretamente os recursos especificados neste documento.

Se a arquitetura atual impedir que o jogo alcance a qualidade desejada, você tem autorização para reconstruí-la, preservando os dados, sistemas e funcionalidades que forem aproveitáveis.

O objetivo é transformar Idle Realms em um RPG 2D com identidade visual profissional, personagens bonitos, animações fluidas, equipamentos visíveis, exploração real e combate automático satisfatório.

O projeto já passou por várias versões insatisfatórias. Não reutilize soluções rejeitadas apenas para acelerar o desenvolvimento.

---

# 1. CONCEITO GERAL DO JOGO

**Nome:** Idle Realms

**Gênero:** RPG Idle, fantasia medieval, aventura, exploração, progressão de personagem.

**Perspectiva:** Top-down em 3/4, com profundidade visual e mapas exploráveis.

**Plataformas:** Navegadores desktop e mobile, com suporte a PWA.

**Direção artística:** Pixel art medieval fantasy híbrida, passando de fantasia clássica para dark fantasy conforme a progressão.

**Combate:** Totalmente automático.

**Movimentação:** Manual e exploração automática opcional.

**Progressão:** Classes, evoluções, equipamentos, atributos, habilidades, monstros, chefes, missões e masmorras.

**Offline:** Salvamento local e progresso calculado durante a ausência do jogador.

**Online futuro:** Conta, sincronização, rankings, eventos e persistência em nuvem.

## Experiência desejada

O jogador começa como um aventureiro relativamente simples, explora um mundo vivo, derrota monstros automaticamente, consegue equipamentos melhores, desbloqueia poderes, evolui sua classe e descobre regiões cada vez mais perigosas.

A aparência do personagem deve acompanhar sua progressão.

Um Guerreiro inicial e um Espadachim Supremo precisam ter diferenças visuais significativas.

O mundo deve transmitir uma sensação de aventura contínua, sem separar artificialmente a exploração e o combate em telas desconectadas.

---

# 2. PRINCIPAIS PROBLEMAS QUE VOCÊ DEVE CORRIGIR

As versões anteriores apresentaram problemas que não podem continuar.

### Problemas artísticos

- Personagens muito simples e pouco atraentes.
- Mesma aparência corporal reutilizada em todas as classes.
- Mudança de classe alterando basicamente a cor da roupa.
- Armaduras sem detalhes.
- Armas mal desenhadas.
- Sprites com proporções inconsistentes.
- Personagens sem identidade visual.
- Cenários que parecem blocos geométricos.
- Artes de estilos diferentes misturadas.
- Animações falsas criadas movendo uma única imagem.

### Problemas de movimentação

- Personagens andando rigidamente.
- NPCs com aparência de bonecos duros.
- Personagens flutuando.
- Pés desalinhados.
- Animações de caminhada sem movimento convincente das pernas.
- Deslizamento pelo chão.
- Ataques desconectados do corpo.
- Câmera tremendo.
- Movimentação travada.
- Mudanças bruscas de direção.
- Animações interrompidas incorretamente.

### Problemas de jogabilidade

- Personagens atravessando obstáculos.
- Caça automática presa em paredes.
- Monstros aparecendo em locais inacessíveis.
- Ataques sem impacto visual.
- Equipamentos que não mudam a aparência do personagem.
- Classes com pouca diferenciação.
- Interface ocupando espaço excessivo.
- Regiões sombrias que são apenas regiões normais com filtros de cor.
- Problemas de salvamento, cooldown e retomada de partida.

**Identifique as causas desses problemas e corrija a implementação, não apenas seus sintomas.**

---

# 3. DIREÇÃO ARTÍSTICA DEFINITIVA

Quero pixel art detalhada, bonita e consistente.

Use uma direção semelhante à qualidade das referências visuais fornecidas, respeitando uma identidade artística própria e os direitos de uso dos recursos.

## Personagens

- Proporções harmoniosas.
- Silhuetas bem definidas.
- Rosto e cabelo legíveis.
- Equipamentos detalhados.
- Armas realmente reconhecíveis.
- Cores bem equilibradas.
- Sombras e iluminação consistentes.
- Animações corporais naturais.
- Boa leitura em tamanho pequeno.

## Ambiente

- Vegetação rica.
- Árvores com volume.
- Construções medievais detalhadas.
- Estradas com texturas.
- Pedras, flores e objetos decorativos.
- Água animada.
- Tochas e iluminação.
- Sombras de contato.
- Diferentes camadas de profundidade.
- Efeitos atmosféricos discretos.

## Duas atmosferas principais

### Fantasia medieval clássica

Usada no início do jogo:

- Vilas.
- Campos.
- Florestas verdes.
- Fazendas.
- Estradas.
- Mercados.
- Castelos.
- Guildas.
- Ambientes acolhedores.

### Dark fantasy

Usada nas regiões avançadas:

- Florestas corrompidas.
- Cemitérios.
- Catacumbas.
- Castelos abandonados.
- Terrenos amaldiçoados.
- Cavernas.
- Cristais misteriosos.
- Portais sombrios.
- Criaturas sobrenaturais.
- Névoa e iluminação dramática.

Cada região deve possuir elementos gráficos próprios, não apenas uma alteração de tonalidade.

---

# 4. RECONSTRUÇÃO COMPLETA DOS PERSONAGENS

Existem seis classes iniciais obrigatórias:

1. Guerreiro.
2. Cavaleiro.
3. Mago.
4. Arqueiro.
5. Ladino.
6. Monge.

Cada uma deve possuir seu próprio design, sua própria silhueta, equipamentos característicos e animações adequadas ao estilo de combate.

## Guerreiro

Visual de combatente experiente.

- Armadura média de metal.
- Espada claramente visível.
- Luvas de combate.
- Botas reforçadas.
- Ombreiras.
- Postura ofensiva.
- Movimentos de espada fortes e precisos.

Suas animações devem transmitir força física, peso e domínio de técnicas de combate.

## Cavaleiro

Visual de combatente fortemente protegido.

- Armadura pesada.
- Elmo detalhado.
- Espada e escudo.
- Capa opcional.
- Placas metálicas.
- Postura defensiva e imponente.

Suas animações devem transmitir o peso da armadura, mas sem parecer lentas ou travadas.

## Mago

Visual arcano, elegante e poderoso.

- Manto detalhado.
- Cajado, grimório ou orbe.
- Símbolos mágicos.
- Acessórios arcanos.
- Efeitos energéticos discretos.

O Mago deve possuir animações próprias de conjuração e também poder evoluir para combate corpo a corpo mágico.

## Arqueiro

Visual de caçador ágil.

- Arco visível.
- Aljava.
- Vestimentas leves.
- Botas de exploração.
- Capa ou capuz opcional.

As animações devem mostrar preparação do disparo, tensionamento da corda, lançamento da flecha e recuperação.

## Ladino

Visual furtivo e perigoso.

- Capuz ou máscara.
- Adagas.
- Armadura leve.
- Botas silenciosas.
- Acessórios de assassino.

Deve possuir movimentos rápidos, esquivas, ataques curtos e combos ágeis.

## Monge

Visual de artista marcial que utiliza Aura.

- Vestimentas próprias.
- Faixas nos braços.
- Luvas ou manoplas.
- Punhos como armas principais.
- Postura de combate corporal.
- Energia espiritual.

Deve possuir socos, chutes, combos, movimentos marciais e habilidades de Aura.

**Não utilize uma única base de personagem com simples alterações de cor.**

---

# 5. SPRITESHEETS COMPLETAS

Cada classe deve possuir spritesheets próprias e realmente animadas.

## Animações obrigatórias

- Idle.
- Walk.
- Run.
- Attack 1.
- Attack 2.
- Attack 3.
- Combo.
- Cast.
- Special.
- Hurt.
- Dodge.
- Death.
- Block para classes apropriadas.
- Interação com objetos, quando necessário.

## Direções

No mínimo:

- Frente.
- Costas.
- Esquerda.
- Direita.

Oito direções são desejáveis quando o conjunto de assets permitir.

## Requisitos

- Quadros realmente diferentes.
- Movimento das pernas e braços.
- Rotação e deslocamento coerentes do corpo.
- Armas acompanhando corretamente as mãos.
- Pés ancorados no chão.
- Sem imagens cortadas.
- Sem objetos aparecendo indevidamente entre quadros.
- Sem fundos indesejados.
- Sem interpolação que borre a pixel art.

### Fluidez

Implemente um controlador de animações com estados bem definidos.

Use delta time, velocidades adequadas, transições coerentes e sincronização entre os movimentos e a distância percorrida.

Não considere uma animação completa apenas porque ela possui muitos quadros repetidos.

---

# 6. MOVIMENTAÇÃO NATURAL E FLUIDA

Esta é uma das prioridades máximas.

Quero que personagens, NPCs e inimigos se movimentem naturalmente.

### Implementar

- Aceleração progressiva.
- Desaceleração natural.
- Movimentação diagonal normalizada.
- Caminhada e corrida com animações distintas.
- Direção visual acompanhando a direção real.
- Detecção correta de colisões.
- Movimento sincronizado com os passos.
- Câmera suave.
- Resposta rápida aos comandos.
- Transições adequadas entre idle, walk, run e ataque.

### Proibido

- Deslocar um sprite parado para simular caminhada.
- Simular movimento apenas fazendo a imagem subir e descer.
- Personagens deslizando sem passos.
- NPCs flutuando.
- Personagens atravessando paredes.
- Mudanças de quadros que alterem a altura dos pés.

### NPCs

NPCs devem possuir animações e rotinas próprias.

Exemplos:

- Guarda patrulhando.
- Ferreiro trabalhando.
- Comerciante parado ou organizando itens.
- Habitantes caminhando.
- Curandeiro realizando animações de atendimento.

Todas essas ações devem respeitar a geometria do cenário.

---

# 7. PERSONALIZAÇÃO DO PERSONAGEM

Quero um criador de personagem com:

- Nome.
- Classe.
- Aparência física.
- Tom de pele.
- Cabelo.
- Cor do cabelo.
- Rosto, quando viável.
- Vestimenta inicial.

As características escolhidas devem continuar visíveis em todas as animações compatíveis.

---

# 8. EQUIPAMENTOS VISÍVEIS NO PERSONAGEM

**ESTE SISTEMA É OBRIGATÓRIO.**

Quando o jogador equipar um item, a aparência do personagem deve mudar imediatamente.

Exemplos:

- Armadura de ferro: peitoral de ferro aparece.
- Armadura dourada: armadura dourada aparece.
- Armadura de dragão: conjunto dracônico aparece.
- Espada de ferro: espada de ferro visível.
- Espada lendária: aparência própria.
- Arco mágico: arco visualmente diferente.
- Escudo novo: escudo diferente.
- Capacete equipado: capacete aparece.
- Manto equipado: manto aparece.
- Botas novas: botas visíveis.
- Luvas novas: detalhes correspondentes.

## Sistema técnico

Utilize camadas visuais sincronizadas:

1. Corpo.
2. Cabelo.
3. Rosto.
4. Roupa base.
5. Peitoral.
6. Calças.
7. Botas.
8. Luvas.
9. Capacete.
10. Capa.
11. Arma.
12. Escudo.
13. Acessórios.
14. Auras e efeitos.

As camadas precisam acompanhar todas as direções e animações.

A ordem de renderização deve variar conforme a direção do personagem, quando necessário.

### Requisito de teste

Equipe pelo menos três armaduras e três armas diferentes e demonstre visualmente que cada equipamento muda o personagem durante caminhada e combate.

Os equipamentos precisam continuar corretos após salvar e carregar o jogo.

---

# 9. MUNDO EXPLORÁVEL

O mundo deve ser uma das principais atrações do Idle Realms.

Não quero combate em uma faixa horizontal.

Quero o personagem andando em um mapa de verdade, encontrando monstros e lutando diretamente no cenário.

## Regiões iniciais

### Vila principal

- Praça central.
- Fonte.
- Ferreiro.
- Mercado.
- Taverna.
- Guilda.
- Casas.
- NPCs.
- Treinadores.
- Portais.
- Áreas de interação.

### Campos iniciais

- Slimes.
- Pequenos animais.
- Goblins iniciantes.
- Materiais de coleta.
- Missões básicas.

### Floresta Sussurrante

- Vegetação densa.
- Lobos.
- Treants.
- Criaturas mágicas.
- Ruínas.
- Caminhos alternativos.
- Chefe da floresta.

### Cripta dos Goblins

- Ambiente subterrâneo.
- Goblins.
- Esqueletos.
- Armadilhas.
- Baús.
- Salas especiais.
- Chefe da masmorra.

### Região Sombria

- Terreno corrompido.
- Árvores mortas.
- Cristais.
- Névoa.
- Criaturas perigosas.
- Ruínas antigas.
- Chefe regional.

### Regiões futuras

- Montanhas Dracônicas.
- Templo Celestial.
- Pântano Amaldiçoado.
- Deserto das Ruínas.
- Castelo do Eclipse.
- Santuário da Aura.
- Domínio do Vazio.

Prepare um sistema extensível para adicionar mapas sem reconstruir o motor do jogo.

---

# 10. COMBATE TOTALMENTE AUTOMÁTICO

O combate será 100% automático.

O jogador pode controlar a exploração e selecionar estratégias, mas não precisa apertar botões para executar cada ataque.

## Comportamento esperado

1. O personagem encontra um inimigo.
2. Avalia se está dentro do alcance.
3. Aproxima-se quando necessário.
4. Inicia a animação adequada.
5. Aplica dano no momento correto do golpe.
6. Utiliza habilidades automáticas.
7. Reage aos ataques inimigos.
8. Derrota o inimigo.
9. Recebe experiência e recompensas.
10. Procura outro alvo quando a caça automática estiver ativa.

## Sistemas obrigatórios

- Ataque básico automático.
- Habilidades automáticas.
- Seleção de alvos.
- Alcance físico e mágico.
- Cooldowns.
- Dano crítico.
- Defesa.
- Resistência.
- Esquiva.
- Bloqueio.
- Efeitos de status.
- Cura automática configurável.
- Poções.
- Regeneração.
- Auto-caça.
- Combate contra chefes.

## Impacto visual

Os ataques precisam ter:

- Preparação.
- Execução.
- Momento de impacto.
- Reação do inimigo.
- Recuperação.

Adicionar efeitos para espadas, flechas, socos, magia, explosões, raios, fogo, gelo, energia sagrada, sombras e Aura.

---

# 11. SISTEMA COMPLETO DE CLASSES

Todas as seis classes iniciais devem possuir múltiplas rotas de evolução.

As evoluções precisam alterar habilidades, atributos, aparência, equipamentos característicos e estilo de combate.

## Guerreiro

**Rota 1 — Fúria**

Guerreiro → Berserker → Berserker Ancestral

Foco em dano físico, velocidade de ataque, fúria e sobrevivência em situações perigosas.

**Rota 2 — Resistência**

Guerreiro → Guardião → Colosso de Ferro

Foco em defesa, resistência, controle de inimigos e redução de dano.

**Rota 3 — Espadas**

Guerreiro → Mestre de Armas → Mestre de Espadas → **Espadachim Supremo**

Foco em técnica, combos, precisão e domínio absoluto de espadas.

## Cavaleiro

**Rota 1 — Sagrada**

Cavaleiro → Paladino → Campeão da Luz

Poder sagrado, proteção, cura e ataques luminosos.

Inclua caminhos compatíveis com Cavaleiro Sagrado, Templário e especializações celestiais.

**Rota 2 — Sombria**

Cavaleiro → Cavaleiro Negro → Cavaleiro do Eclipse

Maldições, dano sombrio, drenagem e energia das trevas.

**Rota 3 — Dragões**

Cavaleiro → Cavaleiro Dragão → **Matador de Dragões**

Combate contra criaturas poderosas, força física, resistência e técnicas dracônicas.

## Mago

**Rota 1 — Domínio Mágico**

Mago → Arquimago → Arquimago Supremo

Domínio de diferentes escolas de magia.

**Rota 2 — Invocação**

Mago → Invocador → Senhor das Entidades

Invoca familiares, espíritos e criaturas mágicas que lutam automaticamente.

**Rota 3 — Combate Corpo a Corpo**

Mago → Mago de Combate → **Arcano de Batalha**

Magia aplicada ao corpo, às armas e aos golpes físicos.

Esta rota deve ser visualmente diferente da de um Mago tradicional.

### Nove círculos de magia

Implemente progressão do primeiro ao nono círculo.

Os círculos devem representar o domínio mágico e funcionar em conjunto com as rotas de evolução.

O Arquimago precisa transmitir uma sensação de poder mágico extraordinário.

Não limite o Mago a um único elemento.

## Arqueiro

**Rota 1**

Arqueiro → Atirador de Elite → Olho do Horizonte

Precisão, dano crítico e ataques a longa distância.

**Rota 2**

Arqueiro → Caçador → Senhor das Feras

Armadilhas, companheiros animais e rastreamento.

**Rota 3**

Arqueiro → Arqueiro Arcano → Arqueiro Astral

Flechas mágicas, ataques elementais e energia astral.

## Ladino

**Rota 1**

Ladino → Assassino → Ceifador das Sombras

Ataques furtivos, crítico, execução e velocidade.

**Rota 2**

Ladino → Trapaceiro → Mestre das Ilusões

Esquiva, cópias ilusórias e confusão.

**Rota 3**

Ladino → Venomista → Alquimista Mortal

Venenos, dano contínuo e enfraquecimento.

## Monge

**Rota 1**

Monge → Discípulo da Aura → Punho Celestial

Energia espiritual e golpes poderosos de Aura.

**Rota 2**

Monge → Monge Guardião → Mestre do Voto

Resistência, recuperação e técnicas defensivas.

**Rota 3**

Monge → Monge das Mil Mãos → **Sábio dos Mil Punhos**

Combos rápidos, artes marciais avançadas e domínio espiritual.

---

# 12. CLASSES SECRETAS

Quero um sistema extenso de classes secretas, com capacidade para dezenas de classes, incluindo aproximadamente 38 caminhos especiais ao longo da expansão do jogo.

Classes secretas já definidas ou desejadas:

- Espadachim Arcano.
- Lâmina Arcana.
- Soberano das Runas.
- Espadachim Transcendente.
- Mago do Vazio.
- Lâmina do Tempo.
- Monge do Dragão Interior.
- Cavaleiro da Ruína.
- Arqueiro Fantasma.
- Carrasco Carmesim.
- Outras classes secretas coerentes com o universo.

As classes secretas devem exigir requisitos especiais:

- Missões ocultas.
- Chefes secretos.
- Itens raros.
- Domínio de habilidades.
- Exploração de locais escondidos.
- Combinações de classes ou especializações.
- Conquistas especiais.

Nem todas precisam estar disponíveis no lançamento, mas a arquitetura deve permitir adicioná-las sem modificar profundamente o sistema principal.

Não apresente classes secretas não implementadas como se já fossem jogáveis.

---

# 13. SISTEMA DE ATRIBUTOS E RECURSOS

Atributos sugeridos:

- Força.
- Destreza.
- Inteligência.
- Vitalidade.
- Espírito.
- Defesa.
- Precisão.
- Esquiva.
- Taxa crítica.
- Dano crítico.
- Velocidade de ataque.
- Velocidade de movimento.
- Resistências.

Recursos de combate:

- Vida.
- Mana.
- Aura.
- Energia Sagrada.
- Energia Sombria.
- Fúria.

Cada classe deve utilizar os recursos adequados à sua identidade.

Exemplos:

- Mago: Mana.
- Monge: Aura.
- Berserker: Fúria.
- Paladino: Energia Sagrada.
- Cavaleiro Negro: Energia Sombria.

---

# 14. ÁRVORES DE HABILIDADES

Cada classe inicial e suas evoluções devem possuir árvores de habilidades próprias.

Quero:

- Habilidades ativas.
- Habilidades automáticas.
- Passivas.
- Especializações.
- Modificadores de habilidades.
- Combos.
- Sinergias entre equipamentos.
- Diferentes builds.

Exemplos:

- Guerreiro crítico.
- Guerreiro resistente.
- Cavaleiro sagrado.
- Cavaleiro sombrio.
- Mago invocador.
- Arcano de Batalha corpo a corpo.
- Arqueiro de precisão.
- Ladino assassino.
- Ladino venenoso.
- Monge de Aura.

As habilidades precisam fazer diferença prática no combate, não apenas aumentar números de forma genérica.

---

# 15. INVENTÁRIO, ITENS E EQUIPAMENTOS

Implemente as categorias:

- Espadas.
- Espadões.
- Adagas.
- Arcos.
- Cajados.
- Grimórios.
- Manoplas.
- Escudos.
- Capacetes.
- Peitorais.
- Calças.
- Botas.
- Luvas.
- Capas.
- Anéis.
- Amuletos.
- Acessórios especiais.

## Raridades

- Comum.
- Incomum.
- Raro.
- Épico.
- Lendário.
- Mítico.

Itens devem possuir atributos, requisitos, aparência visual e possíveis efeitos especiais.

## Sistemas

- Loot de monstros.
- Recompensas de missões.
- Equipamentos de chefes.
- Ferreiro.
- Melhorias.
- Craft.
- Loja.
- Venda.
- Organização de inventário.
- Comparação de equipamentos.

Os itens equipados devem refletir visualmente no personagem.

---

# 16. MASMORRAS E CHEFES

Quero masmorras exploráveis com:

- Salas.
- Inimigos.
- Baús.
- Armadilhas.
- Portas.
- Chefes.
- Recompensas.
- Progressão de dificuldade.

Chefes devem possuir ataques e animações próprios.

Exemplos de chefes iniciais:

- Rei Slime.
- Guardião da Floresta.
- Rei Goblin.
- Guardião das Catacumbas.
- Criatura Corrompida.
- Dragão Ancestral em conteúdo avançado.

Implemente pelo menos um ciclo completo de masmorra, do início à derrota do chefe e à entrega da recompensa, antes de expandir para muitas masmorras.

---

# 17. MISSÕES E PROGRESSÃO DO MUNDO

Quero:

- Missões principais.
- Missões secundárias.
- Missões de classe.
- Missões de evolução.
- Missões secretas.
- Missões de caça.
- Missões de chefes.
- Desafios especiais.

As missões devem levar o jogador a conhecer o mundo e desbloquear novas regiões.

Não quero apenas uma lista infinita de tarefas de matar monstros.

---

# 18. SISTEMA IDLE E PROGRESSO OFFLINE

O jogo deve funcionar como RPG Idle de verdade.

## Caça automática

O personagem deve:

- Encontrar inimigos.
- Caminhar até o alcance.
- Atacar.
- Utilizar habilidades.
- Coletar recompensas.
- Continuar a caçada.

Tudo isso respeitando colisões e obstáculos.

## Progresso offline

Ao fechar o jogo, o progresso deve ser salvo.

Ao retornar, o jogador deve receber um relatório com:

- Tempo offline.
- Experiência obtida.
- Ouro obtido.
- Materiais encontrados.
- Outros resultados permitidos pelas regras.

Implemente limites de tempo e cálculos equilibrados.

Não simule milhares de quadros de combate em segundo plano para calcular o progresso offline; use um sistema próprio de cálculo.

---

# 19. INTERFACE DO JOGO

A interface deve ser bonita, medieval, funcional e discreta.

O mundo precisa ocupar a maior parte da tela.

## Elementos

- Retrato do personagem.
- Nome e nível.
- Classe atual.
- Vida.
- Recurso de combate.
- Minimap.
- Missões.
- Barra de habilidades.
- Botões de auto-caça.
- Inventário.
- Equipamentos.
- Classes.
- Árvore de habilidades.
- Mapa.
- Guilda.
- Ferreiro.
- Loja.
- Masmorras.
- Configurações.

Não quero janelas permanentes bloqueando o cenário.

Os menus devem ser recolhíveis e responsivos.

## Mobile

- Joystick virtual.
- Controles de toque.
- Botões acessíveis.
- Interface adequada a telas menores.
- Resolução adaptável.
- Sem elementos cortados.
- Bom desempenho em celulares intermediários.

---

# 20. SALVAMENTO E PWA

Quero o jogo instalável pelo navegador, quando hospedado em ambiente compatível.

Implemente:

- Manifest PWA.
- Service Worker.
- Cache dos recursos essenciais.
- Salvamento local.
- Versionamento do save.
- Migração de dados.
- Recuperação de erros.
- Retomada da sessão.
- Compatibilidade desktop e mobile.

Evite perda de progresso ao atualizar o jogo.

---

# 21. FUTURAS FUNCIONALIDADES ONLINE

Prepare a arquitetura para:

- Criação de conta.
- Login.
- Sincronização na nuvem.
- Rankings.
- Eventos.
- Recompensas sazonais.
- Salvamento entre dispositivos.
- Progressão persistente.

O modo online inicial será solo.

Não priorize multiplayer em tempo real antes de estabilizar a versão principal.

Ao implementar serviços online, utilize autenticação e validação no servidor para dados competitivos, recompensas e rankings.

---

# 22. QUALIDADE DE CÓDIGO E ARQUITETURA

Analise a tecnologia atual do projeto e escolha uma arquitetura apropriada.

Você pode usar ferramentas e bibliotecas adequadas para jogos 2D, como um motor de renderização com suporte a sprites, animações, colisões e câmera.

Não escolha a tecnologia apenas por ser mais fácil gerar código.

Priorize:

- Organização modular.
- Separação entre lógica e renderização.
- Sistema de animação reutilizável.
- Componentes de personagem.
- Gerenciamento de assets.
- Sistema de equipamentos em camadas.
- Estados consistentes.
- Tratamento de erros.
- Bom desempenho.
- Código legível.
- Estrutura preparada para expansão.

Caso utilize um novo motor gráfico, explique a decisão e preserve os recursos aproveitáveis do projeto existente.

---

# 23. TESTES OBRIGATÓRIOS

Antes de considerar uma implementação concluída, teste:

## Personagens

- As seis classes.
- Todas as animações implementadas.
- Quatro direções.
- Equipamentos visíveis.
- Troca de armaduras.
- Troca de armas.
- Ataques.
- Dano.
- Morte.

## Movimento

- Caminhada.
- Corrida.
- Diagonal.
- Parada.
- Mudanças de direção.
- Colisões.
- Câmera.
- NPCs em movimento.
- Monstros andando.
- Caça automática.

## Combate

- Aquisição de alvo.
- Alcance.
- Dano.
- Habilidades.
- Cooldowns.
- Derrota.
- Recompensas.
- Bosses.

## Sistemas

- Inventário.
- Equipamentos.
- Evoluções.
- Missões.
- Salvamento.
- Carregamento.
- Progresso offline.
- Interface mobile.

## Testes visuais

Execute o jogo no navegador e gere capturas reais.

Não substitua capturas de gameplay por imagens conceituais.

Se houver falha, corrija antes de declarar conclusão.

---

# 24. REGRAS INEGOCIÁVEIS

1. Não reutilize personagens rejeitados.
2. Não utilize somente recoloração para diferenciar classes.
3. Não apresente animações falsas como spritesheets completas.
4. Não deixe personagens flutuando.
5. Não deixe NPCs rígidos.
6. Não use cenário estático como substituto de um mapa explorável.
7. Não esconda bugs.
8. Não invente resultados de testes.
9. Não afirme que um sistema está implementado quando só existe sua interface.
10. Não entregue imagens conceituais fingindo que são screenshots do jogo.
11. Não substitua desenvolvimento por respostas explicativas.
12. Não entregue apenas um prompt de implementação.
13. Não refaça sistemas funcionais sem necessidade técnica.
14. Não utilize sprites de terceiros sem licença adequada.
15. Não considere o projeto concluído apenas porque ele compila.

---

# 25. ORDEM DE EXECUÇÃO

Execute o desenvolvimento nesta ordem de prioridade:

### Fase 1 — Auditoria e reconstrução visual

- Examinar o projeto.
- Identificar problemas.
- Corrigir ou substituir o renderizador.
- Criar seis personagens de qualidade.
- Integrar spritesheets reais.
- Implementar animações fluidas.

### Fase 2 — Movimento e equipamentos

- Corrigir movimentação.
- Corrigir colisões.
- Corrigir câmera.
- Animar NPCs e monstros.
- Implementar personalização.
- Implementar equipamentos visíveis por camadas.

### Fase 3 — Mundo e combate

- Criar vila detalhada.
- Criar campos.
- Criar floresta.
- Criar região sombria própria.
- Implementar navegação.
- Melhorar combate automático.
- Criar efeitos e inimigos.

### Fase 4 — RPG completo

- Classes.
- Evoluções.
- Árvores de habilidades.
- Atributos.
- Recursos.
- Itens.
- Inventário.
- Missões.
- Chefes.
- Masmorras.

### Fase 5 — Polimento e expansão

- Progresso offline.
- PWA.
- Interface mobile.
- Otimização.
- Mais regiões.
- Classes secretas.
- Arquitetura online.

**Essas fases servem para organizar o desenvolvimento, não para substituir trabalho por planejamento.**

Comece implementando imediatamente a primeira fase e avance conforme os testes permitirem.

Se não for possível concluir todo o escopo em uma única execução, entregue uma versão funcional com as partes realmente implementadas, sem inventar recursos, e deixe os próximos passos documentados.

---

# 26. FORMATO DE ENTREGA

Ao concluir cada versão, entregue:

- Código-fonte atualizado.
- Novos arquivos de arte.
- Spritesheets utilizadas.
- Documentação.
- Instruções de execução.
- Lista de modificações.
- Testes realizados.
- Capturas reais do jogo.
- Lista objetiva de pendências.

Sempre descreva o que está implementado, o que é provisório e o que não foi desenvolvido.

---

# 27. OBJETIVO FINAL

Quero que Idle Realms tenha a aparência e a sensação de um RPG 2D medieval de qualidade.

Quero olhar para meu Guerreiro e perceber uma armadura bem desenhada, uma espada bonita, animações naturais e equipamentos que realmente aparecem no personagem.

Quero ver o Cavaleiro com armadura pesada e escudo, o Mago conjurando poderes impressionantes, o Arqueiro disparando flechas, o Ladino realizando ataques rápidos e o Monge lutando com técnicas de Aura.

Quero NPCs caminhando naturalmente, monstros animados, cenários detalhados, regiões perigosas e combate automático acontecendo diretamente no mundo.

O jogo deve ter profundidade suficiente para receber novas classes, regiões, chefes, equipamentos, eventos e expansões no futuro.

**O Idle Realms não deve parecer um protótipo com bonecos simples. Ele deve possuir identidade visual própria, movimentação fluida, combate satisfatório e progressão envolvente.**

## COMANDO FINAL

**COMECE A TRABALHAR AGORA.**

Abra o projeto fornecido, analise os arquivos existentes e implemente as alterações diretamente no código.

Não me devolva apenas um plano de desenvolvimento.

Não me peça para repetir decisões já definidas neste documento.

Priorize a arte dos seis personagens, as animações, a movimentação fluida e os equipamentos visíveis.

Teste o resultado, corrija os problemas encontrados e entregue uma versão jogável com as modificações realizadas.

Continue utilizando este documento como a especificação principal do Idle Realms em todas as próximas alterações.