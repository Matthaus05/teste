# Idle Realms · versão 0.1

RPG idle de fantasia medieval para navegador, com exploração em mapas, seis classes iniciais, combate automático e equipamentos que alteram a aparência. Esta primeira versão foi construída a partir de um repositório que continha somente um README.

## Jogar sem instalar

Baixe [Idle-Realms.html](Idle-Realms.html) e abra esse arquivo no navegador do computador. Ele contém o jogo, a interface e as artes em um único arquivo e funciona sem servidor ou conexão. O salvamento depende do armazenamento permitido pelo navegador para arquivos locais; use a exportação nas configurações como cópia de segurança. A instalação como PWA pertence à versão hospedada.

Para atualizar esse arquivo após editar o código, execute `npm run build:portable`.

## Executar

Requer Node.js 22.8 ou superior. O jogo e o servidor usam APIs nativas; não há pacotes de aplicação a instalar nem etapa de compilação.

```sh
cd /workspace/teste
npm run dev
```

O servidor de desenvolvimento atende na porta 3000. Para escolher outra porta:

```sh
node tools/serve.mjs --host 0.0.0.0 --port 3001
```

## Jogar

Crie o personagem com nome, classe, tom de pele e cabelo. Explore a vila, use a auto-caça para entrar nos campos e receba as recompensas no diário de missões. O ouro permite adquirir três visuais de armas e armaduras na forja. As regiões seguintes exigem níveis maiores.

| Ação | Controle |
| --- | --- |
| Andar | WASD ou setas; joystick no celular |
| Correr | Shift enquanto anda |
| Seguir uma rota | Clique ou toque no terreno |
| Selecionar inimigo para caçar | Clique ou toque no inimigo |
| Interagir com objeto, NPC ou portal próximo | E ou botão de interação |
| Inventário e equipamentos | I ou menu |
| Atlas de regiões | M ou menu |
| Pausar | Botão de pausa ou Escape fora dos menus |
| Ataques e habilidade especial | Automáticos ao alcançar o inimigo |

Salvamento local automático, exportação e importação estão nas configurações. Antes de limpar os dados do navegador ou começar uma nova jornada, exporte o progresso. A caça offline recompensa até oito horas nos campos, na floresta e nas terras sombrias; a vila e a masmorra não geram recompensas offline.

## Validar

```sh
npm run check
npm test
npm run dev
# Em outro terminal, com o servidor ativo:
npm run test:browser
```

O teste de navegador requer Chromium em `/usr/bin/chromium`; o teste usa o protocolo de depuração do navegador sem bibliotecas externas. As capturas e o relatório são gravados em `artifacts/`. Consulte [a entrega e as limitações](docs/ENTREGA.md) para distinguir recursos implementados do escopo futuro.

- [Especificação original](docs/ESPECIFICACAO.md)
- [Captura real no desktop](artifacts/gameplay-desktop.png)
- [Captura real no celular](artifacts/gameplay-mobile.png)
- [Criador de personagem](artifacts/character-creator.png)
- [Atlas de arte original](public/art/character-atlas.png)
- [Metadados das spritesheets](public/art/sprite-meta.json)
