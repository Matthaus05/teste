import { CLASSES, QUESTS, createPlayer, getStats, grantRewards, equipItem, buyItem, ITEM_TIERS, recordKill, visitRegion, claimQuest, questProgress, saveGame, loadGame, xpForLevel } from './progression.js';
import { createWorld, REGIONS, isBlocked, findPath, drawWorldGround, drawProp } from './world.js';
import { drawActor, drawMonster, drawItemIcon, buildSpriteSheet, SPRITE_META } from './art/sprites.js';

const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const canvas = $('game'), ctx = canvas.getContext('2d');
const saved = loadGame();
let player = saved.player || createPlayer({name:'Aventureiro',classId:'warrior'});
if(saved.player&&player.hp<=0){player.hp=getStats(player).hp;player.region='village';player.x=0;player.y=0;player.gold=Math.floor(player.gold*.95);player.autoHunt=false;}
let world, enemies = [], npcs = [], particles = [], floating = [], projectiles = [], path = [], target = null;
let clock = 0, last = 0, attackClock = 0, specialClock = 3, action = null, deathClock = 0;
let camera = {x:0,y:0}, width = innerWidth, height = innerHeight, zoom = 2;
let running = Boolean(saved.player), paused = false, panelOpen = null, selectedClass = 'warrior', skin = 0, hair = 0;
let keys = new Set(), joystick = {x:0,y:0}, walkDistance = 0, velocity = {x:0,y:0};
let lastUI = 0, saveTimer = 0, interaction = null, announcedClear = false, lastRegionChange = -10;
let settings = {sound:false,heal:35};
try { settings = {...settings,...JSON.parse(localStorage.getItem('idle-realms-settings') || '{}')}; } catch {}
const logs = [], seenErrors = [];
const tierNames = ['Ferro','Solar','Dracônico'];
const weaponNames = {warrior:['Espada de ferro','Lâmina solar','Espadão dracônico'],knight:['Espada do vigia','Martelo solar','Lança dracônica'],mage:['Cajado de carvalho','Cajado astral','Cetro dracônico'],archer:['Arco de freixo','Arco da aurora','Arco dracônico'],rogue:['Adagas de ferro','Adagas lunares','Garras dracônicas'],monk:['Faixas do iniciado','Manoplas solares','Punhos dracônicos']};
const classInfo = () => CLASSES.find(c => c.id === player.classId) || CLASSES[0];
const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
const aliveEnemies = () => enemies.filter(e => e.hp > 0);
function log(message) {
  logs.unshift(message); logs.length = Math.min(logs.length,4);
  $('event-log').innerHTML = logs.map((v,i)=>`<div style="opacity:${1-i*.2}">${esc(v)}</div>`).join('');
}
let toastTimer;
function toast(message) { const element=$('toast'); element.textContent=message; element.hidden=false; element.classList.add('visible'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>{element.classList.remove('visible');element.hidden=true;},3200); }
function persist() { const result = saveGame(player); $('save-status').textContent = result.ok ? 'Progresso salvo' : 'Falha ao salvar'; if (!result.ok) toast(result.error || 'Armazenamento indisponível. Exporte seu progresso.'); }
function enterRegion(id,initial=false,restore=false) {
  const region = REGIONS.find(r => r.id===id);
  if (!region) return false;
  if (!initial && player.level < region.level) { toast(`Esta região exige nível ${region.level}.`); return false; }
  const position={x:player.x,y:player.y};
  world = createWorld(id); player.region = id;interaction=null;$('interact').hidden=true;
  const keep=restore && !isBlocked(world,position.x,position.y,10);
  player.x = keep?position.x:world.spawn.x; player.y = keep?position.y:world.spawn.y; projectiles=[]; velocity = {x:0,y:0}; path=[]; target=null; action=null;
  enemies = world.enemySpawns.map((s,i)=>makeEnemy(s,i));
  if(id==='crypt'){if(!restore)player.cryptDefeated=[];else for(const enemy of enemies)if((player.cryptDefeated||[]).includes(enemy.id)){enemy.hp=0;enemy.phase=1;enemy.respawn=0;}}
  npcs = world.npcs.map((n,i)=>({...n,origin:{x:n.x,y:n.y},classId:n.classId||['knight','warrior','mage','archer','monk'][i%5],direction:'down',state:'idle',phase:0,skin:i%3,hair:i%3,armor:0,weapon:0,travel:0,wait:i}));
  visitRegion(player,id); announcedClear=false; lastRegionChange=clock;
  camera={x:player.x,y:player.y};
  $('region-name').textContent=world.name;
  $('region-subtitle').textContent=region.subtitle || 'Explore. Descubra. Evolua.';
  if (!initial) { log(`Você chegou a ${world.name}.`); persist(); }
  updateUI(); return true;
}
function makeEnemy(spawn,index) {
  const level = REGIONS.find(r=>r.id===world.id)?.level || 1;
  const boss=spawn.kind==='boss'; const hp=boss?100+level*45:25+level*11;
  return {...spawn,id:index,origin:{x:spawn.x,y:spawn.y},hp,maxHp:hp,attack:boss?7+level*2:3+level,defense:level*.6,speed:boss?48:55,range:boss?50:30,cooldown:1+index*.13,state:'idle',direction:'down',phase:0,hit:0,respawn:0,path:[],repath:0,travel:0,boss};
}
function face(actor,dx,dy) { if(Math.abs(dx)>Math.abs(dy)) actor.direction=dx<0?'left':'right'; else if(Math.abs(dy)>.01) actor.direction=dy<0?'up':'down'; }
function move(actor,dx,dy,dt) {
  const r=actor===player?9:8; let traveled=0;
  // Bounded substeps prevent tunneling even after a slow browser frame.
  const steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)*dt/5));
  for(let i=0;i<steps;i++) { const sx=dx*dt/steps,sy=dy*dt/steps; const ox=actor.x,oy=actor.y;
    if(!isBlocked(world,actor.x+sx,actor.y,r))actor.x+=sx;
    if(!isBlocked(world,actor.x,actor.y+sy,r))actor.y+=sy;
    traveled+=Math.hypot(actor.x-ox,actor.y-oy);
  }
  if(traveled>.01)face(actor,dx,dy); return traveled;
}
function pathVector(actor,route) {
  while(route.length&&distance(actor,route[0])<7)route.shift();
  if(!route.length)return{x:0,y:0};
  const d=distance(actor,route[0]);return{x:(route[0].x-actor.x)/d,y:(route[0].y-actor.y)/d};
}
function burst(x,y,color,count=10) { for(let i=0;i<count;i++){const a=i/count*Math.PI*2;particles.push({x,y:y-20,vx:Math.cos(a)*(25+Math.random()*45),vy:Math.sin(a)*40-20,life:.5,max:.5,color});} }
function textAt(actor,text,color='#f8df9e') {floating.push({x:actor.x,y:actor.y-45,text,color,life:1});}
let audio;
function sound(frequency=220,duration=.07) { if(!settings.sound)return; try {audio ||= new (window.AudioContext||window.webkitAudioContext)(); const osc=audio.createOscillator(),gain=audio.createGain();osc.type='triangle';osc.frequency.setValueAtTime(frequency,audio.currentTime);gain.gain.setValueAtTime(.04,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);osc.connect(gain).connect(audio.destination);osc.start();osc.stop(audio.currentTime+duration);}catch{} }
function hurtEnemy(enemy,multiplier=1,special=false) {
  if(enemy.hp<=0)return;
  const stats=getStats(player); const critical=Math.random()<(stats.crit ?? .12);
  const damage=Math.max(1,Math.round((stats.attack*multiplier-enemy.defense)*(critical?1.7:1)));
  enemy.hp=Math.max(0,enemy.hp-damage);enemy.hit=.2;enemy.state=enemy.hp?'hurt':'death';enemy.phase=0;
  textAt(enemy,`${critical?'✦ ':''}${damage}`,critical?'#ffe082':special?'#88e7ee':'#fff1c5');
  burst(enemy.x,enemy.y,special?classInfo().color||'#91e9ed':'#e3bd71',special?15:7);sound(special?440:190);
  if(enemy.hp===0) {
    enemy.respawn=20;recordKill(player,enemy.kind);
    if(world.id==='crypt'){player.cryptDefeated ||= [];if(!player.cryptDefeated.includes(enemy.id))player.cryptDefeated.push(enemy.id);}
    const regionLevel=REGIONS.find(r=>r.id===world.id)?.level||1;
    const reward=grantRewards(player,{xp:enemy.boss?110*regionLevel:18+regionLevel*6,gold:enemy.boss?80:6+regionLevel*2,materials:enemy.boss?8:1});
    log(`${enemy.boss?'Chefe derrotado':'Vitória'} · +${enemy.boss?80:6+regionLevel*2} ouro`);
    if(reward.levels){textAt(player,`NÍVEL ${player.level}`,'#ffdb7b');burst(player.x,player.y,'#f9d378',30);toast(`Nível ${player.level}! Seus atributos aumentaram.`);}
    if(enemy.boss&&world.id==='crypt') {player.dungeonComplete=true;toast('Cripta concluída! Recompensa do chefe recebida.');log('O Rei Goblin caiu. A cripta está livre.');}
    if(target===enemy)target=null;
  }
}
function startAttack(enemy,special=false) {
  face(player,enemy.x-player.x,enemy.y-player.y);
  action={time:0,duration:special?.72:.5,hit:false,enemy,special};
  player.state=special&&['mage','monk'].includes(player.classId)?'cast':'attack';player.phase=0;
  if(special){player.energy=Math.max(0,player.energy-25);specialClock=6;}else attackClock=getStats(player).interval;
}
function lineClear(a,b){const d=distance(a,b),steps=Math.ceil(d/6);for(let i=1;i<steps;i++){const f=i/steps;if(isBlocked(world,a.x+(b.x-a.x)*f,a.y+(b.y-a.y)*f,2))return false;}return true;}
function resolveAttack(hit,stats){
  const enemy=hit.enemy;if(enemy.hp<=0||distance(player,enemy)>stats.range+22||!lineClear(player,enemy))return;
  if(['mage','archer'].includes(player.classId)){
    projectiles.push({x:player.x,y:player.y,enemy,speed:player.classId==='archer'?360:260,life:2,kind:player.classId==='archer'?'arrow':'magic',special:hit.special,multiplier:hit.special?2.8:1});
  }else if(hit.special){
    const radius=player.classId==='monk'?95:player.classId==='rogue'?60:85;
    for(const e of aliveEnemies())if(distance(player,e)<radius&&lineClear(player,e))hurtEnemy(e,player.classId==='rogue'?3:2.1,true);
    if(player.classId==='knight'){player.hp=Math.min(stats.hp,player.hp+stats.hp*.1);textAt(player,'Proteção +','#9fe2dc');}
  }else hurtEnemy(enemy);
}
function showOffline(report){$('offline-content').innerHTML=`<p>Sua expedição continuou por ${Math.round(report.seconds/60)} minutos.</p><div class="stats-grid"><div><span>Experiência</span><strong>+${report.xp||0}</strong></div><div><span>Ouro</span><strong>+${report.gold||0}</strong></div><div><span>Materiais</span><strong>+${report.materials||0}</strong></div></div><p class="muted">Máximo de 8 horas. Recompensas dependem da região e do nível.</p>`;if(!$('offline').open)$('offline').showModal();}
let huntRepath=0;
function update(dt) {
  clock+=dt;
  if(!running||paused||panelOpen||document.hidden||$('offline').open)return;
  if(deathClock>0){deathClock-=dt;player.state='death';player.phase=1-Math.max(0,deathClock)/2;if(deathClock<=0){player.hp=getStats(player).hp;player.gold=Math.floor(player.gold*.95);player.autoHunt=false;enterRegion('village',true);toast('A curandeira resgatou você. 5% do ouro foi usado no resgate.');persist();}return;}
  player.playTime=(player.playTime||0)+dt;
  const stats=getStats(player);attackClock=Math.max(0,attackClock-dt);specialClock=Math.max(0,specialClock-dt);huntRepath-=dt;
  player.energy=Math.min(100,(player.energy||0)+dt*4);player.hp=Math.min(stats.hp,player.hp+dt*(world.id==='village'?8:.45));
  if(player.hp<stats.hp*(settings.heal/100)&&player.potions>0){player.potions--;player.hp=Math.min(stats.hp,player.hp+stats.hp*.5);textAt(player,'+ Cura','#9bdfa2');}
  let mx=(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0)+joystick.x;
  let my=(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0)+joystick.y;
  const manual=Math.hypot(mx,my)>.1;
  if(manual){const n=Math.hypot(mx,my);mx/=Math.max(1,n);my/=Math.max(1,n);path=[];}
  if(player.autoHunt&&!manual&&!action) {
    if(!target||target.hp<=0) {target=aliveEnemies().filter(e=>!(world.id==='crypt'&&e.boss&&aliveEnemies().some(m=>!m.boss))).sort((a,b)=>distance(player,a)-distance(player,b))[0]||null;path=[];huntRepath=0;}
    if(target&&(distance(player,target)>stats.range*.86||!lineClear(player,target))&&huntRepath<=0){path=findPath(world,player,target);huntRepath=.65;}
    if(target&&distance(player,target)<=stats.range*.95&&lineClear(player,target))path=[];
  }
  if(!manual&&path.length&&!action) { const v=pathVector(player,path);mx=v.x;my=v.y; }
  const speed=stats.speed*(keys.has('shift')?1.5:1);
  if(action){mx=0;my=0;velocity.x=0;velocity.y=0;action.time+=dt;player.phase=Math.min(1,action.time/action.duration);
    if(!action.hit&&player.phase>=.48){action.hit=true;
      resolveAttack(action,stats);
    }
    if(action.time>=action.duration)action=null;
  } else {
    const ease=1-Math.exp(-dt*(manual?18:12));velocity.x+=(mx*speed-velocity.x)*ease;velocity.y+=(my*speed-velocity.y)*ease;
    if(Math.abs(velocity.x)<.1)velocity.x=0;if(Math.abs(velocity.y)<.1)velocity.y=0;
    const walked=move(player,velocity.x,velocity.y,dt);walkDistance+=walked;
    player.state=walked>.1?(keys.has('shift')?'run':'walk'):'idle';player.phase=walked>.1?(walkDistance/44)%1:(clock*.55)%1;
    const close = target&&target.hp>0&&distance(player,target)<=stats.range&&lineClear(player,target)?target:aliveEnemies().filter(e=>distance(player,e)<=stats.range&&lineClear(player,e)).sort((a,b)=>distance(player,a)-distance(player,b))[0];
    if(close&&!manual&&attackClock<=0&&lineClear(player,close))startAttack(close,specialClock<=0&&player.energy>=25);
  }
  for(const shot of projectiles){shot.life-=dt;const dx=shot.enemy.x-shot.x,dy=shot.enemy.y-shot.y,d=Math.hypot(dx,dy);if(shot.enemy.hp<=0){shot.life=0;continue;}if(d<shot.speed*dt+8){hurtEnemy(shot.enemy,shot.multiplier,shot.special);shot.life=0;}else{shot.x+=dx/d*shot.speed*dt;shot.y+=dy/d*shot.speed*dt;if(isBlocked(world,shot.x,shot.y,2))shot.life=0;}}
  projectiles=projectiles.filter(p=>p.life>0);
  for(const enemy of enemies)updateEnemy(enemy,dt);
  for(const npc of npcs) {
    npc.wait-=dt;
    if(npc.wait<=0){npc.route=findPath(world,npc,{x:npc.origin.x+Math.sin(clock+npc.x)*64,y:npc.origin.y+Math.cos(clock*.7+npc.x)*48});npc.wait=5;}
    const v=pathVector(npc,npc.route||[]),moved=move(npc,v.x*30,v.y*30,dt);npc.travel+=moved;npc.state=moved>.1?'walk':'idle';npc.phase=moved>.1?(npc.travel/40)%1:(clock*.4)%1;
  }
  interaction=findInteraction();$('interact').hidden=!interaction;$('interact').querySelector('span').textContent=interaction?interaction.name:'Interagir';$('interact').title=interaction?`Interagir com ${interaction.name} · E`:'Interagir · E';
  saveTimer+=dt;if(saveTimer>15){persist();saveTimer=0;}
}
function updateEnemy(enemy,dt) {
  if(enemy.hp<=0){enemy.phase=Math.min(1,enemy.phase+dt*2);enemy.respawn-=dt;if(enemy.respawn<=0&&world.id!=='crypt'){Object.assign(enemy,makeEnemy({...enemy.origin,kind:enemy.kind},enemy.id));}return;}
  if(world.id==='crypt'&&enemy.boss&&enemies.some(e=>!e.boss&&e.hp>0))return;
  enemy.hit=Math.max(0,enemy.hit-dt);enemy.cooldown-=dt;enemy.repath-=dt;
  const d=distance(enemy,player);
  if(d<280&&(d>enemy.range||!lineClear(enemy,player))){if(enemy.repath<=0){enemy.path=findPath(world,enemy,player);enemy.repath=.8;}const v=pathVector(enemy,enemy.path);const walked=move(enemy,v.x*enemy.speed,v.y*enemy.speed,dt);enemy.travel+=walked;enemy.state=enemy.hit?'hurt':walked>.05?'walk':'idle';enemy.phase=(enemy.travel/35)%1;
  }else if(d<=enemy.range&&enemy.cooldown<=0&&lineClear(enemy,player)){
    face(enemy,player.x-enemy.x,player.y-enemy.y);enemy.cooldown=1.5;enemy.state='attack';enemy.attackAnimation=.35;
    const stats=getStats(player),dodge=Math.random()<(stats.dodge||.05),block=player.classId==='knight'&&Math.random()<stats.block;
    const damage=dodge?0:Math.max(1,Math.round((enemy.attack-stats.defense*.4)*(block?.35:1)));
    player.hp=Math.max(0,player.hp-damage);textAt(player,dodge?'Esquiva':block?`Bloqueio ${damage}`:`−${damage}`,dodge?'#9de7d8':'#ef9c8a');sound(95,.09);
    if(player.hp<=0){deathClock=2;action=null;player.autoHunt=false;log('Você caiu em batalha. O resgate está a caminho.');}
  }else {if(enemy.attackAnimation>0){enemy.attackAnimation-=dt;enemy.phase=1-enemy.attackAnimation/.35;}else {enemy.state=enemy.hit?'hurt':'idle';enemy.phase=(clock*.7)%1;}}
}
function findInteraction() {
  if(clock-lastRegionChange<1)return null;
  const nearby=[...(world.portals||[]).map(p=>({...p,kind:'portal'})),...(world.interactables||[]),...npcs.map(n=>({...n,kind:'npc'}))];
  return nearby.filter(i=>distance(player,i)<75).sort((a,b)=>distance(player,a)-distance(player,b))[0]||null;
}
function interact() {
  if(!running||paused||deathClock>0||panelOpen||$('offline').open)return;
  interaction=findInteraction();if(!interaction)return;
  if(interaction.kind==='portal')return enterRegion(interaction.to);
  const label=(interaction.role||interaction.kind||interaction.name||'').toLowerCase();
  if(/ferreir|smith|forge/.test(label))openPanel('inventory');
  else if(/cura|heal|fonte|fountain/.test(label)){player.hp=getStats(player).hp;player.energy=100;toast('Vida e energia restauradas.');burst(player.x,player.y,'#9de6cd',20);}
  else if(/merc|loja|shop/.test(label)){if(player.gold>=15){player.gold-=15;player.potions+=3;toast('Você comprou 3 poções por 15 de ouro.');}else toast('3 poções custam 15 de ouro.');}
  else if(interaction.kind==='dungeonReward'&&!player.dungeonComplete){toast('Derrote o Rei Goblin para abrir este tesouro.');}
  else if(interaction.kind==='dungeonReward'||/chest|baú/.test(label)){if(!player.openedChests)player.openedChests=[];const id=world.id+':'+interaction.id;if(player.openedChests.includes(id))toast('Este baú já foi aberto.');else{player.openedChests.push(id);grantRewards(player,{xp:40,gold:35,materials:4});toast('Baú encontrado! +35 ouro, +4 materiais e +40 XP.');}}
  else {openPanel('quests');}
  persist();
}

function resize() {width=innerWidth;height=innerHeight;const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);canvas.style.width=width+'px';canvas.style.height=height+'px';ctx.setTransform(dpr,0,0,dpr,0,0);ctx.imageSmoothingEnabled=false;zoom=width<650?1.65:2;}
addEventListener('resize',resize);resize();
function draw(dt=1/60) {
  ctx.fillStyle='#101c20';ctx.fillRect(0,0,width,height);
  const follow=1-Math.exp(-8*dt);camera.x+=(player.x-camera.x)*follow;camera.y+=(player.y-camera.y)*follow;
  const offsetX=Math.round(width/2-camera.x*zoom),offsetY=Math.round(height*.53-camera.y*zoom);
  ctx.save();ctx.translate(offsetX,offsetY);ctx.scale(zoom,zoom);ctx.imageSmoothingEnabled=false;
  drawWorldGround(ctx,world,clock,{x:camera.x-width/zoom/2-80,y:camera.y-height/zoom/2-80,width:width/zoom+160,height:height/zoom+160});
  for(const portal of world.portals){ctx.save();ctx.translate(portal.x,portal.y);ctx.strokeStyle='#a7dfcd';ctx.lineWidth=1;ctx.globalAlpha=.6+.2*Math.sin(clock*2);ctx.beginPath();ctx.ellipse(0,0,20+Math.sin(clock*2)*2,9,0,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.ellipse(0,-14,13,24,0,0,Math.PI*2);ctx.stroke();ctx.restore();label(portal.x,portal.y-47,portal.name,'#b8e5d9',8);}
  const ordered=[...world.props.map(p=>({type:'prop',y:p.y,item:p})),...npcs.map(p=>({type:'npc',y:p.y,item:p})),...enemies.filter(e=>e.hp>0||e.respawn>19.5).map(p=>({type:'enemy',y:p.y,item:p})),{type:'hero',y:player.y,item:player}].sort((a,b)=>a.y-b.y);
  for(const entry of ordered){const p=entry.item;if(Math.abs(p.x-camera.x)>width/zoom/2+180||Math.abs(p.y-camera.y)>height/zoom/2+180)continue;
    if(entry.type==='prop'){if(p.type==='chest')p.open=(player.openedChests||[]).includes(world.id+':'+p.id);drawProp(ctx,p,clock);continue;}
    ctx.save();ctx.translate(Math.round(p.x),Math.round(p.y));
    if(entry.type==='enemy'){if(p===target){ctx.strokeStyle='#d5a45b';ctx.beginPath();ctx.ellipse(0,-1,p.boss?26:16,7,0,0,Math.PI*2);ctx.stroke();}drawMonster(ctx,p,clock);}else {drawActor(ctx,p,clock);}
    ctx.restore();
    if(entry.type==='npc'){label(p.x,p.y-51,p.name,'#efe0b3',8);label(p.x,p.y-42,({guild:'Guilda',blacksmith:'Ferreiro',shop:'Mercadora',healer:'Curandeira',guard:'Guarda',villager:'Habitante',quest:'Explorador'}[p.role]||'Habitante'),'#9db8ad',6);}
    if(entry.type==='hero'){label(p.x,p.y-52,player.name,'#f8e4ae',8);}
    if(entry.type==='enemy'&&p.hp>0&&(p.hp<p.maxHp||p===target||p.boss)){ctx.fillStyle='#24202a';ctx.fillRect(p.x-17,p.y-42,34,4);ctx.fillStyle=p.boss?'#cf8b55':'#aa645c';ctx.fillRect(p.x-16,p.y-41,32*p.hp/p.maxHp,2);if(p.boss)label(p.x,p.y-49,p.name||'Guardião ancestral','#f4ba78',8);}
  }
  if(action){ctx.save();ctx.translate(player.x,player.y-20);ctx.globalAlpha=Math.sin(player.phase*Math.PI);ctx.strokeStyle=action.special?(classInfo().color||'#9addd7'):'#ffe8a6';ctx.lineWidth=action.special?2:3;ctx.beginPath();if(action.special)ctx.arc(0,0,20+player.phase*45,0,Math.PI*2);else {const a=Math.atan2(action.enemy.y-player.y,action.enemy.x-player.x);ctx.arc(0,0,30,a-1.1+player.phase*.8,a+.1+player.phase*.8);}ctx.stroke();ctx.restore();}
  for(const shot of projectiles){ctx.save();ctx.translate(shot.x,shot.y-20);const a=Math.atan2(shot.enemy.y-shot.y,shot.enemy.x-shot.x);ctx.rotate(a);ctx.fillStyle=shot.kind==='arrow'?'#f0ddb1':shot.special?'#e4c5ff':'#9de5ee';if(shot.kind==='arrow'){ctx.fillRect(-10,-1,15,2);ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(0,-3);ctx.lineTo(0,3);ctx.fill();}else{ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=8;ctx.beginPath();ctx.arc(0,0,shot.special?5:3,0,Math.PI*2);ctx.fill();}ctx.restore();}
  for(const p of particles){ctx.globalAlpha=Math.max(0,p.life/p.max);ctx.fillStyle=p.color;ctx.fillRect(Math.round(p.x),Math.round(p.y),2,2);}ctx.globalAlpha=1;
  for(const f of floating){ctx.globalAlpha=Math.min(1,f.life*2);label(f.x,f.y,f.text,f.color,10);}ctx.globalAlpha=1;
  ctx.restore();
  // A restrained vignette gives the bright play area a frame without hiding geometry.
  const vignette=ctx.createRadialGradient(width/2,height/2,height*.25,width/2,height/2,Math.max(width,height)*.65);vignette.addColorStop(0,'transparent');vignette.addColorStop(1,'#07131680');ctx.fillStyle=vignette;ctx.fillRect(0,0,width,height);
  drawMinimap();drawPreview();
}
function label(x,y,text,color,size=8){ctx.font=`${size}px Georgia`;ctx.textAlign='center';ctx.fillStyle='#0d171cf0';ctx.fillText(text,Math.round(x)+1,Math.round(y)+1);ctx.fillStyle=color;ctx.fillText(text,Math.round(x),Math.round(y));}
function drawMinimap(){const c=$('minimap'),m=c.getContext('2d'),sx=c.width/world.width,sy=c.height/world.height;m.fillStyle='#203c35';m.fillRect(0,0,c.width,c.height);for(const key of world.blocked){const [x,y]=key.split(',').map(Number);m.fillStyle='#142923';m.fillRect(x*32*sx,y*32*sy,Math.ceil(32*sx),Math.ceil(32*sy));}for(const p of world.portals){m.fillStyle='#7ad9d0';m.fillRect(p.x*sx-2,p.y*sy-2,4,4);}for(const e of aliveEnemies()){m.fillStyle=e.boss?'#edc26c':'#b57665';m.fillRect(e.x*sx,e.y*sy,2,2);}m.fillStyle='#fff0b9';m.beginPath();m.arc(player.x*sx,player.y*sy,3,0,Math.PI*2);m.fill();}
function preview(canvas,actor,scale=3){if(!canvas)return;const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);c.imageSmoothingEnabled=false;c.save();c.translate(canvas.width/2,canvas.height*.85);c.scale(scale,scale);drawActor(c,actor,clock);c.restore();}
function drawPreview(){const actor={...player,classId:running?player.classId:selectedClass,skin:running?player.skin:skin,hair:running?player.hair:hair,direction:'down',state:'idle',phase:(clock*.6)%1};if(!running)preview($('creator-preview'),actor,4);preview($('portrait'),{...player,state:'idle',direction:'down',phase:0},1.55);if(panelOpen&&$('gear-preview'))preview($('gear-preview'),{...player,state:'walk',phase:(clock*1.3)%1,direction:['down','left','up','right'][Math.floor(clock/3)%4]},4);}
function updateUI(){const stats=getStats(player);$('player-name').textContent=player.name;$('class-name').textContent=classInfo().name;$('level').textContent=player.level;$('hp-text').textContent=`${Math.ceil(player.hp)} / ${Math.ceil(stats.hp)}`;$('hp-fill').style.width=`${Math.max(0,Math.min(100,player.hp/stats.hp*100))}%`;$('resource-fill').style.width=`${player.energy||0}%`;$('xp-fill').style.width=`${Math.min(100,player.xp/xpForLevel(player.level)*100)}%`;$('gold').textContent=player.gold;$('materials').textContent=player.materials;
  $('auto-hunt').classList.toggle('active',!!player.autoHunt);$('auto-hunt').setAttribute('aria-pressed',String(!!player.autoHunt));$('auto-hunt').querySelector('small').textContent=player.autoHunt?'Explorando e combatendo':'Desativada';
  $('pause').innerHTML=paused?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 11 7-11 7z"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14M16 5v14"/></svg>';$('pause').title=paused?'Retomar o jogo':'Pausar o jogo';$('pause').setAttribute('aria-label',$('pause').title);$('pause').setAttribute('aria-pressed',String(paused));
  $('skill-basic').title='Ataque básico automático';$('skill-special').style.opacity=specialClock>0?'.5':'1';$('skill-special').querySelector('.skill-key').textContent=specialClock>0?Math.ceil(specialClock)+'s':'AUTO';$('skill-special').title=specialClock>0?`Especial disponível em ${Math.ceil(specialClock)} segundos`:'Habilidade especial automática disponível';
  $('skill-heal').querySelector('.skill-label').textContent=`Poção · ${player.potions}`;$('skill-heal').title=`Usar poção de cura · Q · ${player.potions} disponíveis`;
  const quest=QUESTS.find(q=>!questProgress(player,q.id).claimed);if(quest){const p=questProgress(player,quest.id);$('quest-title').textContent=quest.name;$('quest-progress').textContent=`${quest.description} · ${p.current}/${p.target}`;$('quest-action').textContent=p.complete?'Receber recompensa':'Ver diário';$('quest-action').onclick=()=>{if(p.complete){const r=claimQuest(player,quest.id);if(r.ok){toast('Recompensa de missão recebida.');persist();updateUI();}}else openPanel('quests');};}else{$('quest-title').textContent='O próximo capítulo';$('quest-progress').textContent='Todas as missões desta versão concluídas.';$('quest-action').textContent='Explorar mundo';$('quest-action').onclick=()=>openPanel('map');}}

function openPanel(type){if(!running||deathClock>0)return;panelOpen=type;renderPanel(type);if(!$('panel').open)$('panel').showModal();}
function closePanel(){panelOpen=null;$('panel').close();keys.clear();joystick={x:0,y:0};}
const statLabel={hp:'Vida máxima',attack:'Ataque',defense:'Defesa',range:'Alcance',speed:'Movimento',interval:'Intervalo de ataque',crit:'Chance crítica',dodge:'Esquiva'};
function renderPanel(type){const title={character:'Seu aventureiro',inventory:'Equipamentos & forja',classes:'Caminhos de classe',quests:'Diário de aventura',map:'Atlas dos reinos',settings:'Configurações',help:'Guia do aventureiro'};$('panel-title').textContent=title[type]||type;const body=$('panel-content');
  if(type==='character'){const stats=getStats(player);body.innerHTML=`<div class="character-summary"><canvas id="gear-preview" width="220" height="210"></canvas><div><span class="eyebrow">NÍVEL ${player.level}</span><h2>${esc(player.name)}</h2><p>${esc(classInfo().name)} · ${esc(classInfo().resource||'Energia')}</p><p>${esc(classInfo().description)}</p></div></div><div class="stats-grid">${Object.entries(statLabel).map(([k,n])=>`<div><span>${n}</span><strong>${k==='crit'||k==='dodge'?Math.round((stats[k]||0)*100)+'%':Math.round((stats[k]||0)*10)/10}</strong></div>`).join('')}</div><p class="muted">Equipamento: ${tierNames[player.armor]} · ${esc(weaponNames[player.classId][player.weapon])}</p>`;}
  if(type==='inventory'){body.innerHTML=`<div class="character-summary"><canvas id="gear-preview" width="220" height="210"></canvas><div><span class="eyebrow">EQUIPAMENTOS EM CAMADAS</span><h2>O poder tem uma forma.</h2><p>Compare, forje e equipe. As peças acompanham os passos e os ataques em quatro direções.</p><p>${player.gold} ouro · ${player.materials} materiais</p></div></div><div class="gear-columns">${['weapon','armor'].map(slot=>`<section><h3>${slot==='weapon'?'Armas':'Armaduras'}</h3>${[0,1,2].map(t=>{const owned=player.inventory[slot].includes(t),equipped=player[slot]===t;return `<article class="gear-item tier-${t}"><canvas width="48" height="48" data-icon="${slot}:${t}"></canvas><div><strong>${esc(slot==='weapon'?weaponNames[player.classId][t]:['Armadura de ferro','Armadura solar','Armadura dracônica'][t])}</strong><small>${ITEM_TIERS[t].rarity} · ${slot==='weapon'?`Ataque +${ITEM_TIERS[t].attack}`:`Defesa +${ITEM_TIERS[t].defense} · Vida +${ITEM_TIERS[t].health}`}</small></div><button data-equip="${slot}:${t}" ${equipped?'disabled':''}>${equipped?'Equipado':owned?'Equipar':`Forjar · ${slot==='weapon'?[0,90,280][t]:[0,75,240][t]} ouro`}</button></article>`;}).join('')}</section>`).join('')}</div><p class="muted">Novas classes começam com seu conjunto próprio. As três aparências desta versão são desbloqueadas na forja com ouro de combate.</p>`;
    body.querySelectorAll('[data-icon]').forEach(c=>{const[s,t]=c.dataset.icon.split(':');const g=c.getContext('2d');g.imageSmoothingEnabled=false;drawItemIcon(g,s,Number(t),0,0,48);});body.querySelectorAll('[data-equip]').forEach(b=>b.onclick=()=>{const[s,t]=b.dataset.equip.split(':');let result=player.inventory[s].includes(+t)?equipItem(player,s,+t):buyItem(player,s,+t);if(result.ok){equipItem(player,s,+t);toast('Equipamento atualizado.');persist();renderPanel(type);}else toast(result.error||'Ouro insuficiente.');});}
  if(type==='classes'){body.innerHTML=`<p class="muted">As seis classes iniciais são jogáveis. Escolha uma nova classe no criador em uma nova jornada. Evoluções e classes secretas ainda não estão disponíveis nesta versão.</p><div class="class-catalog">${CLASSES.map(c=>`<article class="catalog-card ${c.id===player.classId?'selected':''}"><span class="eyebrow">${c.id===player.classId?'SUA CLASSE':'CLASSE INICIAL'}</span><h3>${esc(c.name)}</h3><p>${esc(c.description)}</p><small>${esc(c.resource||'Energia')} · ${c.stats.range>80?'Longa distância':'Corpo a corpo'}</small></article>`).join('')}</div>`;}
  if(type==='quests'){body.innerHTML=QUESTS.map(q=>{const p=questProgress(player,q.id);return `<article class="quest-entry"><span class="eyebrow">${p.claimed?'CONCLUÍDA':p.complete?'RECOMPENSA DISPONÍVEL':'EM ANDAMENTO'}</span><h3>${esc(q.name)}</h3><p>${esc(q.description)}</p><p>${p.current} / ${p.target} · ${q.reward?.gold||0} ouro · ${q.reward?.xp||0} XP</p><button data-claim="${q.id}" ${!p.complete||p.claimed?'disabled':''}>${p.claimed?'Recompensa recebida':'Receber recompensa'}</button></article>`;}).join('');body.querySelectorAll('[data-claim]').forEach(b=>b.onclick=()=>{const r=claimQuest(player,b.dataset.claim);if(r.ok){toast('Missão concluída!');persist();renderPanel(type);updateUI();}else toast(r.error);});}
  if(type==='map'){body.innerHTML=`<p class="muted">Viaje pelos portais do mundo ou use as rotas descobertas no atlas. Cada região tem sua própria geometria, criaturas e perigos.</p><div class="region-grid">${REGIONS.map(r=>`<button class="region-card region-${r.id}" data-region="${r.id}" ${player.level<r.level?'disabled':''}><span class="eyebrow">${r.id===world.id?'VOCÊ ESTÁ AQUI':'NÍVEL '+r.level}</span><h3>${esc(r.name)}</h3><p>${esc(r.subtitle||'Uma nova aventura espera.')}</p><span>${player.level<r.level?'🔒 Região bloqueada':'Explorar →'}</span></button>`).join('')}</div>`;body.querySelectorAll('[data-region]').forEach(b=>b.onclick=()=>{if(enterRegion(b.dataset.region)){closePanel();player.autoHunt=false;}});}
  if(type==='settings'){body.innerHTML=`<div class="setting-row"><label for="sound-setting">Sons de combate</label><input id="sound-setting" type="checkbox" ${settings.sound?'checked':''}></div><div class="setting-row"><label for="heal-setting">Usar poção automaticamente abaixo de</label><select id="heal-setting"><option value="0">Desativado</option>${[25,35,50,70].map(v=>`<option value="${v}" ${settings.heal===v?'selected':''}>${v}% de vida</option>`).join('')}</select></div><p class="muted">Salvamento local automático a cada 15 segundos e ao sair. Progresso offline limitado a 8 horas quando a caça estiver ativa fora da vila.</p><div class="button-row"><button id="save-now">Salvar agora</button><button id="export-save">Exportar progresso</button><label class="button" for="import-save">Importar progresso</label><input id="import-save" type="file" accept="application/json" hidden></div><p class="muted">Guarde um arquivo exportado antes de limpar os dados do navegador. Importar substitui apenas o progresso deste navegador após validar o arquivo.</p><button id="new-journey" class="danger">Iniciar nova jornada…</button>`;
    $('sound-setting').onchange=e=>{settings.sound=e.target.checked;localStorage.setItem('idle-realms-settings',JSON.stringify(settings));sound();};$('heal-setting').onchange=e=>{settings.heal=+e.target.value;localStorage.setItem('idle-realms-settings',JSON.stringify(settings));};$('save-now').onclick=()=>{persist();toast('Progresso salvo neste navegador.');};$('export-save').onclick=()=>{persist();const blob=new Blob([JSON.stringify({format:'idle-realms-export',player},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='idle-realms-save.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};$('import-save').onchange=async e=>{try {const data=JSON.parse(await e.target.files[0].text());if(data.format!=='idle-realms-export'||!data.player)throw Error('Formato de arquivo inválido.');const temp={values:new Map(),getItem(k){return this.values.get(k)||null;},setItem(k,v){this.values.set(k,v);},removeItem(k){this.values.delete(k);}};const put=saveGame(data.player,temp);if(!put.ok)throw Error('Dados inválidos.');const loaded=loadGame(temp);if(!loaded.player)throw Error(loaded.error||'Progresso inválido.');player=loaded.player;if(player.hp<=0){player.hp=getStats(player).hp;player.region='village';player.x=0;player.y=0;player.gold=Math.floor(player.gold*.95);player.autoHunt=false;}enterRegion(player.region,true,true);persist();closePanel();toast('Progresso importado.');}catch(error){toast(error.message||'Não foi possível importar.');}};$('new-journey').onclick=()=>{body.innerHTML='<h3>Guardar esta aventura?</h3><p>Exporte o progresso antes de iniciar outra jornada. A nova partida substituirá o salvamento local ao confirmar o personagem.</p><button id="confirm-new">Abrir criador de personagem</button>';$('confirm-new').onclick=()=>{closePanel();running=false;$('creator').showModal();};};}
  if(type==='help')body.innerHTML=`<div class="help-content"><h3>O mundo é seu caminho</h3><p>WASD ou setas para andar. Shift para correr. Clique no terreno para traçar uma rota; no celular, use o joystick. E interage com pessoas, fontes, baús e portais próximos.</p><h3>Você explora. Seu herói luta.</h3><p>O combate acontece automaticamente quando você para perto de um inimigo. A auto-caça encontra alvos e navega pelos obstáculos. Na vila, ativá-la leva aos Campos Dourados.</p><h3>Prepare a próxima expedição</h3><p>Poções são usadas abaixo do limite configurado. O mercado vende 3 por 15 ouro. Troque armas e armaduras na forja, receba missões no diário e desbloqueie regiões subindo de nível.</p><h3>A Cripta dos Goblins</h3><p>Derrote os guardas para despertar o Rei Goblin, vença o chefe e receba sua recompensa. Inimigos da cripta não reaparecem até uma nova expedição.</p><h3>Esta versão</h3><p>Artes originais, seis classes, três visuais de armas e armaduras por classe e cinco mapas. Evoluções, árvores de habilidades e serviços online aguardam desenvolvimento. Veja docs/ENTREGA.md.</p></div>`;
}

document.querySelectorAll('[data-panel]').forEach(b=>b.addEventListener('click',()=>openPanel(b.dataset.panel)));
$('close-panel').onclick=closePanel;$('panel').addEventListener('cancel',e=>{e.preventDefault();closePanel();});
$('auto-hunt').onclick=()=>{if(!running||paused||deathClock>0||panelOpen||$('offline').open)return;if(world.id==='village')enterRegion('fields');player.autoHunt=!player.autoHunt;path=[];target=null;toast(player.autoHunt?'Caça automática ativada.':'Caça automática desativada.');persist();updateUI();};
$('pause').onclick=()=>{paused=!paused;keys.clear();releaseJoy();updateUI();};$('interact').onclick=interact;
$('skill-heal').onclick=()=>{if(!running||paused||deathClock>0||panelOpen||$('offline').open)return;if(player.potions>0&&player.hp<getStats(player).hp){player.potions--;player.hp=Math.min(getStats(player).hp,player.hp+getStats(player).hp*.5);toast('Poção utilizada.');}else toast(player.potions?'Sua vida já está cheia.':'Compre poções no mercado.');};
$('skill-basic').onclick=()=>toast('O ataque básico é automático ao parar perto de inimigos.');$('skill-special').onclick=()=>toast('A habilidade da classe é usada automaticamente quando há energia.');
document.querySelectorAll('[data-class]').forEach(b=>b.onclick=()=>{selectedClass=b.dataset.class;document.querySelectorAll('[data-class]').forEach(c=>{c.classList.toggle('selected',c===b);c.setAttribute('aria-pressed',String(c===b));});const desc=$('class-description');if(desc)desc.textContent=CLASSES.find(c=>c.id===selectedClass)?.description||'';});
for(const field of ['skin','hair'])document.querySelectorAll(`[data-${field}]`).forEach(b=>b.onclick=()=>{if(field==='skin')skin=+b.dataset.skin;else hair=+b.dataset.hair;document.querySelectorAll(`[data-${field}]`).forEach(c=>{c.classList.toggle('selected',c===b);c.setAttribute('aria-pressed',String(c===b));});});
$('create-form').onsubmit=e=>{e.preventDefault();player=createPlayer({name:$('hero-name').value.trim()||'Aventureiro',classId:selectedClass,skin,hair});running=true;paused=false;deathClock=0;walkDistance=0;enterRegion('village',true);$('creator').close();persist();log('Bem-vindo a Avelora. Sua história começa aqui.');toast('WASD para explorar · E para interagir · Auto-caça para iniciar a aventura');};
$('creator').addEventListener('cancel',e=>e.preventDefault());
$('offline-close').onclick=()=>$('offline').close();
addEventListener('keydown',e=>{if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)||!running||panelOpen||$('offline').open)return;const k=e.key.toLowerCase();if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();keys.add(k);if(k==='e')interact();if(k==='i')openPanel('inventory');if(k==='m')openPanel('map');if(k==='c')openPanel('character');if(k==='k')openPanel('classes');if(k==='j')openPanel('quests');if(k==='h')openPanel('help');if(k==='q')$('skill-heal').click();if(k==='escape'){paused=!paused;keys.clear();releaseJoy();}});
addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));addEventListener('blur',()=>{keys.clear();releaseJoy();if(running)persist();});
let suspendedAt=0;
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(running)persist();suspendedAt=Date.now();keys.clear();releaseJoy();last=0;}else {last=0;if(running&&suspendedAt&&Date.now()-suspendedAt>=60000){const resumed=loadGame();if(resumed.player){player=resumed.player;enterRegion(player.region,true,true);if(resumed.offline?.seconds)showOffline(resumed.offline);}}suspendedAt=0;}});addEventListener('pagehide',()=>{if(running)persist();});
canvas.addEventListener('pointerdown',e=>{if(!running||paused||deathClock>0||panelOpen||document.hidden||$('offline').open)return;const p={x:(e.clientX-width/2)/zoom+camera.x,y:(e.clientY-height*.53)/zoom+camera.y};const hit=aliveEnemies().find(m=>distance(m,p)<30);if(hit){target=hit;player.autoHunt=true;huntRepath=0;}else{player.autoHunt=false;target=null;path=findPath(world,player,p);if(!path.length)toast('Este ponto não tem uma rota acessível.');}updateUI();});
const joy=$('joystick');let joyPointer=null;
joy.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joy.setPointerCapture(e.pointerId);updateJoy(e);});joy.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)updateJoy(e);});
function updateJoy(e){const r=joy.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,d=Math.max(32,Math.hypot(dx,dy));joystick={x:dx/d,y:dy/d};$('joystick-knob').style.transform=`translate(${joystick.x*26}px,${joystick.y*26}px)`;}
function releaseJoy(){joyPointer=null;joystick={x:0,y:0};$('joystick-knob').style.transform='';}joy.addEventListener('pointerup',releaseJoy);joy.addEventListener('pointercancel',releaseJoy);joy.addEventListener('lostpointercapture',releaseJoy);

function frame(now){const dt=last?Math.min(.05,(now-last)/1000):0;last=now;update(dt);for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=80*dt;p.life-=dt;}particles=particles.filter(p=>p.life>0);for(const f of floating){f.y-=dt*24;f.life-=dt;}floating=floating.filter(f=>f.life>0);draw(dt);if(now-lastUI>150){updateUI();lastUI=now;}requestAnimationFrame(frame);}
enterRegion(player.region||'village',true,true);$('loading').hidden=true;
if(!running)$('creator').showModal();
else if(saved.offline?.seconds>30)showOffline(saved.offline);
if(saved.error)toast(saved.error);
requestAnimationFrame(frame);
if('serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>log('Cache offline indisponível neste navegador.'));
window.addEventListener('error',e=>seenErrors.push(e.message));
// Small diagnostic surface used by the real-browser regression suite and sprite gallery.
window.__IDLE_REALMS__={getState:()=>({player:JSON.parse(JSON.stringify(player)),region:world.id,enemies:enemies.map(e=>({id:e.id,kind:e.kind,x:e.x,y:e.y,hp:e.hp,maxHp:e.maxHp,state:e.state})),paused,panelOpen,errors:seenErrors}),enterRegion:id=>enterRegion(id),moveTo:(x,y)=>{path=findPath(world,player,{x,y});return path.length;},step:seconds=>{for(let t=0;t<Math.min(600,seconds);t+=1/60)update(1/60);return player;},equip:(slot,tier)=>equipItem(player,slot,tier),start:options=>{player=createPlayer(options);running=true;paused=false;deathClock=0;attackClock=0;specialClock=3;walkDistance=0;keys.clear();joystick={x:0,y:0};if($('offline').open)$('offline').close();if($('panel').open)closePanel();$('creator').close();enterRegion('village',true);return player;},spriteSheet:(classId,appearance)=>buildSpriteSheet(classId,appearance),spriteMeta:SPRITE_META,persist,openPanel};
