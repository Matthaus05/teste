// Original, deterministic pixel environments. All coordinates are world pixels.
export const TILE = 32;
export const WORLD_W = 64;
export const WORLD_H = 48;
export const REGIONS = [
  { id: 'village', name: 'Vila de Avelora', level: 1, subtitle: 'O início de uma grande jornada' },
  { id: 'fields', name: 'Campos Dourados', level: 1, subtitle: 'Uma brisa atravessa as colinas' },
  { id: 'forest', name: 'Floresta Sussurrante', level: 3, subtitle: 'As raízes guardam segredos antigos' },
  { id: 'crypt', name: 'Cripta dos Goblins', level: 5, subtitle: 'Sob a pedra, um rei espera' },
  { id: 'shadow', name: 'Terras do Eclipse', level: 8, subtitle: 'Onde a luz se torna memória' },
];
const PALETTES = {
  village: { grass: '#567e45', grass2:'#648c4e', grassDark:'#406337', dirt:'#b7a06b', dirtLight:'#c7b17b', stone:'#9ca495', water:'#3e8e9b', waterDark:'#2b697b' },
  fields: { grass:'#678b46',grass2:'#789b50',grassDark:'#507339',dirt:'#b6a16a',dirtLight:'#c7b77e',stone:'#969c86',water:'#438c94',waterDark:'#2f6977' },
  forest: { grass:'#315b47',grass2:'#3d6a4e',grassDark:'#264737',dirt:'#8b8760',dirtLight:'#a49a6e',stone:'#707f70',water:'#347b83',waterDark:'#245963' },
  crypt: { grass:'#323d40',grass2:'#3c4949',grassDark:'#263034',dirt:'#5c6056',dirtLight:'#707164',stone:'#68716a',water:'#344e51',waterDark:'#26393f' },
  shadow: { grass:'#3a414b',grass2:'#48515b',grassDark:'#2e333e',dirt:'#665e69',dirtLight:'#7c6e7c',stone:'#655f70',water:'#4b486f',waterDark:'#333048' },
};
function hash(x,y,s=0) { let n = Math.imul(x + s * 317, 374761393) ^ Math.imul(y + 183, 668265263); n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967295; }
function tileKey(x,y) { return `${x},${y}`; }
function rectTiles(w,x,y,ww,hh,type,block=false) { for(let yy=y;yy<y+hh;yy++) for(let xx=x;xx<x+ww;xx++) if(xx>=0&&yy>=0&&xx<WORLD_W&&yy<WORLD_H) { w.tiles[yy][xx]=type; if(block) w.blocked.add(tileKey(xx,yy)); else w.blocked.delete(tileKey(xx,yy)); } }
function pathTiles(w,x1,y1,x2,y2,width=3,type='dirt') { const x0=Math.min(x1,x2),y0=Math.min(y1,y2); if(y1===y2) rectTiles(w,x0,y0-Math.floor(width/2),Math.abs(x2-x1)+1,width,type); else if(x1===x2) rectTiles(w,x0-Math.floor(width/2),y0,width,Math.abs(y2-y1)+1,type); }
function put(w,type,tx,ty,extra={}) { const p={type,x:tx*TILE,y:ty*TILE,...extra}; w.props.push(p); return p; }
function obstacle(w,x,y,ww=1,hh=1) { for(let yy=y;yy<y+hh;yy++)for(let xx=x;xx<x+ww;xx++) w.blocked.add(tileKey(xx,yy)); }
function tree(w,x,y,variant='oak',scale=1) { if(x<2||y<2||x>61||y>45)return; if(w.tiles[y]?.[x]!=='grass')return; if(w.blocked.has(tileKey(x,y)))return; put(w,'tree',x+.5,y+.8,{variant,scale,seed:hash(x,y)}); obstacle(w,x,y); }
function building(w,x,y,ww,hh,name,style='house',roof='#9d5749') {
  // x/y locate ground footprint. Elevated roof can overlap north of footprint.
  put(w,'building',x,y+hh,{w:ww*TILE,h:hh*TILE,name,style,roof}); obstacle(w,x,y,ww,hh);
  rectTiles(w,x+Math.floor(ww/2)-1,y+hh,3,2,'cobble');
}
function portal(w,x,y,to,name) { const p={x:x*TILE,y:y*TILE,to,name,radius:34}; w.portals.push(p); rectTiles(w,x-1,y-1,3,3,'cobble'); put(w,'portal',x,y,{to,name,seed:hash(x,y)}); }
function npc(w,id,name,role,x,y,classId='warrior',extra={}) { w.npcs.push({id,name,role,x:x*TILE,y:y*TILE,classId,direction:'down',...extra}); }
function enemy(w,kind,x,y,extra={}) { w.enemySpawns.push({kind,x:x*TILE+16,y:y*TILE+16,...extra}); }
function interact(w,id,kind,name,x,y) { w.interactables.push({id,kind,name,x:x*TILE,y:y*TILE,radius:58}); }
export function createWorld(regionId='village') {
  const meta=REGIONS.find(r=>r.id===regionId)||REGIONS[0];
  const w={...meta,width:WORLD_W*TILE,height:WORLD_H*TILE,tileSize:TILE,tiles:Array.from({length:WORLD_H},()=>Array(WORLD_W).fill('grass')),props:[],spawn:{x:32*TILE+16,y:27*TILE+16},npcs:[],enemySpawns:[],portals:[],interactables:[],blocked:new Set(),palette:PALETTES[meta.id]};
  for(let y=0;y<WORLD_H;y++)for(let x=0;x<WORLD_W;x++)if(x===0||y===0||x===WORLD_W-1||y===WORLD_H-1)w.blocked.add(tileKey(x,y));
  if(meta.id==='village') makeVillage(w);
  else if(meta.id==='fields')makeFields(w);
  else if(meta.id==='forest')makeForest(w);
  else if(meta.id==='crypt')makeCrypt(w);
  else makeShadow(w);
  // Decorative grass is always deterministic. It never participates in collision.
  for(let y=2;y<WORLD_H-2;y++)for(let x=2;x<WORLD_W-2;x++)if(w.tiles[y][x]==='grass'&&!w.blocked.has(tileKey(x,y))&&hash(x,y,92)>.82) put(w,meta.id==='shadow'?'ash':'flowers',x+hash(x,y,3),y+hash(x,y,4),{seed:hash(x,y,8),dark:meta.id==='forest'});
  return w;
}
function makeVillage(w) {
  pathTiles(w,4,29,58,29,3);pathTiles(w,32,5,32,43,3);
  rectTiles(w,25,19,14,12,'cobble');pathTiles(w,15,14,32,14,3);pathTiles(w,17,14,17,29,3);pathTiles(w,45,14,45,36,3);pathTiles(w,32,35,45,35,3);
  // Stream, pebble edges, and two foot bridges.
  for(let y=3;y<45;y++){ const x=50+Math.floor(Math.sin(y*.21)*2);rectTiles(w,x,y,5,1,'water',true); if(y%3===0) put(w,'reeds',x+.1,y+.7,{seed:hash(x,y)}); }
  rectTiles(w,47,27,10,4,'bridge');rectTiles(w,47,12,10,3,'bridge');
  building(w,24,14,5,4,'A GUILDA','guild','#526c80');
  building(w,35,14,6,4,'O CARVALHO DOURADO','tavern','#9c5f42');
  building(w,19,23,5,3,'FORJA DE BRUM','forge','#576a73');
  building(w,40,23,5,3,'MERCADO','market','#bc8b5a');
  building(w,13,9,5,4,'','house','#8c624d');building(w,9,33,5,4,'','house','#a8654b');building(w,20,35,5,4,'','house','#a8654b');building(w,38,36,5,4,'','house','#796278');
  // Plaza fountain is a real obstacle; path lanes surround it on every side.
  put(w,'fountain',32.5,23.6);obstacle(w,31,21,3,3);
  put(w,'banner',25,19,{color:'#456b87'});put(w,'banner',39,19,{color:'#456b87'});
  put(w,'lamp',25,28);put(w,'lamp',39,28);put(w,'lamp',29,18);put(w,'lamp',35,18);
  put(w,'bench',25,25);put(w,'bench',39,25);put(w,'bench',29,31);
  put(w,'cart',42,28);obstacle(w,41,27,2,1);
  for(let x=14;x<22;x++){if(x!==17)put(w,'fence',x,33,{orientation:'h'});}for(let x=8;x<15;x++)put(w,'fence',x,39,{orientation:'h'});
  for(let y=18;y<22;y++)for(let x=8;x<14;x++)rectTiles(w,x,y,1,1,'farm');
  for(const [x,y]of [[10,8],[20,10],[7,25],[8,29],[12,27],[20,18],[22,32],[28,39],[35,38],[45,8],[46,20],[45,31],[8,15],[12,42],[41,41]])tree(w,x,y,'oak',1.15);
  for(let y=3;y<45;y+=3)for(let x=3;x<61;x+=3)if((x<7||y<7||y>41||x>58)&&hash(x,y)>.22)tree(w,x,y,'oak',1.1+hash(x,y)*.3);
  npc(w,'guildmaster','Elara','guild',27,19,'mage');npc(w,'blacksmith','Brum','blacksmith',24.5,27.2,'warrior');npc(w,'merchant','Mira','shop',40,27.2,'rogue');npc(w,'healer','Irmã Lyra','healer',29,25,'mage');npc(w,'guard','Guarda Rowan','guard',30,31.5,'knight',{patrol:[{x:29*TILE,y:31*TILE},{x:36*TILE,y:31*TILE}]});npc(w,'villager','Theo','villager',37,20,'monk',{patrol:[{x:37*TILE,y:20*TILE},{x:37*TILE,y:26*TILE}]});
  interact(w,'guild','guild','Guilda dos Aventureiros',27,19);interact(w,'forge','blacksmith','Forja de Brum',24.5,27);interact(w,'market','shop','Mercado de Mira',40,27);interact(w,'healing','healer','Fonte da renovação',29,25);
  portal(w,59,29,'fields','Campos Dourados');portal(w,32,5,'forest','Floresta Sussurrante');
  w.spawn={x:32*TILE+16,y:27*TILE+16};
}
function makeFields(w) {
  pathTiles(w,3,25,59,25,4);pathTiles(w,30,6,30,42,3);pathTiles(w,30,10,57,10,3);pathTiles(w,30,38,51,38,3);
  rectTiles(w,8,9,12,9,'farm');rectTiles(w,9,33,13,8,'farm');
  building(w,8,18,5,4,'','barn','#8c5741');put(w,'windmill',17,16);obstacle(w,16,14,2,2);
  for(let x=7;x<=20;x++) { if(x<11||x>13) put(w,'fence',x,19,{orientation:'h'}); }
  for(let y=6;y<43;y++){const x=42+Math.floor(Math.sin(y*.19)*2);rectTiles(w,x,y,3,1,'water',true);}rectTiles(w,40,23,8,4,'bridge');rectTiles(w,40,9,8,3,'bridge');rectTiles(w,40,37,8,3,'bridge');
  for(const [x,y]of [[24,13],[27,17],[35,12],[35,32],[23,34],[48,19],[50,34],[57,14],[7,31],[12,7],[26,42],[58,41]])tree(w,x,y,'oak');
  for(let y=3;y<46;y+=3)for(let x=3;x<61;x+=3)if((x<6||y<5||y>43||x>59)&&hash(x,y)>.36)tree(w,x,y,'oak');
  const spawns=[['slime',23,22],['slime',26,27],['slime',33,22],['slime',35,28],['slime',20,29],['goblin',37,19],['goblin',49,23],['goblin',51,28],['wolf',54,32],['slime',23,17],['slime',32,34],['boss',55,8]];for(const [kind,x,y]of spawns)enemy(w,kind,x,y,{boss:kind==='boss',name:kind==='boss'?'Rei Slime':undefined});
  put(w,'chest',52,37,{id:'fields-chest'});interact(w,'fields-chest','chest','Baú esquecido',52,37);put(w,'sign',19,24,{text:'Campos Dourados'});npc(w,'farmer','Velho Cedro','quest',15,24,'monk');interact(w,'farmer','quest','O pedido do fazendeiro',15,24);
  portal(w,4,25,'village','Vila de Avelora');portal(w,30,5,'forest','Floresta Sussurrante');portal(w,58,25,'crypt','Cripta dos Goblins');w.spawn={x:9*TILE+16,y:25*TILE+16};
}
function makeForest(w) {
  pathTiles(w,5,37,32,37,3);pathTiles(w,32,8,32,37,3);pathTiles(w,32,15,56,15,3);pathTiles(w,12,23,32,23,2);pathTiles(w,12,23,12,37,2);
  rectTiles(w,25,25,13,9,'dirt');rectTiles(w,39,6,15,10,'moss');
  for(let y=3;y<45;y+=2)for(let x=3;x<61;x+=2){if(w.tiles[y][x]==='grass'&&hash(x,y,21)>.24){let variant=hash(x,y,22)>.55?'pine':'oak';tree(w,x,y,variant,.85+hash(x,y,23)*.5);}}
  for(let y=5;y<43;y++){let x=20+Math.floor(Math.sin(y*.25)*2);rectTiles(w,x,y,3,1,'water',true);}rectTiles(w,17,21,9,4,'bridge');rectTiles(w,17,35,9,4,'bridge');
  put(w,'ruin',42,11,{w:3*TILE,h:3*TILE});obstacle(w,42,9,3,2);put(w,'ruin',50,13,{w:2*TILE,h:4*TILE});obstacle(w,50,10,2,3);
  put(w,'stone',30,27,{large:true});obstacle(w,29,26,2,1);put(w,'mushrooms',28,28);put(w,'mushrooms',34,31);put(w,'crystal',44,16,{color:'#66c7af'});obstacle(w,44,16);
  const enemies=[['wolf',28,30],['wolf',33,32],['wolf',36,27],['treant',30,19],['goblin',13,29],['treant',36,15],['wolf',46,18],['boss',47,9]];for(const [kind,x,y]of enemies)enemy(w,kind,x,y,{boss:kind==='boss',name:kind==='boss'?'Guardião da Floresta':undefined});
  put(w,'chest',12,22,{id:'forest-chest'});interact(w,'forest-chest','chest','Relíquia das raízes',12,22);npc(w,'ranger','Lys','quest',30,35,'archer');interact(w,'ranger','quest','A guardiã dos caminhos',30,35);
  portal(w,5,37,'village','Vila de Avelora');portal(w,56,15,'shadow','Terras do Eclipse');portal(w,32,41,'fields','Campos Dourados');w.spawn={x:10*TILE+16,y:37*TILE+16};
}
function makeCrypt(w) {
  // Genuine room/corridor layout, with collision on every surrounding wall.
  rectTiles(w,0,0,WORLD_W,WORLD_H,'wall',true);
  const rooms=[[4,18,12,12],[21,18,11,12],[21,4,11,10],[39,4,18,14],[39,25,18,17]];
  for(const [x,y,ww,hh]of rooms)rectTiles(w,x,y,ww,hh,'floor');
  rectTiles(w,15,22,7,4,'floor');rectTiles(w,25,13,4,6,'floor');rectTiles(w,31,8,9,4,'floor');rectTiles(w,46,17,4,9,'floor');
  for(const [x,y]of [[5,20],[14,20],[22,20],[30,20],[22,6],[30,6],[40,6],[55,6],[40,27],[55,27],[40,39],[55,39]])put(w,'torch',x,y);
  for(const [x,y]of [[6,19],[13,19],[22,19],[30,28],[22,5],[40,5],[55,16],[40,26],[55,26]]){put(w,'pillar',x,y);obstacle(w,x,y);}
  for(const [x,y]of [[24,25],[27,23],[44,31],[51,36]]){put(w,'trap',x+.5,y+.5);w.interactables.push({id:`trap-${x}-${y}`,kind:'trap',name:'Armadilha de espinhos',x:(x+.5)*TILE,y:(y+.5)*TILE,radius:20});}
  put(w,'sarcophagus',26,7);obstacle(w,25,6,2,2);put(w,'bones',9,28);put(w,'bones',24,11);put(w,'bones',54,14);put(w,'bones',42,37);
  const enemies=[['goblin',12,24],['goblin',24,23],['skeleton',28,27],['skeleton',27,10],['goblin',43,11],['skeleton',51,14],['skeleton',45,29],['goblin',52,28],['boss',48,36]];
  for(const [kind,x,y]of enemies)enemy(w,kind,x,y,{boss:kind==='boss',name:kind==='boss'?'Rei Goblin':undefined});
  put(w,'chest',26,5,{id:'crypt-cache'});interact(w,'crypt-cache','chest','Tesouro da antessala',26,5);put(w,'chest',48,39,{id:'crypt-reward',bossLocked:true});interact(w,'crypt-reward','dungeonReward','Tesouro do Rei Goblin',48,39);
  portal(w,6,24,'fields','Retornar aos Campos');w.spawn={x:10*TILE+16,y:24*TILE+16};
}
function makeShadow(w) {
  pathTiles(w,5,34,31,34,3);pathTiles(w,31,12,31,34,3);pathTiles(w,31,12,54,12,3);rectTiles(w,37,25,18,13,'ash');
  // Shattered bridges over a magical rift.
  for(let y=4;y<43;y++){const x=22+Math.floor(Math.sin(y*.17)*2);rectTiles(w,x,y,4,1,'void',true);}rectTiles(w,19,32,10,4,'bridge');rectTiles(w,19,11,10,3,'bridge');
  for(let y=4;y<45;y+=3)for(let x=4;x<60;x+=3)if(w.tiles[y][x]==='grass'&&hash(x,y,41)>.5)tree(w,x,y,'dead',.9+hash(x,y)*.3);
  for(const [x,y]of [[14,27],[19,39],[30,29],[34,18],[43,18],[49,28],[41,36],[54,36],[56,13]]){put(w,'crystal',x+.5,y+.8,{color:hash(x,y)>.4?'#a38bc7':'#7fb3bb'});obstacle(w,x,y);}
  put(w,'ruin',43,12,{w:4*TILE,h:4*TILE});obstacle(w,43,9,4,3);put(w,'ruin',52,25,{w:3*TILE,h:4*TILE});obstacle(w,52,22,3,3);
  for(const [x,y]of [[39,28],[42,32],[51,32],[49,35],[43,35]]){put(w,'grave',x,y);obstacle(w,x,y);}
  for(const [kind,x,y]of [['corrupt',15,33],['corrupt',31,26],['skeleton',35,32],['corrupt',39,22],['skeleton',48,18],['corrupt',52,15],['boss',47,31]])enemy(w,kind,x,y,{boss:kind==='boss',name:kind==='boss'?'Arauto do Eclipse':undefined});
  put(w,'chest',55,36,{id:'shadow-chest'});interact(w,'shadow-chest','chest','Relíquia do Eclipse',55,36);portal(w,5,34,'forest','Floresta Sussurrante');w.spawn={x:10*TILE+16,y:34*TILE+16};
}
export function isBlocked(world,x,y,radius=10) {
  if(!Number.isFinite(x)||!Number.isFinite(y)||x-radius<0||y-radius<0||x+radius>=world.width||y+radius>=world.height)return true;
  const minX=Math.floor((x-radius)/TILE),maxX=Math.floor((x+radius)/TILE),minY=Math.floor((y-radius)/TILE),maxY=Math.floor((y+radius)/TILE);
  for(let yy=minY;yy<=maxY;yy++)for(let xx=minX;xx<=maxX;xx++)if(world.blocked.has(tileKey(xx,yy))) {
    // Circle versus tile, so actors can move naturally around corners.
    const nx=Math.max(xx*TILE,Math.min(x,(xx+1)*TILE)),ny=Math.max(yy*TILE,Math.min(y,(yy+1)*TILE));if((x-nx)**2+(y-ny)**2<=radius**2)return true;
  }
  return false;
}
export function findPath(world,from,to) {
  if(!from||!to)return [];
  const sx=Math.max(1,Math.min(WORLD_W-2,Math.floor(from.x/TILE))),sy=Math.max(1,Math.min(WORLD_H-2,Math.floor(from.y/TILE)));
  const gx=Math.max(1,Math.min(WORLD_W-2,Math.floor(to.x/TILE))),gy=Math.max(1,Math.min(WORLD_H-2,Math.floor(to.y/TILE)));
  const start=tileKey(sx,sy),open=[{x:sx,y:sy,g:0,f:0}],best=new Map([[start,0]]),parent=new Map(),closed=new Set();let goal=null,nearest=null,nearestDist=Infinity;
  while(open.length){open.sort((a,b)=>a.f-b.f);const n=open.shift(),k=tileKey(n.x,n.y);if(closed.has(k))continue;closed.add(k);const distance=Math.abs(gx-n.x)+Math.abs(gy-n.y);if(distance<nearestDist){nearestDist=distance;nearest=n;}
    if(n.x===gx&&n.y===gy){goal=n;break;}
    for(const [dx,dy]of [[0,1],[1,0],[0,-1],[-1,0]]){const x=n.x+dx,y=n.y+dy,key=tileKey(x,y);if(x<1||y<1||x>=WORLD_W-1||y>=WORLD_H-1||world.blocked.has(key)||closed.has(key))continue;const g=n.g+1;if(g>=(best.get(key)??Infinity))continue;best.set(key,g);parent.set(key,k);open.push({x,y,g,f:g+Math.abs(gx-x)+Math.abs(gy-y)});}
  }
  goal=goal||nearest;if(!goal)return [];
  let k=tileKey(goal.x,goal.y),result=[];while(k!==start){const [x,y]=k.split(',').map(Number);result.push({x:x*TILE+TILE/2,y:y*TILE+TILE/2});k=parent.get(k);if(!k)return [];}
  result.reverse();
  const center={x:sx*TILE+TILE/2,y:sy*TILE+TILE/2};
  if(Math.hypot(from.x-center.x,from.y-center.y)>.5)result.unshift(center);
  // Finish precisely only when the requested spot is reachable and clear.
  if(goal.x===gx&&goal.y===gy&&!isBlocked(world,to.x,to.y,10)&&(!result.length||Math.hypot(result.at(-1).x-to.x,result.at(-1).y-to.y)>.5))result.push({x:to.x,y:to.y});
  return result;
}
const groundCaches=new WeakMap();
function rect(ctx,color,x,y,w,h){ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function poly(ctx,color,points){ctx.fillStyle=color;ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fill();}
export function drawWorldGround(ctx,world,time=0,bounds=null) {
  let cache=groundCaches.get(world);
  if(!cache&&typeof document!=='undefined'){cache=document.createElement('canvas');cache.width=world.width;cache.height=world.height;const g=cache.getContext('2d');paintGround(g,world);groundCaches.set(world,cache);}
  if(cache)ctx.drawImage(cache,0,0);else paintGround(ctx,world,bounds);
  // The surface glints travel independently of the land texture.
  const minY=Math.max(0,Math.floor((bounds?.y||0)/TILE)),maxY=Math.min(WORLD_H,Math.ceil(((bounds?.y||0)+(bounds?.height||world.height))/TILE));
  const minX=Math.max(0,Math.floor((bounds?.x||0)/TILE)),maxX=Math.min(WORLD_W,Math.ceil(((bounds?.x||0)+(bounds?.width||world.width))/TILE));
  for(let y=minY;y<maxY;y++)for(let x=minX;x<maxX;x++){if(world.tiles[y][x]==='water'||world.tiles[y][x]==='void'){const f=hash(x,y,5),wave=Math.floor((time*.5+f*6)%6);if(wave<3){ctx.globalAlpha=.18+wave*.05;rect(ctx,world.tiles[y][x]==='void'?'#ac8dbd':'#b0d9c0',x*TILE+4+wave*2,y*TILE+6+Math.floor(f*17),9,1);ctx.globalAlpha=1;}}}
}
function paintGround(ctx,w){
  const p=w.palette;
  for(let y=0;y<WORLD_H;y++)for(let x=0;x<WORLD_W;x++){
    const type=w.tiles[y][x],xx=x*TILE,yy=y*TILE,r=hash(x,y,7);
    if(type==='grass'||type==='ash'||type==='moss'){
      rect(ctx,type==='ash'?'#4c4651':type==='moss'?'#4d6251':r>.6?p.grass2:p.grass,xx,yy,TILE,TILE);
      for(let i=0;i<7;i++){const a=hash(x*7+i,y,3),b=hash(x,y*7+i,5);rect(ctx,i%3===0?p.grassDark:p.grass2,xx+Math.floor(a*30),yy+Math.floor(b*30),i%2===0?3:1,1);if(i%2===0)rect(ctx,p.grassDark,xx+Math.floor(a*30)+1,yy+Math.floor(b*30)-2,1,2);}
    }else if(type==='dirt'){
      rect(ctx,p.dirt,xx,yy,TILE,TILE);for(let i=0;i<10;i++)rect(ctx,i%3===0?'#8d805a':p.dirtLight,xx+Math.floor(hash(x*11+i,y,10)*30),yy+Math.floor(hash(x,y*11+i,11)*30),i%4===0?4:2,1);
      // Uneven edges stop roads from looking like clean geometric slabs.
      for(const [dx,dy]of [[0,-1],[1,0],[0,1],[-1,0]])if(w.tiles[y+dy]?.[x+dx]==='grass')for(let i=0;i<5;i++){let e=3+Math.floor(hash(x+i,y,14)*25),len=2+Math.floor(hash(x,y+i,18)*5);rect(ctx,p.grass,xx+(dx===1?32-len:dx===-1?0:e),yy+(dy===1?32-len:dy===-1?0:e),dx?len:3,dy?len:3);}
    }else if(type==='cobble'){
      rect(ctx,'#69755f',xx,yy,TILE,TILE);
      for(let row=0;row<4;row++)for(let col=0;col<4;col++){
        const c=hash(x*4+col,y*4+row,20),ox=col*8+1,oy=row*8+1,sw=5+Math.floor(c*2),sh=5+Math.floor(hash(x+col,y+row,44)*2);
        poly(ctx,c>.7?'#adb19a':c>.35?'#9aa58d':'#8e9982',[[xx+ox+1,yy+oy],[xx+ox+sw-1,yy+oy],[xx+ox+sw,yy+oy+1],[xx+ox+sw,yy+oy+sh-1],[xx+ox+sw-1,yy+oy+sh],[xx+ox,yy+oy+sh],[xx+ox,yy+oy+1]]);
        rect(ctx,c>.5?'#b8bda1':'#aab598',xx+ox+1,yy+oy,sw-2,1);
        if(c>.91){rect(ctx,'#526c45',xx+ox-1,yy+oy+sh,3,1);rect(ctx,'#6f8654',xx+ox,yy+oy+sh-2,1,2);}
      }
    }else if(type==='water'||type==='void'){
      rect(ctx,type==='void'?'#29263d':p.waterDark,xx,yy,TILE,TILE);rect(ctx,type==='void'?'#3b3355':p.water,xx+1,yy+1,TILE-2,TILE-2);
      for(let i=0;i<3;i++)rect(ctx,type==='void'?'#5a496f':'#5d9d9f',xx+Math.floor(hash(x+i,y)*23),yy+6+i*9,8,1);
      if(w.tiles[y-1]?.[x]!=='water'&&w.tiles[y-1]?.[x]!=='void')rect(ctx,type==='void'?'#797084':'#779e83',xx,yy,32,3);
      if(w.tiles[y]?.[x-1]!==type)rect(ctx,type==='void'?'#65566f':'#71927a',xx,yy,3,32);
    }else if(type==='bridge'){
      rect(ctx,'#66583f',xx,yy,TILE,TILE);for(let n=0;n<4;n++){rect(ctx,'#ac8c5b',xx+n*8+1,yy+1,6,30);rect(ctx,'#c3a16b',xx+n*8+2,yy+1,1,30);rect(ctx,'#8b704e',xx+n*8+3,yy+4+Math.floor(hash(x+n,y)*15),2,9);}rect(ctx,'#635340',xx,yy+2,32,3);rect(ctx,'#b19a70',xx,yy+1,32,1);rect(ctx,'#635340',xx,yy+28,32,3);
    }else if(type==='farm'){
      rect(ctx,'#695a3e',xx,yy,TILE,TILE);for(let r=0;r<4;r++){rect(ctx,'#514a33',xx,yy+r*8,32,2);for(let j=0;j<4;j++){const ox=xx+j*8+4,oy=yy+r*8+5;rect(ctx,'#727e37',ox,oy-3,2,5);rect(ctx,'#9ca04b',ox-2,oy-4,2,2);rect(ctx,'#c2b463',ox+1,oy-6,2,4);}}
    }else if(type==='floor'){
      rect(ctx,'#3e4948',xx,yy,32,32);for(let i=0;i<4;i++){let ox=(i%2)*16,oy=Math.floor(i/2)*16;rect(ctx,hash(x*2+ox,y*2+oy)>.5?'#596461':'#525d59',xx+ox+1,yy+oy+1,14,14);rect(ctx,'#66716a',xx+ox+2,yy+oy+1,12,1);if(hash(x+i,y,11)>.8){rect(ctx,'#35443c',xx+ox+8,yy+oy+9,6,2);}}
    }else if(type==='wall'){
      rect(ctx,'#1f292c',xx,yy,32,32);
      if(w.tiles[y+1]?.[x]==='floor'){
        rect(ctx,'#444e4e',xx,yy-20,32,52);for(let r=0;r<5;r++)for(let j=0;j<3;j++){const ox=j*14-(r%2)*7;rect(ctx,r%2?'#59615b':'#62695f',xx+Math.max(0,ox),yy-18+r*10,Math.min(13,32-Math.max(0,ox)),8);}rect(ctx,'#8a8d77',xx,yy-20,32,3);rect(ctx,'#323c3d',xx,yy+27,32,5);
      }else if(w.tiles[y]?.[x+1]==='floor'||w.tiles[y]?.[x-1]==='floor'){rect(ctx,'#404c49',xx+2,yy,28,32);rect(ctx,'#6a7368',xx+2,yy,3,32);}
    }
  }
}
export function drawProp(ctx,p,time=0){
  ctx.save();ctx.translate(Math.round(p.x),Math.round(p.y));
  switch(p.type){
    case 'tree':drawTree(ctx,p);break;
    case 'building':drawBuilding(ctx,p,time);break;
    case 'fountain':drawFountain(ctx,time);break;
    case 'flowers':drawFlowers(ctx,p);break;
    case 'ash':rect(ctx,'#938aa1',0,0,2,1);rect(ctx,'#797185',4,2,1,1);break;
    case 'lamp':drawLamp(ctx,time);break;
    case 'banner':drawBanner(ctx,p,time);break;
    case 'bench':drawBench(ctx);break;
    case 'fence':drawFence(ctx,p);break;
    case 'portal':drawPortal(ctx,p,time);break;
    case 'reeds':drawReeds(ctx,p);break;
    case 'cart':drawCart(ctx);break;
    case 'windmill':drawWindmill(ctx,time);break;
    case 'stone':drawStone(ctx,p);break;
    case 'mushrooms':drawMushrooms(ctx);break;
    case 'ruin':drawRuin(ctx,p);break;
    case 'crystal':drawCrystal(ctx,p,time);break;
    case 'chest':drawChest(ctx,p);break;
    case 'sign':drawSign(ctx);break;
    case 'torch':drawTorch(ctx,time);break;
    case 'pillar':drawPillar(ctx);break;
    case 'trap':drawTrap(ctx,time);break;
    case 'sarcophagus':drawSarcophagus(ctx);break;
    case 'bones':drawBones(ctx);break;
    case 'grave':drawGrave(ctx);break;
  }
  ctx.restore();
}
function shadow(ctx,x,y,w,h,a=.22){ctx.save();ctx.globalAlpha=a;ctx.fillStyle='#172c27';ctx.beginPath();ctx.ellipse(x,y,w,h,0,0,Math.PI*2);ctx.fill();ctx.restore();}
function drawTree(ctx,p){
  ctx.scale(p.scale||1,p.scale||1);shadow(ctx,7,1,26,9,.23);
  if(p.variant==='dead'){
    poly(ctx,'#252f35',[[-4,0],[6,0],[5,-31],[13,-47],[11,-51],[3,-39],[0,-61],[-3,-63],[-3,-40],[-12,-49],[-18,-50],[-12,-43],[-6,-31]]);rect(ctx,'#56565b',0,-36,2,34);rect(ctx,'#6d6268',-1,-25,1,12);rect(ctx,'#605861',10,-47,2,6);return;
  }
  rect(ctx,'#504a35',-6,-35,12,34);rect(ctx,'#796545',-3,-35,4,33);rect(ctx,'#a0814e',-2,-25,2,20);rect(ctx,'#3e4530',3,-31,3,30);poly(ctx,'#4f4d33',[[-10,1],[-3,-7],[5,-7],[11,1]]);
  if(p.variant==='pine'){
    poly(ctx,'#1f453b',[[-30,-15],[-14,-34],[-24,-32],[-9,-52],[-17,-49],[0,-83],[17,-49],[9,-52],[24,-32],[14,-34],[30,-15]]);
    poly(ctx,'#315d47',[[-24,-21],[-7,-39],[-18,-36],[-3,-57],[-10,-54],[0,-77],[9,-54],[3,-55],[18,-37],[8,-39],[24,-22]]);
    poly(ctx,'#477653',[[-19,-23],[-5,-39],[-10,-37],[0,-57],[1,-47],[13,-37],[7,-38],[19,-23]]);rect(ctx,'#659160',-1,-69,2,9);rect(ctx,'#65895b',-12,-31,7,2);return;
  }
  const seed=p.seed||0;
  poly(ctx,'#2b5136',[[-34,-31],[-38,-42],[-30,-55],[-31,-63],[-21,-70],[-10,-73],[-5,-80],[8,-79],[14,-72],[26,-70],[31,-60],[36,-53],[34,-40],[27,-31],[12,-25],[-14,-26]]);
  poly(ctx,'#3e693e',[[-32,-39],[-33,-49],[-24,-58],[-24,-65],[-12,-67],[-5,-75],[7,-74],[12,-67],[24,-65],[27,-55],[32,-49],[28,-39],[15,-34],[-10,-33]]);
  poly(ctx,'#527e44',[[-29,-45],[-21,-53],[-23,-59],[-12,-64],[-2,-70],[5,-69],[9,-61],[19,-62],[25,-54],[22,-46],[11,-42],[5,-45],[-8,-41],[-18,-43]]);
  poly(ctx,'#68904e',[[-22,-54],[-14,-59],[-12,-64],[-2,-68],[4,-65],[2,-59],[11,-55],[6,-50],[-3,-52],[-12,-48]]);
  for(let i=0;i<23;i++){let x=hash(i,Math.floor(seed*1000),4)*58-29,y=hash(i,5,Math.floor(seed*100)) *38-69;rect(ctx,i%3===0?'#86a15b':'#365b3a',x,y,3+hash(i,9)*4,2);}
  rect(ctx,'#315638',-18,-31,12,3);rect(ctx,'#315638',14,-33,6,3);
}
function drawBuilding(ctx,p,time){
  const w=p.w,h=p.h,roof=p.roof||'#9e6045',frontH=37,roofHeight=45;
  shadow(ctx,w/2+10,0,w*.59,14,.22);
  // Warm plaster walls, timber posts, raised stone foundation.
  rect(ctx,'#716e59',0,-h-25,w,h+25);rect(ctx,'#c4ba91',4,-h-25,w-8,h+20);rect(ctx,'#a89d78',4,-30,w-8,27);
  rect(ctx,'#66705e',-3,-9,w+6,9);rect(ctx,'#94927a',-3,-9,w+6,2);
  for(let xx=2;xx<w;xx+=31){rect(ctx,'#67523a',xx,-h-25,5,h+18);rect(ctx,'#8c6d48',xx+1,-h-25,1,h+16);}
  rect(ctx,'#6c573b',0,-h/2-17,w,5);rect(ctx,'#806342',0,-h-25,w,5);
  // Stone outlined entrance and door. Roof back edge attaches to rear wall.
  const doorX=w*.5-13;rect(ctx,'#6c654f',doorX-4,-43,34,36);rect(ctx,'#493f30',doorX,-41,26,34);rect(ctx,'#76583b',doorX+2,-38,22,31);rect(ctx,'#9c7950',doorX+4,-37,2,28);
  for(let dx=8;dx<22;dx+=7)rect(ctx,'#503f2e',doorX+dx,-36,1,28);rect(ctx,'#c3aa66',doorX+19,-22,3,3);rect(ctx,'#a5a083',doorX-6,-7,38,6);rect(ctx,'#c0b796',doorX-9,-2,44,3);
  for(let xx=16;xx<w-16;xx+=45){if(Math.abs(xx-w/2)<23)continue;drawWindow(ctx,xx,-h/2-4,time);}
  if(p.style==='tavern'||p.style==='guild'){drawWindow(ctx,w*.24,-h+1,time);drawWindow(ctx,w*.73,-h+1,time);}
  const roofBottom=-h+12;
  poly(ctx,'#4c4436',[[-12,roofBottom],[w*.5,-h-roofHeight],[w+12,roofBottom],[w+12,roofBottom+7],[-12,roofBottom+7]]);
  poly(ctx,roof,[[-8,roofBottom],[w*.5,-h-roofHeight+5],[w+8,roofBottom]]);
  const rgb=roof==='#526c80'?['#5c7c8e','#446071','#77939e']:roof==='#576a73'?['#667a7d','#47575c','#89918a']:['#ae7353','#80513e','#c38e64'];
  for(let row=0;row<7;row++){
    let yy=-h-roofHeight+10+row*8,half=(row+1)/7*(w*.5+9);
    for(let xx=w*.5-half;xx<w*.5+half-3;xx+=13){rect(ctx,row%2?rgb[0]:roof,xx+((row%2)*5),yy,11,5);rect(ctx,rgb[1],xx+((row%2)*5),yy+5,11,1);if((Math.floor(xx)+row)%3===0)rect(ctx,rgb[2],xx+((row%2)*5),yy,8,1);}
  }
  rect(ctx,'#bea57a',-10,roofBottom+1,w+20,3);rect(ctx,'#66503b',-10,roofBottom+4,w+20,5);
  // Chimney and drifting forge smoke.
  rect(ctx,'#777666',w*.79,-h-roofHeight+2,17,37);rect(ctx,'#a2a086',w*.79-2,-h-roofHeight,21,5);for(let yy=0;yy<4;yy++)rect(ctx,'#5e635b',w*.79+3+(yy%2)*4,-h-roofHeight+9+yy*7,9,1);
  if(p.style==='forge'||p.style==='tavern'){for(let i=0;i<3;i++){ctx.globalAlpha=.15-i*.035;rect(ctx,'#cdd0b1',w*.79+3+Math.sin(time*.5+i)*5,-h-roofHeight-8-i*9-(time*4%9),9+i*4,7+i*2);}ctx.globalAlpha=1;}
  if(p.style==='guild'){
    rect(ctx,'#476b7f',14,-h/2-1,13,31);poly(ctx,'#476b7f',[[14,-h/2+30],[20,-h/2+36],[27,-h/2+30]]);rect(ctx,'#c8ae70',19,-h/2+7,3,14);rect(ctx,'#e1cf8e',16,-h/2+11,9,3);
  }
  if(p.style==='forge'){
    rect(ctx,'#4d4839',w-41,-24,28,9);poly(ctx,'#9a9c91',[[w-45,-26],[w-9,-26],[w-18,-20],[w-31,-20],[w-32,-14],[w-38,-14]]);rect(ctx,'#b7baa7',w-43,-27,29,2);rect(ctx,'#3b3c32',w-33,-14,14,7);
    rect(ctx,'#403c30',8,-29,23,20);rect(ctx,'#ac6437',11,-26,17,14);rect(ctx,'#e7b86a',15,-24,8,10);
  }
  if(p.style==='market'){
    const ay=-37;rect(ctx,'#5b4b33',-11,ay+4,3,36);rect(ctx,'#5b4b33',w+7,ay+4,3,36);for(let i=0;i<8;i++){const sw=(w+25)/8;poly(ctx,i%2?'#d1b789':'#8c7b4c',[[-12+i*sw,ay-13],[-12+(i+1)*sw,ay-13],[-10+(i+1)*sw,ay+5],[-10+i*sw,ay+5]]);rect(ctx,i%2?'#bfa87a':'#716341',-10+i*sw,ay+5,sw-1,5);}
    rect(ctx,'#715436',4,-13,w-7,15);rect(ctx,'#a58353',1,-17,w,6);for(let i=0;i<9;i++)rect(ctx,i%3===0?'#a25c41':i%3===1?'#c5b76b':'#7d9653',10+i*18,-23,11,7);
  }
  // Readable signs are kept short; UI can supply full interaction names.
  if(p.name){ctx.fillStyle='#63503a';ctx.fillRect(w/2-37,-h/2-24,74,14);ctx.fillStyle='#d6bc7f';ctx.font='bold 6px monospace';ctx.textAlign='center';const name=p.style==='guild'?'GUILDA':p.style==='tavern'?'TAVERNA':p.style==='forge'?'FERREIRO':'MERCADO';ctx.fillText(name,w/2,-h/2-15);}
  for(const xx of [5,w-6]){rect(ctx,'#50633b',xx-4,-9,12,9);rect(ctx,'#9e7b50',xx-3,-5,10,5);rect(ctx,'#75924f',xx-5,-15,8,8);rect(ctx,'#8ca656',xx,-13,8,6);rect(ctx,'#c49275',xx+1,-17,3,3);}
}
function drawWindow(ctx,x,y,time){rect(ctx,'#6d5d41',x-10,y-19,22,22);rect(ctx,'#453e30',x-7,y-17,16,17);rect(ctx,'#c0a268',x-5,y-15,12,13);rect(ctx,'#e2c78a',x-4,y-14,6,11);rect(ctx,'#796345',x,y-16,2,15);rect(ctx,'#796345',x-6,y-8,15,2);rect(ctx,'#ddc293',x-11,y+2,24,3);rect(ctx,'#5b5038',x-14,y-17,3,21);rect(ctx,'#5b5038',x+13,y-17,3,21);}
function drawFountain(ctx,time){
  shadow(ctx,3,2,52,20,.24);ctx.fillStyle='#747f76';ctx.beginPath();ctx.ellipse(0,-4,50,22,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#adb39b';ctx.beginPath();ctx.ellipse(0,-10,49,21,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#5c8280';ctx.beginPath();ctx.ellipse(0,-10,41,15,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#79b0ab';ctx.beginPath();ctx.ellipse(0,-12,38,13,0,0,Math.PI*2);ctx.fill();
  rect(ctx,'#6d837b',-8,-46,16,35);rect(ctx,'#a4af97',-6,-45,9,34);rect(ctx,'#c7ccb3',-5,-45,3,33);ctx.fillStyle='#8d9c8c';ctx.beginPath();ctx.ellipse(0,-45,25,10,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#bec6a7';ctx.beginPath();ctx.ellipse(0,-49,25,9,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#7bb6ad';ctx.beginPath();ctx.ellipse(0,-50,20,6,0,0,Math.PI*2);ctx.fill();
  rect(ctx,'#8d9e8b',-4,-68,8,19);rect(ctx,'#d2d4ae',-2,-70,4,21);for(let i=0;i<5;i++){const x=-19+i*10,d=Math.floor((time*24+i*9)%29);rect(ctx,'#b4d9c6',x,-44+d,2,5);rect(ctx,'#90cbc0',x+2,-43+d,1,7);}for(let i=0;i<8;i++){const x=Math.sin(i*4.2)*32,y=-10+Math.cos(i*2.7)*9;rect(ctx,'#b6d5bc',x+Math.sin(time*2+i)*3,y,7,1);}rect(ctx,'#bcc5aa',-38,4,17,2);rect(ctx,'#bcc5aa',25,4,14,2);
}
function drawFlowers(ctx,p){const seed=p.seed||0;const colors=p.dark?['#a1b3b0','#b995a8','#8eae87']:['#c5b25f','#d4cfab','#c79993'];for(let i=0;i<3;i++){const x=Math.floor(hash(i,Math.floor(seed*1000),1)*15)-7,y=Math.floor(hash(i,2,Math.floor(seed*50))*8);rect(ctx,'#3c643b',x,y-3,1,4);rect(ctx,colors[Math.floor(seed*3)%3],x-1,y-4,3,2);}}
function drawLamp(ctx,time){shadow(ctx,1,0,10,3,.18);rect(ctx,'#4f4b38',-2,-49,4,49);rect(ctx,'#8d7e52',-1,-47,1,45);rect(ctx,'#49503e',-7,-56,14,4);rect(ctx,'#d2b377',-5,-52,10,12);rect(ctx,'#f1d79a',-3,-51,6,9);rect(ctx,'#5b5942',-7,-41,14,3);rect(ctx,'#655e41',-2,-62,4,6);ctx.globalAlpha=.05+Math.sin(time*3)*.01;ctx.fillStyle='#ffe1a3';ctx.beginPath();ctx.arc(0,-47,33,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
function drawBanner(ctx,p,time){shadow(ctx,1,0,9,3,.2);rect(ctx,'#6c5a3e',-2,-65,4,65);rect(ctx,'#b59d6d',-1,-65,1,62);rect(ctx,'#bd9d61',-5,-69,10,5);rect(ctx,'#9b8557',-2,-64,31,3);const shift=Math.floor(Math.sin(time*1.7)*2);poly(ctx,p.color||'#506f84',[[3,-60],[27+shift,-60],[26+shift,-29],[15+shift,-21],[3,-28]]);rect(ctx,'#b7a36b',5,-59,2,28);rect(ctx,'#cfb974',12+shift,-49,9,3);rect(ctx,'#cfb974',15+shift,-52,3,15);}
function drawBench(ctx){shadow(ctx,4,2,23,5,.18);rect(ctx,'#5e4c34',-19,-19,3,20);rect(ctx,'#5e4c34',17,-19,3,20);rect(ctx,'#a58c59',-21,-20,43,4);rect(ctx,'#846c47',-21,-14,43,4);rect(ctx,'#b49a64',-22,-8,45,5);rect(ctx,'#584f36',-17,-3,4,5);rect(ctx,'#584f36',16,-3,4,5);}
function drawFence(ctx,p){rect(ctx,'#716147',0,-23,4,27);rect(ctx,'#b29b6b',1,-24,2,25);rect(ctx,'#947d56',2,-17,29,4);rect(ctx,'#b49d6a',2,-17,29,1);rect(ctx,'#806a4a',2,-6,29,4);rect(ctx,'#a98c5c',2,-6,29,1);}
function drawPortal(ctx,p,time){
  shadow(ctx,0,3,30,11,.18);ctx.strokeStyle='#96a78e';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,0,25,9,0,0,Math.PI*2);ctx.stroke();ctx.strokeStyle='#c2b887';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,0,20,6,0,0,Math.PI*2);ctx.stroke();
  for(let i=0;i<8;i++){let phase=(time*.5+i/8)%1,x=Math.sin(i*5+time*.4)*18,y=-phase*41;ctx.globalAlpha=(1-phase)*.7;rect(ctx,p.to==='shadow'?'#b9a5dc':'#b7d5b0',x,y,2,3);}ctx.globalAlpha=1;
  rect(ctx,'#5b6755',-29,-27,7,28);rect(ctx,'#8c9c79',-28,-27,3,25);rect(ctx,'#b5b38c',-30,-30,9,4);rect(ctx,'#5b6755',22,-27,7,28);rect(ctx,'#8c9c79',23,-27,3,25);rect(ctx,'#b5b38c',21,-30,9,4);
}
function drawReeds(ctx,p){for(let i=0;i<6;i++){let h=5+hash(i,Math.floor(p.seed*100))*10,x=i*3;rect(ctx,'#53704c',x,-h,1,h);rect(ctx,'#75905b',x+1,-h+3,1,h-3);rect(ctx,'#9c9160',x,-h-2,2,3);}}
function drawCart(ctx){shadow(ctx,3,4,33,10,.24);rect(ctx,'#433e2e',-26,-7,8,14);rect(ctx,'#433e2e',24,-7,8,14);rect(ctx,'#aaa17b',-25,-5,6,10);rect(ctx,'#aaa17b',25,-5,6,10);rect(ctx,'#6d573b',-27,-24,58,20);for(let y=-23;y<-5;y+=6){rect(ctx,'#a88a56',-26,y,56,4);rect(ctx,'#b69a65',-25,y,54,1);}rect(ctx,'#7c6947',-20,-37,15,14);rect(ctx,'#b79c64',-18,-35,11,10);rect(ctx,'#89905b',0,-31,17,9);rect(ctx,'#536944',3,-37,13,9);rect(ctx,'#7f6243',30,-9,34,3);}
function drawWindmill(ctx,time){shadow(ctx,4,3,33,12,.22);poly(ctx,'#b2ac86',[[-22,0],[23,0],[14,-83],[-13,-83]]);rect(ctx,'#786b4b',-7,-26,15,26);poly(ctx,'#6e513c',[[-20,-78],[0,-105],[20,-78]]);rect(ctx,'#665a40',-3,-80,6,6);ctx.save();ctx.translate(0,-77);ctx.rotate(time*.22);for(let i=0;i<4;i++){ctx.rotate(Math.PI/2);rect(ctx,'#685b3f',-2,0,4,65);rect(ctx,'#d2c69d',2,15,13,46);for(let y=19;y<60;y+=9)rect(ctx,'#9e9269',2,y,13,2);}ctx.restore();rect(ctx,'#b5a778',-4,-81,8,8);}
function drawStone(ctx,p){shadow(ctx,2,1,p.large?30:15,6,.2);const k=p.large?1.6:1;ctx.scale(k,k);poly(ctx,'#6b796d',[[-17,-1],[-20,-10],[-11,-23],[4,-27],[17,-17],[22,-3]]);poly(ctx,'#969e85',[[-18,-10],[-10,-21],[4,-24],[15,-16],[4,-12]]);poly(ctx,'#7c8975',[[-17,-9],[5,-12],[16,-16],[20,-4],[-14,-2]]);rect(ctx,'#536b4c',-13,-3,8,2);rect(ctx,'#a9ad91',-7,-20,9,2);}
function drawMushrooms(ctx){for(const [x,y,s]of [[-5,0,1],[7,2,.8],[2,-5,.6]]){rect(ctx,'#b6b193',x,y-7*s,2,8*s);poly(ctx,'#a9766f',[[x-6*s,y-6*s],[x-5*s,y-11*s],[x,y-14*s],[x+6*s,y-11*s],[x+7*s,y-6*s]]);rect(ctx,'#d4c6aa',x-2*s,y-11*s,2,2);}}
function drawRuin(ctx,p){shadow(ctx,p.w/2,0,p.w*.6,12,.25);const heights=[p.h*.8,p.h,p.h*.65,p.h*.9];for(let x=0;x<p.w;x+=24){let h=heights[Math.floor(x/24)%4];rect(ctx,'#444e4e',x,-h,23,h);rect(ctx,'#738074',x+2,-h+2,19,h-3);for(let y=-h+8;y<-5;y+=11){rect(ctx,'#46534b',x+1,y,22,2);rect(ctx,'#54645a',x+11+(Math.floor(y)%2)*5,y-9,1,9);}rect(ctx,'#8f9b82',x,-h,23,3);rect(ctx,'#3c5d45',x+3,-15,8,15);}rect(ctx,'#65825a',4,-p.h*.6,3,p.h*.6);for(let i=0;i<9;i++)rect(ctx,'#59794f',5+Math.sin(i)*6,-i*7,7,3);}
function drawCrystal(ctx,p,time){shadow(ctx,2,1,15,5,.28);const color=p.color||'#b39ad3';poly(ctx,'#4c4567',[[-11,0],[-15,-11],[-8,-32],[-4,-14],[1,-48],[8,-56],[17,-41],[13,-2]]);poly(ctx,color,[[-8,-1],[-11,-12],[-7,-28],[-2,-10],[3,-45],[8,-52],[12,-39],[9,-3]]);poly(ctx,'#d1c7df',[[3,-45],[8,-52],[8,-9],[3,-5]]);rect(ctx,'#ece1ed',7,-43,2,15);ctx.globalAlpha=.08+Math.sin(time*1.7)*.025;ctx.fillStyle=color;ctx.beginPath();ctx.arc(4,-20,44,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
function drawChest(ctx,p){shadow(ctx,1,2,18,5,.2);rect(ctx,'#564830',-15,-18,30,20);rect(ctx,p.open?'#726342':'#a3844c',-13,-16,26,16);rect(ctx,'#d0b472',-15,-7,30,3);rect(ctx,'#c6a65b',-11,-17,3,18);rect(ctx,'#c6a65b',8,-17,3,18);rect(ctx,'#3c3b2a',-3,-7,7,6);rect(ctx,'#dec57b',-2,-7,5,3);if(!p.open){poly(ctx,'#c19a58',[[-15,-18],[-11,-24],[10,-24],[15,-18]]);rect(ctx,'#d1b274',-11,-24,21,2);}else{rect(ctx,'#78603c',-14,-28,28,8);rect(ctx,'#3e3529',-11,-18,23,6);}}
function drawSign(ctx){rect(ctx,'#5e5138',-2,-28,4,29);rect(ctx,'#ac9464',-21,-33,42,13);rect(ctx,'#c1a574',-20,-32,39,2);rect(ctx,'#63563b',-15,-28,24,2);poly(ctx,'#63563b',[[8,-31],[14,-27],[8,-23]]);}
function drawTorch(ctx,time){rect(ctx,'#3b3a2f',-3,-21,6,22);rect(ctx,'#807453',-2,-20,3,18);const f=Math.sin(time*11)*2;poly(ctx,'#ce7842',[[-5,-20],[-7,-27],[-2,-40+f],[2,-34],[6,-28],[4,-20]]);poly(ctx,'#eebc6b',[[-3,-23],[-3,-31],[0,-36+f],[3,-27],[1,-22]]);rect(ctx,'#f5dda0',-1,-29,2,7);ctx.globalAlpha=.06;ctx.fillStyle='#ffc47c';ctx.beginPath();ctx.arc(0,-26,55,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
function drawPillar(ctx){shadow(ctx,3,0,22,7,.2);rect(ctx,'#414b49',-15,-57,30,57);rect(ctx,'#7e8878',-12,-55,25,52);rect(ctx,'#9aa38c',-10,-54,5,51);rect(ctx,'#616e60',6,-53,5,50);for(let y=-44;y<0;y+=12)rect(ctx,'#4f5a50',-12,y,25,2);rect(ctx,'#a8ad94',-17,-62,35,6);rect(ctx,'#566156',-17,-5,35,7);rect(ctx,'#89927b',-17,-5,35,2);}
function drawTrap(ctx,time){rect(ctx,'#333f3d',-14,-5,28,10);for(let i=0;i<5;i++)poly(ctx,'#929988',[[-12+i*5,-1],[-10+i*5,-8],[-8+i*5,-1]]);rect(ctx,'#6a7468',-15,3,30,2);}
function drawSarcophagus(ctx){shadow(ctx,1,2,33,9,.3);rect(ctx,'#3d4947',-25,-45,50,48);rect(ctx,'#828d7c',-24,-45,46,42);rect(ctx,'#9aa28b',-24,-45,46,4);rect(ctx,'#5f6f62',-17,-37,32,31);rect(ctx,'#acb49b',-4,-35,8,8);rect(ctx,'#8b9a85',-6,-27,12,19);rect(ctx,'#a6ac8e',-12,-21,25,4);rect(ctx,'#666d5d',-22,-4,44,5);}
function drawBones(ctx){rect(ctx,'#b6baa1',-9,-4,18,3);rect(ctx,'#999f89',-8,-7,3,8);rect(ctx,'#b6baa1',6,-6,3,7);rect(ctx,'#c3c5a8',3,-12,8,7);rect(ctx,'#3a4641',4,-10,2,2);rect(ctx,'#3a4641',8,-10,2,2);}
function drawGrave(ctx){shadow(ctx,2,1,14,5,.3);poly(ctx,'#535964',[[-12,1],[-12,-28],[-7,-36],[7,-36],[12,-28],[12,1]]);poly(ctx,'#7d7a80',[[-9,-1],[-9,-27],[-5,-32],[5,-32],[9,-27],[9,-1]]);rect(ctx,'#ada2a4',-1,-27,2,14);rect(ctx,'#ada2a4',-5,-22,10,2);rect(ctx,'#4e5d4b',-10,-3,20,4);}
