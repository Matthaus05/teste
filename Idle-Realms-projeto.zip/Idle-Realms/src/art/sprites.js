/**
 * Idle Realms original pixel art. Every sheet is rasterised from articulated
 * directional poses; equipment shares those poses, never a translated still.
 * All artwork in this module is original to this project (see ART-LICENSE.md).
 */
export const SPRITE_META = Object.freeze({
  width: 80, height: 80, anchorX: 40, anchorY: 64, frames: 8,
  directions: ['down', 'up', 'left', 'right'],
  states: ['idle', 'walk', 'run', 'attack', 'cast', 'hurt', 'death', 'dodge'],
});

const C = {
  ink: '#17242c', deep: '#23343b', steel: '#687e86', light: '#c1d7d7', shine: '#f0ead3',
  gold: '#d4a34f', goldDark: '#825f36', goldLight: '#f8dc8b',
  violet: '#7770aa', violetLight: '#b1acd9', purple: '#4b426c',
  leaf: '#657f50', leafLight: '#a1b57a', leafDark: '#354c39',
  red: '#ae6050', redDark: '#693e3e', cloth: '#d8c5a0', brown: '#76533d',
  brownDark: '#453a31', magic: '#7fe4d8', magicDark: '#397b88',
  skin: ['#d8a783', '#9c684e', '#bc8b60'], skinShade: ['#a36f53', '#704737', '#8b613f'],
  hair: ['#513b2e', '#c5a36b', '#d3d9d7'],
};

const palettes = {
  warrior: [C.steel, '#41545f', C.light],
  knight: ['#87969a', '#526371', '#d0dcda'],
  mage: ['#7770aa', '#474064', '#b4abdc'],
  archer: ['#738957', '#3e5943', '#b2c383'],
  rogue: ['#627184', '#323f50', '#9eaebd'],
  monk: ['#c18a55', '#82573e', '#edc48c'],
};
const cache = new Map();
const clampTier = n => Math.max(0, Math.min(2, Number(n) || 0));
function canvas(w, h) {
  if (typeof document !== 'undefined') {
    const c = document.createElement('canvas'); c.width = w; c.height = h; return c;
  }
  if (typeof OffscreenCanvas !== 'undefined') return new OffscreenCanvas(w, h);
  throw new Error('A Canvas implementation is required to rasterise sprite sheets.');
}
function r(ctx, x, y, w, h, color) {
  ctx.fillStyle = color; ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}
function line(ctx, x0, y0, x1, y1, color, thickness = 1) {
  x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
  const dx = Math.abs(x1-x0), sx = x0<x1 ? 1 : -1, dy = -Math.abs(y1-y0), sy = y0<y1 ? 1 : -1;
  let err = dx+dy;
  for (;;) {
    r(ctx,x0,y0,thickness,thickness,color);
    if(x0===x1 && y0===y1) break;
    const e2=2*err;
    if(e2>=dy){err+=dy;x0+=sx;}
    if(e2<=dx){err+=dx;y0+=sy;}
  }
}
/** Integer scan conversion keeps sloping edges crisp at every native pixel. */
function poly(ctx, points, color) {
  const ys=points.map(p=>p[1]), low=Math.ceil(Math.min(...ys)), high=Math.floor(Math.max(...ys));
  for(let y=low;y<=high;y++){
    const xs=[];
    for(let i=0;i<points.length;i++){
      const a=points[i],b=points[(i+1)%points.length];
      if((a[1]<=y && b[1]>y)||(b[1]<=y && a[1]>y)) xs.push(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]));
    }
    xs.sort((a,b)=>a-b);
    for(let i=0;i<xs.length;i+=2) if(xs[i+1]!==undefined) r(ctx,Math.ceil(xs[i]),y,Math.floor(xs[i+1])-Math.ceil(xs[i])+1,1,color);
  }
}
function oval(ctx,x,y,rx,ry,color){
  for(let dy=-ry;dy<=ry;dy++){
    const dx=Math.floor(rx*Math.sqrt(Math.max(0,1-dy*dy/(ry*ry))));
    r(ctx,x-dx,y+dy,dx*2+1,1,color);
  }
}
function outlined(ctx,points,fill){poly(ctx,points,C.ink); const cx=points.reduce((s,p)=>s+p[0],0)/points.length,cy=points.reduce((s,p)=>s+p[1],0)/points.length; poly(ctx,points.map(([x,y])=>[x+(x<cx?1:x>cx?-1:0),y+(y<cy?1:y>cy?-1:0)]),fill);}
function armorPalette(classId,tier){
  if(tier===1) return ['#b8995d','#746040','#ead49a'];
  if(tier===2) return ['#5f777d','#344d59','#a4d1ca'];
  return palettes[classId]||palettes.warrior;
}
function leg(ctx, x, hipY, swing, side, colors, bare=false, run=false, cross=0) {
  const lift=Math.max(0, swing), footY=-Math.round(lift*(run?4:2)), kneeX=x+Math.round(swing*(side?4:1)+cross*(side?2:1));
  const footX=x+Math.round(swing*(side?(run?6:4):2));
  line(ctx,x,hipY,kneeX,-5-lift*2,C.ink,4);
  line(ctx,x+1,hipY,kneeX+1,-5-lift*2,colors[1],2);
  line(ctx,kneeX,-5-lift*2,footX,footY-2,C.ink,3);
  line(ctx,kneeX+1,-5-lift*2,footX+1,footY-2,bare?C.skin[0]:colors[0],1);
  r(ctx,footX-1,footY-3,5,3,C.brownDark);r(ctx,footX,footY-3,3,1,bare?C.cloth:colors[2]);
  if(!side) r(ctx,footX-1,footY,5,1,C.ink);
}
function blade(ctx,handX,handY,angle,tier,classId='warrior'){
  const length=classId==='rogue'?9:classId==='knight'?15:17;
  const len=length+tier*2,dx=Math.cos(angle),dy=Math.sin(angle);
  const tipX=handX+dx*len,tipY=handY+dy*len,px=-dy,py=dx;
  line(ctx,handX-dx*3,handY-dy*3,handX,handY,C.brownDark,2);
  line(ctx,handX+px*3,handY+py*3,handX-px*3,handY-py*3,tier===2?C.magic:C.gold,1);
  poly(ctx,[[handX+dx,handY+dy],[handX+dx*4+px*2,handY+dy*4+py*2],[tipX,tipY],[handX+dx*4-px*2,handY+dy*4-py*2]],C.ink);
  line(ctx,handX+dx*3,handY+dy*3,tipX-dx,tipY-dy,tier===2?C.magic:tier===1?C.goldLight:C.light,2);
  line(ctx,handX+dx*3-px,handY+dy*3-py,tipX-dx,tipY-dy,C.shine,1);
  if(tier===1){line(ctx,handX+dx*5+px*2,handY+dy*5+py*2,handX+dx*8+px*2,handY+dy*8+py*2,C.gold,1);}
  if(tier===2){r(ctx,tipX+px*3,tipY+py*3,1,1,C.magic);r(ctx,handX+dx*7-px*3,handY+dy*7-py*3,1,2,C.magic);}
}
function staff(ctx,x,y,tier,attack){
  const topY=y-22+(attack?2:0);
  line(ctx,x,y+5,x,topY,C.ink,3);line(ctx,x+1,y+4,x+1,topY+2,tier===1?C.gold:C.brown,1);
  if(tier===0){line(ctx,x-3,topY+3,x-4,topY-2,C.gold);line(ctx,x+3,topY+3,x+4,topY-2,C.gold);oval(ctx,x+1,topY,3,3,C.magicDark);r(ctx,x,topY-2,2,3,C.magic);}
  if(tier===1){poly(ctx,[[x,topY-6],[x+5,topY],[x,topY+6],[x-4,topY]],C.ink);poly(ctx,[[x,topY-5],[x+3,topY],[x,topY+4],[x-2,topY]],C.violetLight);r(ctx,x,topY-3,1,4,C.shine);}
  if(tier===2){poly(ctx,[[x,topY-6],[x+4,topY],[x,topY+5],[x-3,topY]],C.magic);line(ctx,x-6,topY+2,x-5,topY-3,C.gold);line(ctx,x+6,topY+2,x+5,topY-3,C.gold);line(ctx,x-5,topY+3,x+5,topY+3,C.gold);r(ctx,x,topY-5,1,3,C.shine);}
}
function bow(ctx,x,y,tier,attack,phase){
  const bend=3+tier, draw=attack?Math.sin(phase*Math.PI)*4:0;
  const wood=tier===2?C.magic:tier===1?C.gold:C.brown;
  const pts=[[x-1,y-12],[x+bend,y-8],[x+bend+1,y],[x+bend,y+8],[x-1,y+12]];
  for(let i=0;i<pts.length-1;i++) {line(ctx,...pts[i],...pts[i+1],C.ink,2);line(ctx,pts[i][0],pts[i][1],pts[i+1][0],pts[i+1][1],wood);}
  line(ctx,x-1,y-12,x-draw,y,C.cloth);line(ctx,x-draw,y,x-1,y+12,C.cloth);
  if(attack){line(ctx,x-draw,y,x+9,y,C.light);poly(ctx,[[x+10,y],[x+6,y-2],[x+6,y+3]],C.light);}
  if(tier>0){r(ctx,x+2,y-9,2,2,C.goldLight);r(ctx,x+2,y+8,2,2,C.goldLight);}
}
function shield(ctx,x,y,tier){
  const w=tier===2?7:6;
  outlined(ctx,[[x-w,y-8],[x+w,y-8],[x+w,y+1],[x,y+8],[x-w,y+1]],tier===1?C.goldDark:tier===2?C.magicDark:C.steel);
  line(ctx,x-w+2,y-6,x+w-2,y-6,tier===2?C.magic:C.light);
  line(ctx,x,y-6,x,y+4,tier===1?C.goldLight:C.light);line(ctx,x-3,y-1,x+3,y-1,tier===1?C.goldLight:C.light);
  if(tier===2){poly(ctx,[[x,y-5],[x+3,y-1],[x,y+4],[x-3,y-1]],C.magic);r(ctx,x,y-2,1,2,C.shine);}
}
function face(ctx,classId,dir,skin,hair,headY,armor,blink=false){
  const side=dir==='left'||dir==='right',back=dir==='up',sk=C.skin[skin],shade=C.skinShade[skin],ha=C.hair[hair];
  // Every class gets a different head covering and silhouette.
  if(classId==='knight'){
    outlined(ctx,[[-5,headY+2],[-4,headY-4],[0,headY-6],[5,headY-4],[6,headY+3],[3,headY+6],[-3,headY+6]],armorPalette(classId,armor)[0]);
    line(ctx,-3,headY-3,3,headY-3,C.light);line(ctx,0,headY-5,0,headY+4,C.light);
    if(!back){r(ctx,side?1:-4,headY,side?4:9,2,C.ink);r(ctx,side?3:-3,headY,side?1:2,1,C.magic);r(ctx,3,headY,1,1,C.magic);r(ctx,-2,headY+3,1,2,C.deep);r(ctx,2,headY+3,1,2,C.deep);}
    if(armor===0){r(ctx,-1,headY-9,3,4,C.redDark);r(ctx,0,headY-10,4,2,C.red);}
    if(armor===1){line(ctx,-5,headY-4,-9,headY-8,C.gold,2);line(ctx,5,headY-4,9,headY-8,C.gold,2);}
    if(armor===2){poly(ctx,[[-4,headY-4],[-8,headY-10],[-7,headY-2]],C.magicDark);poly(ctx,[[4,headY-4],[8,headY-10],[7,headY-2]],C.magicDark);}
    return;
  }
  if(['mage','archer','rogue'].includes(classId)){
    const colors=armorPalette(classId,armor);
    const pts=classId==='mage'?[[-6,headY+5],[-6,headY-3],[-1,headY-10],[5,headY-4],[7,headY+5]]:classId==='rogue'?[[-6,headY+5],[-5,headY-4],[0,headY-8],[5,headY-4],[6,headY+5]]:[[-5,headY+5],[-6,headY-2],[-2,headY-6],[5,headY-4],[7,headY+4]];
    outlined(ctx,pts,colors[1]);line(ctx,-4,headY-2,-1,headY-5,colors[0]);
    if(back){line(ctx,0,headY-5,3,headY+4,colors[0]);return;}
    r(ctx,-3,headY-2,side?7:7,7,shade);r(ctx,side?1:-2,headY-2,side?3:6,5,sk);
    r(ctx,side?3:-2,headY,1,1,blink?shade:C.ink);if(!side)r(ctx,2,headY,1,1,blink?shade:C.ink);
    if(classId==='rogue'){r(ctx,-3,headY+2,8,4,colors[0]);line(ctx,-2,headY+2,3,headY+2,colors[2]);}
    if(classId==='mage'){r(ctx,-4,headY+2,1,3,ha);r(ctx,4,headY+1,1,4,ha);}
    if(classId==='archer'){line(ctx,-4,headY-4,-6,headY-10,C.ink);line(ctx,-5,headY-5,-7,headY-9,C.cloth,2);r(ctx,-4,headY+2,1,3,ha);}
    return;
  }
  outlined(ctx,[[-5,headY-3],[-3,headY-5],[4,headY-5],[6,headY-2],[5,headY+4],[2,headY+6],[-3,headY+5]],shade);
  r(ctx,-3,headY-3,7,7,sk);r(ctx,4,headY,2,3,shade);
  if(back){r(ctx,-4,headY-4,9,8,ha);r(ctx,-3,headY+4,6,1,shade);}
  else {r(ctx,side?3:-2,headY,1,1,blink?shade:C.ink);if(!side)r(ctx,2,headY,1,1,blink?shade:C.ink);r(ctx,0,headY+4,3,1,shade);}
  if(classId==='warrior'){
    poly(ctx,[[-5,headY],[-5,headY-4],[-1,headY-7],[5,headY-5],[6,headY-1],[3,headY-2],[2,headY-4],[-1,headY-3],[-3,headY]],ha);
    r(ctx,-2,headY-5,4,1,hair===1?C.goldLight:'#7a5740');r(ctx,-4,headY+2,1,3,ha);
    if(armor===2){r(ctx,-5,headY-3,10,2,C.magicDark);r(ctx,-1,headY-4,3,3,C.magic);}
  } else {
    r(ctx,-3,headY-5,7,2,ha);r(ctx,0,headY-8,4,3,ha);r(ctx,-5,headY-1,11,2,C.redDark);r(ctx,-4,headY-1,9,1,C.red);line(ctx,-5,headY,-8,headY+4,C.redDark,2);
  }
}

function poseActor(ctx,classId,dir,state,frame,appearance){
  const {skin,hair,armor,weapon}=appearance,p=frame/8,walk=state==='walk'||state==='run',run=state==='run';
  const side=dir==='right'||dir==='left',back=dir==='up';
  const wave=walk?Math.sin(p*Math.PI*2):0,cross=walk?Math.cos(p*Math.PI*2):0,attack=state==='attack',cast=state==='cast',dead=state==='death';
  const attackP=frame/7,hit=attack?Math.sin(Math.min(1,attackP*1.4)*Math.PI):0;
  const hurt=state==='hurt',dodge=state==='dodge';
  const colors=armorPalette(classId,armor),sk=C.skin[skin],shade=C.skinShade[skin];
  ctx.save();
  if(dir==='left')ctx.scale(-1,1);
  if(dead){
    const fall=Math.min(1,frame/5);
    ctx.translate(0,-fall*14);ctx.rotate(-fall*Math.PI/2);ctx.translate(0,fall*20);
    ctx.globalAlpha=frame===7?.65:1;
  }
  if(dodge)ctx.translate(Math.round(Math.sin(p*Math.PI)*3),Math.round(Math.sin(p*Math.PI)*-2));
  const bob=walk?Math.round(Math.abs(wave)*-1):attack?Math.round(hit):0;
  ctx.translate(0,bob);
  const breath=state==='idle'?Math.round(Math.sin(p*Math.PI*2)):0;
  const recoil=hurt?Math.round(Math.sin(frame/7*Math.PI)*2):0;
  const crouch=dodge?Math.round(Math.sin(frame/7*Math.PI)*4):0;
  const headY=(classId==='knight'?-30:classId==='rogue'?-29:classId==='mage'?-30:-29)+breath+recoil+crouch;
  const hipY=classId==='mage'?-10:-11;
  // Rear layers: capes, quivers and rear arm follow the current pose.
  if(armor>0 || ['knight','mage','archer'].includes(classId)){
    const capeColor=classId==='knight'?C.redDark:classId==='mage'?colors[1]:armor===2?C.magicDark:colors[1];
    const flutter=Math.round(wave*2)+(attack?Math.round(hit*2):0);
    poly(ctx,[[-6,-23],[6,-23],[8+flutter,-3],[2+flutter,-5],[-1,-3],[-8+flutter,-4]],C.ink);
    poly(ctx,[[-5,-22],[5,-22],[6+flutter,-5],[2+flutter,-7],[-1,-5],[-6+flutter,-6]],capeColor);
    line(ctx,-4,-20,-4+flutter,-7,armor===1?C.goldDark:colors[0]);
  }
  if(classId==='archer'){
    poly(ctx,[[-6,-26],[-2,-25],[-4,-10],[-8,-11]],C.brownDark);line(ctx,-6,-25,-7,-31,C.cloth);line(ctx,-4,-24,-4,-31,C.cloth);r(ctx,-8,-31,3,2,C.light);r(ctx,-5,-31,3,2,C.light);
  }
  leg(ctx,side?-2:-4,hipY,wave,side,colors,classId==='monk',run,cross);
  leg(ctx,side?2:3,hipY,-wave,side,colors,classId==='monk',run,-cross);
  // A shield on a north-facing arm passes behind the torso and shoulder.
  if(back&&classId==='knight')shield(ctx,-9,-16+wave*3,armor);
  if(classId==='mage'){
    const hem=Math.round(wave);
    outlined(ctx,[[-5,-24],[5,-24],[8,-5],[6,-2],[2,-3],[0,-1],[-3,-3],[-8,-2],[-7,-8]],colors[0]);
    poly(ctx,[[-1,-22],[3,-22],[5,-5],[2,-4],[0,-5]],colors[1]);
    line(ctx,-5,-5,6,-5,C.gold);line(ctx,0,-21,0,-7,C.goldDark);r(ctx,-1,-18,3,2,C.gold);r(ctx,0,-17,1,1,C.magic);
    if(hem){r(ctx,-7,-4+hem,3,1,colors[2]);r(ctx,5,-4-hem,2,1,colors[2]);}
    if(walk){line(ctx,-4+Math.round(cross),-14,-5+Math.round(wave),-6,colors[1]);r(ctx,3+Math.round(cross),-8+Math.round(wave),1,2,colors[2]);}
    if(armor===1){poly(ctx,[[-6,-22],[-10,-25],[-8,-17],[-5,-19]],C.gold);poly(ctx,[[6,-22],[10,-25],[8,-17],[5,-19]],C.gold);line(ctx,-5,-19,-4,-8,C.goldLight);r(ctx,2,-12,2,2,C.goldLight);}
    if(armor===2){poly(ctx,[[-6,-23],[-10,-28],[-10,-19],[-6,-17]],C.magicDark);poly(ctx,[[6,-23],[10,-28],[10,-19],[6,-17]],C.magicDark);r(ctx,-4,-9,2,2,C.magic);r(ctx,3,-8,2,2,C.magic);line(ctx,-4,-7,4,-7,C.magicDark);}
  } else if(classId==='monk'){
    outlined(ctx,[[-7,-23],[3,-24],[7,-20],[6,-12],[3,-9],[-5,-11],[-7,-18]],colors[0]);
    poly(ctx,[[-5,-22],[-1,-22],[2,-14],[-2,-13]],C.cloth);poly(ctx,[[0,-22],[3,-23],[4,-15],[2,-14]],sk);
    r(ctx,-6,-12,12,3,C.redDark);r(ctx,-5,-12,10,1,C.red);poly(ctx,[[2,-11],[4,-11],[6+wave,-4],[3+wave,-5]],C.red);
    if(armor===1){outlined(ctx,[[-8,-23],[-4,-25],[-3,-20],[-8,-19]],C.gold);r(ctx,-1,-18,3,3,C.goldLight);poly(ctx,[[-3,-11],[-1,-11],[-4-wave,-3],[-7-wave,-4]],C.cloth);}
    if(armor===2){line(ctx,-5,-21,4,-14,C.magic,2);r(ctx,-2,-20,4,3,C.magicDark);r(ctx,-1,-19,2,1,C.magic);poly(ctx,[[5,-22],[8,-24],[10,-19],[6,-19]],C.magicDark);}
  } else if(classId==='rogue'){
    outlined(ctx,[[-5,-24],[5,-24],[6,-17],[3,-10],[-4,-11],[-6,-17]],colors[1]);
    line(ctx,-3,-22,3,-12,colors[2],2);line(ctx,3,-22,-3,-12,colors[0],2);r(ctx,-5,-12,10,2,C.brownDark);r(ctx,0,-12,2,2,C.gold);
    poly(ctx,[[-5,-11],[0,-10],[-3,-6],[-6,-7]],colors[0]);poly(ctx,[[1,-10],[5,-11],[6,-7],[3,-6]],colors[0]);
    if(armor===1){poly(ctx,[[-6,-24],[-10,-26],[-8,-19],[-5,-18]],C.goldDark);r(ctx,-7,-23,2,3,C.gold);r(ctx,3,-18,3,2,C.goldLight);}
    if(armor===2){poly(ctx,[[-5,-24],[-9,-28],[-8,-19]],C.magicDark);poly(ctx,[[5,-24],[9,-28],[8,-19]],C.magicDark);line(ctx,-3,-20,3,-14,C.magic);}
  } else if(classId==='archer'){
    outlined(ctx,[[-5,-23],[5,-23],[6,-18],[4,-11],[-4,-11],[-6,-17]],colors[0]);
    line(ctx,-4,-22,3,-13,C.brownDark,2);line(ctx,-3,-22,4,-13,C.cloth);r(ctx,-5,-12,10,2,C.brown);r(ctx,-1,-12,2,2,C.gold);r(ctx,4,-16,3,4,C.brownDark);
    if(armor===1){poly(ctx,[[-6,-24],[-10,-23],[-8,-17],[-4,-19]],C.goldDark);poly(ctx,[[-6,-23],[-8,-21],[-6,-18],[-5,-20]],C.goldLight);r(ctx,1,-17,2,3,C.goldLight);}
    if(armor===2){poly(ctx,[[-6,-23],[-10,-28],[-8,-17],[-4,-19]],C.magicDark);line(ctx,-7,-23,-7,-20,C.magic);poly(ctx,[[3,-13],[7,-14],[7,-6],[4,-8]],C.magicDark);}
  } else {
    const knight=classId==='knight',width=knight?8:7;
    outlined(ctx,[[-width,-23],[-4,-25],[4,-25],[width,-22],[width-1,-13],[4,-10],[-5,-10],[-width,-15]],colors[0]);
    poly(ctx,[[-width+2,-22],[0,-24],[0,-14],[-width+2,-15]],colors[2]);
    poly(ctx,[[1,-23],[width-2,-21],[width-2,-15],[1,-13]],colors[1]);
    line(ctx,-5,-14,5,-14,C.ink);line(ctx,-5,-16,5,-16,colors[2]);r(ctx,-5,-12,10,2,C.brownDark);r(ctx,-1,-12,3,2,C.gold);
    if(knight){poly(ctx,[[-7,-12],[0,-11],[-1,-6],[-7,-7]],colors[0]);poly(ctx,[[1,-11],[7,-12],[7,-7],[2,-6]],colors[0]);line(ctx,-6,-8,-2,-7,colors[2]);line(ctx,3,-7,6,-8,colors[2]);}
    if(armor===2){poly(ctx,[[-5,-22],[0,-20],[5,-22],[2,-17],[0,-15],[-2,-17]],C.magicDark);r(ctx,-1,-20,3,2,C.magic);}
  }
  // North-facing capes cover the breastplate. Front and back never reuse the
  // same equipment ordering; the quiver, seams and pauldrons remain readable.
  if(back&&(armor>0||['knight','mage','archer'].includes(classId))){
    const flutter=Math.round(wave*2),capeColor=classId==='knight'?C.redDark:armor===2?C.magicDark:colors[1];
    poly(ctx,[[-5,-23],[5,-23],[6+flutter,-5],[1+flutter,-3],[-1,-5],[-6+flutter,-4]],capeColor);
    line(ctx,-4,-21,-3+flutter,-6,classId==='knight'?C.red:colors[0]);line(ctx,0,-21,1+flutter,-5,colors[0]);
    if(armor===1){line(ctx,-4+flutter,-6,5+flutter,-7,C.gold);r(ctx,-1,-17,3,2,C.goldDark);}
    if(armor===2){poly(ctx,[[-2,-16],[0,-20],[3,-16],[0,-12]],C.magic);}
    if(classId==='archer'){poly(ctx,[[-5,-24],[-1,-24],[3,-10],[-2,-9]],C.brownDark);line(ctx,-3,-22,1,-11,C.brown);line(ctx,-4,-25,-6,-30,C.cloth);line(ctx,-2,-24,-3,-31,C.cloth);r(ctx,-7,-31,3,2,C.light);r(ctx,-4,-32,3,2,C.light);}
  }else if(back&&classId==='warrior'){
    line(ctx,0,-22,0,-14,colors[1]);r(ctx,-4,-20,2,1,colors[1]);r(ctx,3,-20,2,1,colors[1]);
  }
  // Articulated arms, with a distinct action silhouette for every profession.
  const armSwing=walk?wave*3:0;
  let leftHand=[-8,-14+armSwing+breath],rightHand=[8,-14-armSwing+breath];
  if(attack){
    if(classId==='archer'){leftHand=[3,-18];rightHand=[10-Math.round(hit*7),-19];}
    else if(classId==='mage'){leftHand=[-9-Math.round(hit*3),-22+Math.round(Math.cos(attackP*Math.PI)*3)];rightHand=[8+Math.round(Math.sin(attackP*Math.PI*2)*2),-17];}
    else if(classId==='monk'){leftHand=[-7+Math.round(Math.max(0,attackP-.45)*9),-18+hit*3+Math.round(Math.cos(attackP*Math.PI)*2)];rightHand=[8+hit*8,-18-hit*3];}
    else if(classId==='rogue'){leftHand=[-8+hit*7,-17];rightHand=[8+hit*6,-20+hit*5];}
    else {rightHand=[6+hit*6,-25+hit*12];leftHand=[-8,-15];}
  }
  if(cast){leftHand=[-9,-24-Math.sin(p*Math.PI)*3];rightHand=[9,-24-Math.sin(p*Math.PI)*3];}
  if(hurt){leftHand=[-9+recoil,-16+recoil];rightHand=[7-recoil,-18+recoil];}
  if(dodge){leftHand=[-9+crouch,-15+crouch];rightHand=[8-crouch,-18+crouch];}
  const arm=(isLeft,hand)=>{
    const sx=isLeft?-7:6,sy=-22,elbow=[sx+(isLeft?-2:2),(-22+hand[1])/2];
    line(ctx,sx,sy,...elbow,C.ink,4);line(ctx,elbow[0],elbow[1],hand[0],hand[1],C.ink,4);
    const material=classId==='monk'?sk:colors[0];
    line(ctx,sx+1,sy+1,elbow[0]+1,elbow[1],material,2);line(ctx,elbow[0]+1,elbow[1],hand[0]+1,hand[1]-1,classId==='monk'?C.cloth:colors[1],2);
    r(ctx,hand[0],hand[1]-1,3,3,classId==='knight'?colors[0]:sk);r(ctx,hand[0],hand[1]+1,3,1,classId==='knight'?colors[1]:shade);
    if(['warrior','knight'].includes(classId)){
      outlined(ctx,[[sx-3,-24],[sx+3,-24],[sx+4,-20],[sx-3,-19]],colors[0]);line(ctx,sx-2,-23,sx+2,-23,colors[2]);
      if(armor===1)r(ctx,sx-2,-21,4,1,C.goldLight);
      if(armor===2){poly(ctx,[[sx-2,-23],[sx-4,-28],[sx+1,-24]],colors[2]);}
    }
    if(classId==='monk'&&weapon>0){r(ctx,hand[0]-1,hand[1]-2,5,4,weapon===2?C.magicDark:C.goldDark);r(ctx,hand[0],hand[1]-2,3,1,weapon===2?C.magic:C.goldLight);}
  };
  arm(true,leftHand);
  if(back)arm(false,rightHand);
  face(ctx,classId,dir,skin,hair,headY,armor,state==='idle'&&frame===6);
  if(back){
    // Back-facing head is behind the collar; cape is visible over rear plate.
    if(classId==='knight')line(ctx,-5,-24,5,-24,C.red);
    if(classId==='mage')line(ctx,-5,-24,5,-24,C.gold);
  }
  if(!back)arm(false,rightHand);
  // Equipment lives in the same posed coordinate space as its owning hand.
  const [hx,hy]=rightHand;
  if(classId==='mage')staff(ctx,hx+1,hy,weapon,attack);
  else if(classId==='archer')bow(ctx,10,-17,weapon,attack,attackP);
  else if(classId==='monk'){
    if(attack||cast){const glow=weapon===0?C.gold:weapon===1?C.goldLight:C.magic; r(ctx,hx+4,hy-2,2,1,glow);r(ctx,hx+6,hy,3,2,glow);r(ctx,hx+5,hy+3,1,1,glow);}
  } else {
    const angle=attack?(-2.3+attackP*3.4):walk?(-1.1-wave*.15):-1.15;
    blade(ctx,hx+1,hy,angle,weapon,classId);
    if(classId==='rogue')blade(ctx,leftHand[0],leftHand[1],attack?-.6+hit*2:2.0,weapon,'rogue');
    if(classId==='knight'&&!back)shield(ctx,leftHand[0]-1,leftHand[1]-2,armor);
  }
  if(cast){
    const radius=5+Math.round(Math.sin(p*Math.PI)*3),color=classId==='mage'?C.magic:classId==='monk'?C.goldLight:C.violetLight;
    for(let i=0;i<6;i++){const a=i*Math.PI/3+p*Math.PI*2;r(ctx,Math.round(Math.cos(a)*radius),-22+Math.round(Math.sin(a)*radius),2,2,color);}
  }
  if(attack&&classId==='mage'){
    const [cx,cy]=leftHand,rad=3+Math.round(hit*2);
    for(let i=0;i<4;i++){const a=i*Math.PI/2+attackP*4; r(ctx,cx+Math.round(Math.cos(a)*rad),cy+Math.round(Math.sin(a)*rad),1,2,C.magic);}
    poly(ctx,[[cx,cy-2],[cx+2,cy],[cx,cy+3],[cx-2,cy]],frame<5?C.magicDark:C.magic);
  }
  if(hurt && frame<3){ctx.globalCompositeOperation='source-atop';r(ctx,-20,-43,40,45,'#d88b7b66');}
  ctx.restore();
}

/** Transparent four-direction sheet, with eight sampled frames for each action. */
export function buildSpriteSheet(classId='warrior',options={}){
  const appearance={skin:clampTier(options.skin),hair:clampTier(options.hair),armor:clampTier(options.armor),weapon:clampTier(options.weapon)};
  const key=JSON.stringify([classId,appearance]);
  if(cache.has(key))return cache.get(key);
  const m=SPRITE_META,sheet=canvas(m.width*m.frames,m.height*m.states.length*m.directions.length),ctx=sheet.getContext('2d');
  ctx.imageSmoothingEnabled=false;
  m.directions.forEach((direction,d)=>m.states.forEach((state,s)=>{
    for(let frame=0;frame<m.frames;frame++){
      ctx.save();ctx.translate(frame*m.width+m.anchorX,(d*m.states.length+s)*m.height+m.anchorY);poseActor(ctx,classId,direction,state,frame,appearance);ctx.restore();
    }
  }));
  // Keep previews and equipment changes bounded on mobile.
  if(cache.size>=8)cache.delete(cache.keys().next().value);
  cache.set(key,sheet);return sheet;
}
export const buildSpriteSheets=()=>Object.fromEntries(Object.keys(palettes).map(id=>[id,buildSpriteSheet(id)]));
export function drawActor(ctx,actor={},time=0){
  const m=SPRITE_META,dir=Math.max(0,m.directions.indexOf(actor.direction||'down'));
  const state=Math.max(0,m.states.indexOf(actor.state||'idle'));
  const rawPhase=Number.isFinite(actor.phase)?actor.phase:time*(actor.state==='run'?1.8:actor.state==='walk'?1.2:.7);
  const phase=actor.state==='death'?Math.min(.999,Math.max(0,rawPhase)):((rawPhase%1)+1)%1;
  const frame=Math.min(7,Math.floor(phase*m.frames));
  ctx.save();ctx.imageSmoothingEnabled=false;
  ctx.drawImage(buildSpriteSheet(actor.classId||'warrior',actor),frame*m.width,(dir*m.states.length+state)*m.height,m.width,m.height,-m.anchorX,-m.anchorY,m.width,m.height);ctx.restore();
}

/** Monsters use separate anatomy, articulated limbs and compressed/extended impact frames. */
export function drawMonster(ctx,monster={},time=0){
  const kind=monster.kind||'slime',phase=Number.isFinite(monster.phase)?monster.phase:time*1.5,p=phase*Math.PI*2;
  const walking=monster.state==='walk'||monster.state==='run',attack=monster.state==='attack',hurt=monster.state==='hurt',death=monster.state==='death';
  const wave=walking?Math.sin(p):0;
  if(kind==='boss'){
    const name=(monster.name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    const anatomy=/goblin/.test(name)?'goblin':/floresta|treant|silvestre|raiz/.test(name)?'treant':/eclipse|corromp|sombra/.test(name)?'corrupt':'slime';
    if(anatomy!=='slime'){
      ctx.save();ctx.scale(1.5,1.5);
      drawMonster(ctx,{...monster,kind:anatomy},time);
      if(death)ctx.globalAlpha=Math.max(.15,1-phase);
      const cy=anatomy==='goblin'?-30:-36;
      poly(ctx,[[-6,cy],[-7,cy-7],[-3,cy-4],[0,cy-9],[3,cy-4],[7,cy-7],[6,cy]],C.ink);
      poly(ctx,[[-5,cy-1],[-5,cy-5],[-2,cy-3],[0,cy-7],[2,cy-3],[5,cy-5],[5,cy-1]],anatomy==='corrupt'?C.violet:C.gold);
      line(ctx,-5,cy-1,5,cy-1,anatomy==='corrupt'?C.violetLight:C.goldLight);r(ctx,-1,cy-4,3,2,anatomy==='corrupt'?C.magic:C.red);
      if(anatomy==='corrupt'){
        for(const[x,y]of[[-13,-25],[13,-21],[-12,-11]])poly(ctx,[[x,y-5],[x+2,y],[x,y+4],[x-2,y]],C.violetLight);
      }
      ctx.restore();return;
    }
  }
  ctx.save();if(monster.direction==='left')ctx.scale(-1,1);
  if(death){ctx.globalAlpha=Math.max(.15,1-phase);ctx.scale(1,.3+Math.max(0,1-phase)*.7);}
  if(kind==='slime'||kind==='boss'){
    const boss=kind==='boss',s=boss?1.6:1;ctx.scale(s,s);
    const squeeze=Math.round(Math.sin(p)*(walking?2:1)),w=11+squeeze,h=12-squeeze;
    oval(ctx,0,-h+1,w,h,C.ink);oval(ctx,0,-h+1,w-1,h-1,hurt?'#d49b77':'#658f75');oval(ctx,-2,-h-1,w-4,h-4,'#96b599');
    r(ctx,-6,-h-4,4,2,'#c8dbc0');r(ctx,-5,-h-2,2,1,'#deead6');r(ctx,3,-8,2,3,C.ink);r(ctx,-4,-8,2,3,C.ink);r(ctx,0,-4,2,1,'#415c51');
    if(attack){r(ctx,-4,-7,8,1,C.ink);r(ctx,-2,-6,5,2,C.ink);}
    if(boss){poly(ctx,[[-7,-23],[-7,-29],[-3,-26],[0,-31],[3,-26],[7,-29],[7,-23]],C.goldDark);line(ctx,-6,-24,6,-24,C.goldLight);r(ctx,-1,-27,3,2,C.red);}
  } else if(kind==='wolf'){
    const stride=Math.round(wave*3);
    for(const [x,s]of[[-7,1],[7,-1]]){line(ctx,x,-7,x+s*stride,-1,C.ink,3);r(ctx,x+s*stride,-1,4,2,C.deep);}
    outlined(ctx,[[-13,-13],[-8,-18],[6,-17],[12,-11],[9,-4],[-10,-5]],'#727c80');poly(ctx,[[-11,-13],[-6,-16],[5,-15],[7,-11],[-8,-10]],'#a1aaa6');
    poly(ctx,[[-11,-13],[-18,-19],[-17,-13],[-11,-9]],'#727c80');
    outlined(ctx,[[6,-14],[8,-23],[12,-18],[16,-20],[18,-13],[21,-10],[19,-6],[11,-7]],'#87918f');r(ctx,14,-14,2,1,C.goldLight);r(ctx,19,-10,3,2,C.ink);r(ctx,16,-6,4,1,C.ink);
    if(attack){r(ctx,17,-5,5,2,C.ink);r(ctx,18,-5,1,1,C.cloth);}
  } else if(kind==='treant'||kind==='corrupt'){
    const corrupt=kind==='corrupt',wood=corrupt?'#5b5366':'#75634b',leaf=corrupt?'#9a739c':'#78875b';
    line(ctx,-5,-8,-8-wave*2,0,C.ink,5);line(ctx,4,-8,7+wave*2,0,C.ink,5);line(ctx,-5,-8,-8-wave*2,-1,wood,3);line(ctx,4,-8,7+wave*2,-1,wood,3);
    outlined(ctx,[[-8,-25],[-3,-31],[6,-27],[9,-11],[4,-5],[-6,-6],[-10,-15]],wood);line(ctx,-4,-25,-3,-9,C.brownDark);line(ctx,3,-25,4,-13,C.brownDark);
    line(ctx,-8,-22,-16,-15-wave*2,wood,4);line(ctx,8,-21,15,-12+wave*2,wood,4);line(ctx,-14,-16,-17,-22,wood,2);line(ctx,14,-14,18,-20,wood,2);
    for(const[x,y,s]of[[-8,-30,6],[0,-33,8],[8,-29,6],[-3,-26,6]]){oval(ctx,x,y,s,4,C.ink);oval(ctx,x,y-1,s-1,3,leaf);r(ctx,x-2,y-2,3,1,corrupt?'#c09dbd':'#a6b485');}
    r(ctx,-5,-21,3,2,corrupt?C.violetLight:C.goldLight);r(ctx,3,-21,3,2,corrupt?C.violetLight:C.goldLight);r(ctx,-2,-15,5,2,C.ink);
    if(corrupt){poly(ctx,[[-3,-11],[0,-21],[4,-11],[1,-6]],C.violet);r(ctx,0,-17,1,5,C.violetLight);}
  } else {
    const skeleton=kind==='skeleton',skin=skeleton?'#c3bd9e':'#89a16a',dark=skeleton?'#837f6d':'#536d47';
    leg(ctx,-4,-9,wave,false,[skin,C.brownDark,dark]);leg(ctx,3,-9,-wave,false,[skin,C.brownDark,dark]);
    outlined(ctx,[[-6,-21],[6,-21],[7,-11],[-6,-10]],skeleton?C.brownDark:'#755d43');
    if(skeleton){for(let i=0;i<3;i++)line(ctx,-4,-19+i*3,4,-19+i*3,skin);line(ctx,0,-20,0,-11,skin);}
    else{r(ctx,-5,-14,11,2,C.brownDark);r(ctx,0,-14,2,2,C.gold);}
    const arm=attack?Math.sin(p)*6:wave*2;line(ctx,-6,-20,-9,-12+arm,dark,3);line(ctx,6,-20,10,-13-arm,skin,3);
    outlined(ctx,[[-6,-25],[-4,-30],[4,-30],[7,-25],[5,-20],[-4,-20]],skin);r(ctx,-4,-25,2,2,C.ink);r(ctx,2,-25,2,2,C.ink);r(ctx,-1,-21,3,1,C.ink);
    if(skeleton){r(ctx,-1,-24,2,2,dark);r(ctx,-3,-20,7,2,skin);r(ctx,-2,-20,1,2,C.ink);r(ctx,1,-20,1,2,C.ink);}
    else{poly(ctx,[[-5,-27],[-11,-29],[-7,-23]],skin);poly(ctx,[[5,-27],[11,-29],[7,-23]],skin);r(ctx,0,-29,5,2,dark);}
    blade(ctx,11,-12-arm,attack?-.6+Math.sin(p):-.9,0,'rogue');
  }
  ctx.restore();
}

export function drawItemIcon(ctx,slot='weapon',tier=0,x=0,y=0,size=32){
  ctx.save();ctx.translate(x+size/2,y+size*.75);ctx.scale(size/32,size/32);
  if(slot==='weapon')blade(ctx,-5,2,-Math.PI/4,clampTier(tier));
  else if(slot==='shield')shield(ctx,0,-8,clampTier(tier));
  else if(slot==='armor'){
    const col=armorPalette('warrior',clampTier(tier));outlined(ctx,[[-8,-21],[-3,-23],[3,-23],[9,-20],[7,-5],[-7,-5]],col[0]);line(ctx,-5,-19,-5,-8,col[2],2);line(ctx,-5,-8,5,-8,col[1],2);r(ctx,-2,-18,5,4,tier===2?C.magic:C.gold);
  } else if(slot==='potion'){outlined(ctx,[[-3,-21],[3,-21],[3,-16],[7,-13],[7,-3],[-7,-3],[-7,-13],[-3,-16]],'#b9d1cb');r(ctx,-5,-12,11,8,C.red);r(ctx,-2,-22,5,3,C.brown);r(ctx,-4,-12,2,6,'#e6aba1');}
  else {poly(ctx,[[0,-23],[8,-13],[0,-2],[-8,-13]],C.magicDark);poly(ctx,[[0,-21],[5,-13],[0,-4],[-5,-13]],C.magic);line(ctx,0,-20,0,-7,C.shine);}
  ctx.restore();
}
