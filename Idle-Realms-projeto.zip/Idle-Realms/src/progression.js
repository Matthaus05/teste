/** Idle Realms progression, equipment and versioned local persistence.
 * No renderer or browser dependencies: this module is also exercised by node:test.
 */
export const SAVE_KEY = 'idle-realms.save';
export const BACKUP_KEY = 'idle-realms.backup';
export const SAVE_VERSION = 2;
export const OFFLINE_LIMIT = 8 * 60 * 60;

export const CLASSES = [
  { id: 'warrior', name: 'Guerreiro', description: 'Espada, força e golpes que rompem a defesa.', resource: 'Fúria', color: '#dc9a65', stats: { hp: 150, attack: 15, defense: 5, range: 48, speed: 112, interval: .88 } },
  { id: 'knight', name: 'Cavaleiro', description: 'Placas e escudo para enfrentar os maiores perigos.', resource: 'Vigor', color: '#a8c6d7', stats: { hp: 190, attack: 12, defense: 9, range: 45, speed: 98, interval: 1.02 } },
  { id: 'mage', name: 'Mago', description: 'Conjura projéteis arcanos a uma distância segura.', resource: 'Mana', color: '#bd9de9', stats: { hp: 100, attack: 20, defense: 2, range: 174, speed: 107, interval: 1.15 } },
  { id: 'archer', name: 'Arqueiro', description: 'Flechas precisas e passos ágeis entre as árvores.', resource: 'Foco', color: '#97bc79', stats: { hp: 115, attack: 14, defense: 3, range: 190, speed: 124, interval: .8 } },
  { id: 'rogue', name: 'Ladino', description: 'Adagas velozes e uma chance maior de golpes críticos.', resource: 'Energia', color: '#bb98cd', stats: { hp: 120, attack: 11, defense: 3, range: 40, speed: 137, interval: .55 } },
  { id: 'monk', name: 'Monge', description: 'Punhos, disciplina e a força espiritual da Aura.', resource: 'Aura', color: '#e3ba71', stats: { hp: 145, attack: 13, defense: 5, range: 44, speed: 120, interval: .7 } },
];

export const ITEM_TIERS = [
  { tier: 0, name: 'Viajante', rarity: 'Comum', weaponName: 'Arma de viagem', armorName: 'Traje de viagem', weaponPrice: 0, armorPrice: 0, attack: 0, defense: 0, health: 0, color: '#b6b5a3' },
  { tier: 1, name: 'Aço da Guarda', rarity: 'Raro', weaponName: 'Arma da Guarda', armorName: 'Armadura da Guarda', weaponPrice: 90, armorPrice: 75, attack: 7, defense: 4, health: 25, color: '#8bc1d8' },
  { tier: 2, name: 'Legado Dracônico', rarity: 'Épico', weaponName: 'Arma dracônica', armorName: 'Armadura dracônica', weaponPrice: 280, armorPrice: 240, attack: 19, defense: 10, health: 65, color: '#d6ab67' },
];

const routes = {
  warrior: [['Berserker', 'Berserker Ancestral'], ['Guardião', 'Colosso de Ferro'], ['Mestre de Armas', 'Mestre de Espadas', 'Espadachim Supremo']],
  knight: [['Paladino', 'Campeão da Luz'], ['Cavaleiro Negro', 'Cavaleiro do Eclipse'], ['Cavaleiro Dragão', 'Matador de Dragões']],
  mage: [['Arquimago', 'Arquimago Supremo'], ['Invocador', 'Senhor das Entidades'], ['Mago de Combate', 'Arcano de Batalha']],
  archer: [['Atirador de Elite', 'Olho do Horizonte'], ['Caçador', 'Senhor das Feras'], ['Arqueiro Arcano', 'Arqueiro Astral']],
  rogue: [['Assassino', 'Ceifador das Sombras'], ['Trapaceiro', 'Mestre das Ilusões'], ['Venomista', 'Alquimista Mortal']],
  monk: [['Discípulo da Aura', 'Punho Celestial'], ['Monge Guardião', 'Mestre do Voto'], ['Monge das Mil Mãos', 'Sábio dos Mil Punhos']],
};
// Planned route definitions are data only; no unimplemented evolution is advertised as playable.
export const EVOLUTION_ROUTES = routes;

const validClass = id => CLASSES.some(c => c.id === id);
const finite = (value, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) => typeof value === 'number' && Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
const integer = (value, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) => Math.floor(finite(value, fallback, min, max));
const safeText = (value, fallback, max = 22) => typeof value === 'string' && value.trim() ? value.trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, max) : fallback;
const validTier = tier => Number.isInteger(tier) && tier >= 0 && tier < ITEM_TIERS.length;
const CHEST_IDS = new Set(['fields:fields-chest', 'forest:forest-chest', 'crypt:crypt-cache', 'crypt:crypt-reward', 'shadow:shadow-chest']);
export const xpForLevel = level => Math.round(65 * Math.pow(Math.max(1, level), 1.45));

export function createPlayer(options = {}) {
  const player = {
    name: safeText(options.name, 'Aventureiro'),
    classId: validClass(options.classId) ? options.classId : 'warrior',
    skin: integer(options.skin, 0, 0, 2), hair: integer(options.hair, 0, 0, 2),
    armor: 0, weapon: 0, direction: 'down', state: 'idle', phase: 0,
    x: 0, y: 0, region: 'village', level: 1, xp: 0, gold: 0, materials: 0,
    hp: 1, maxHp: 1, energy: 100, potions: 5, autoHunt: false,
    inventory: { armor: [0], weapon: [0] },
    quests: { kills: {}, visits: ['village'], claimed: [], dungeonWins: 0 },
    settings: { autoPotion: true, sound: false },
    playTime: 0, openedChests: [], dungeonComplete: false, cryptDefeated: [],
  };
  player.hp = player.maxHp = getStats(player).maxHp;
  return player;
}

export function getStats(player) {
  const base = (CLASSES.find(c => c.id === player.classId) || CLASSES[0]).stats;
  const level = integer(player.level, 1, 1, 100);
  const armor = ITEM_TIERS[validTier(player.armor) ? player.armor : 0];
  const weapon = ITEM_TIERS[validTier(player.weapon) ? player.weapon : 0];
  const maxHp = base.hp + (level - 1) * 12 + armor.health;
  return {
    ...base, hp: maxHp, maxHp,
    attack: base.attack + (level - 1) * 2.5 + weapon.attack,
    defense: base.defense + (level - 1) * .75 + armor.defense,
    crit: player.classId === 'rogue' ? .22 : player.classId === 'archer' ? .16 : .1,
    critDamage: 1.75,
    dodge: player.classId === 'rogue' ? .15 : player.classId === 'monk' ? .11 : .05,
    block: player.classId === 'knight' ? .2 : 0,
    resistance: player.classId === 'mage' ? .15 : .05,
  };
}

export function grantRewards(player, rewards = {}) {
  const xp = integer(rewards.xp, 0, 0, 1e9);
  const gold = integer(rewards.gold, 0, 0, 1e9);
  const materials = integer(rewards.materials, 0, 0, 1e6);
  player.xp += xp; player.gold += gold; player.materials += materials;
  let levels = 0;
  while (player.level < 100 && player.xp >= xpForLevel(player.level)) {
    player.xp -= xpForLevel(player.level++); levels++;
  }
  if (player.level >= 100) player.xp = Math.min(player.xp, xpForLevel(100));
  player.maxHp = getStats(player).maxHp;
  if (levels) { player.hp = player.maxHp; player.energy = 100; }
  return { xp, gold, materials, levels };
}

export function equipItem(player, slot, tier) {
  if (!['armor', 'weapon'].includes(slot) || !validTier(tier)) return { ok: false, error: 'Equipamento inválido.' };
  if (!player.inventory[slot].includes(tier)) return { ok: false, error: 'Compre este equipamento no ferreiro.' };
  const oldMax = getStats(player).maxHp;
  player[slot] = tier;
  player.maxHp = getStats(player).maxHp;
  player.hp = Math.min(player.maxHp, Math.max(0, player.hp + player.maxHp - oldMax));
  return { ok: true, slot, tier };
}

export function buyItem(player, slot, tier) {
  if (!['armor', 'weapon'].includes(slot) || !validTier(tier)) return { ok: false, error: 'Equipamento inválido.' };
  if (player.inventory[slot].includes(tier)) return { ok: false, error: 'Você já possui este equipamento.' };
  const price = ITEM_TIERS[tier][`${slot}Price`];
  if (player.gold < price) return { ok: false, error: `Você precisa de ${price} moedas.` };
  player.gold -= price; player.inventory[slot].push(tier);
  return { ok: true, price, slot, tier };
}

export function buyPotion(player) {
  if (player.gold < 15) return { ok: false, error: 'Você precisa de 15 moedas.' };
  if (player.potions >= 99) return { ok: false, error: 'Sua bolsa está cheia.' };
  player.gold -= 15; player.potions++;
  return { ok: true };
}

export function usePotion(player) {
  if (player.potions <= 0 || player.hp <= 0 || player.hp >= getStats(player).maxHp) return false;
  player.potions--; player.hp = Math.min(getStats(player).maxHp, player.hp + Math.round(getStats(player).maxHp * .5));
  return true;
}

export function recordKill(player, kind) {
  if (typeof kind !== 'string' || kind.length > 40 || ['__proto__', 'constructor', 'prototype'].includes(kind)) return;
  player.quests.kills[kind] = (Object.hasOwn(player.quests.kills, kind) ? player.quests.kills[kind] : 0) + 1;
  if (kind === 'boss' && player.region === 'crypt') player.quests.dungeonWins++;
}

export function visitRegion(player, id) {
  if (!['village', 'fields', 'forest', 'crypt', 'shadow'].includes(id)) return;
  player.region = id;
  if (!player.quests.visits.includes(id)) player.quests.visits.push(id);
}

export const QUESTS = [
  { id: 'first-steps', name: 'Além dos portões', description: 'Deixe a vila e explore os Campos Dourados.', target: 1, reward: { xp: 30, gold: 35 }, progress: p => Number(p.quests.visits.includes('fields')) },
  { id: 'slime-watch', name: 'O pedido da guarda', description: 'Derrote 6 slimes que ameaçam as estradas.', target: 6, reward: { xp: 90, gold: 70 }, progress: p => p.quests.kills.slime || 0 },
  { id: 'forest-scout', name: 'Entre as folhas', description: 'Encontre o caminho para a Floresta Sussurrante.', target: 1, reward: { xp: 70, gold: 50, materials: 3 }, progress: p => Number(p.quests.visits.includes('forest')) },
  { id: 'crypt-king', name: 'O silêncio da cripta', description: 'Atravesse a Cripta dos Goblins e derrote seu guardião.', target: 1, reward: { xp: 250, gold: 180, materials: 8 }, progress: p => p.quests.dungeonWins || 0 },
];

export function questProgress(player, id) {
  const quest = QUESTS.find(q => q.id === id);
  if (!quest) return null;
  const current = Math.min(quest.target, quest.progress(player));
  return { current, target: quest.target, complete: current >= quest.target, claimed: player.quests.claimed.includes(id) };
}
export const getQuestProgress = questProgress;

export function claimQuest(player, id) {
  const quest = QUESTS.find(q => q.id === id), progress = questProgress(player, id);
  if (!quest || !progress.complete) return { ok: false, error: 'A missão ainda não foi concluída.' };
  if (progress.claimed) return { ok: false, error: 'Recompensa já recebida.' };
  player.quests.claimed.push(id);
  return { ok: true, ...grantRewards(player, quest.reward) };
}

/** Aggregate estimate, not combat-frame simulation. Never awards dungeon clears/quest kills. */
export function calculateOffline(player, seconds) {
  const elapsed = Math.floor(finite(seconds, 0, 0, OFFLINE_LIMIT));
  const eligible = player.autoHunt === true && ['fields', 'forest', 'shadow'].includes(player.region) && player.hp > 0;
  const fights = eligible ? Math.floor(elapsed / 25) : 0;
  const levelScale = player.region === 'shadow' ? 2.4 : player.region === 'forest' ? 1.6 : 1;
  return {
    seconds: elapsed, capped: seconds > OFFLINE_LIMIT, eligible, fights,
    xp: Math.floor(fights * 4 * levelScale), gold: Math.floor(fights * 3 * levelScale),
    materials: Math.floor(fights / 8),
  };
}

function persistentPlayer(player) {
  // Reconstruct from a whitelist. Entity targets, render state and monotonic cooldowns are intentionally transient.
  const p = createPlayer(player);
  p.level = integer(player.level, 1, 1, 100);
  p.xp = integer(player.xp, 0, 0, 1e9); p.gold = integer(player.gold, 0, 0, 1e12);
  p.materials = integer(player.materials, 0, 0, 1e9); p.potions = integer(player.potions, 5, 0, 99);
  p.inventory = Object.fromEntries(['armor', 'weapon'].map(slot => [slot, [...new Set([0, ...(Array.isArray(player.inventory?.[slot]) ? player.inventory[slot].filter(validTier) : [])])]]));
  p.armor = validTier(player.armor) && p.inventory.armor.includes(player.armor) ? player.armor : 0;
  p.weapon = validTier(player.weapon) && p.inventory.weapon.includes(player.weapon) ? player.weapon : 0;
  p.maxHp = getStats(p).maxHp; p.hp = finite(player.hp, p.maxHp, 0, p.maxHp);
  p.energy = finite(player.energy, 100, 0, 100);
  p.x = finite(player.x, 0, 0, 8192); p.y = finite(player.y, 0, 0, 8192);
  p.direction = ['up', 'down', 'left', 'right'].includes(player.direction) ? player.direction : 'down';
  p.region = ['village', 'fields', 'forest', 'crypt', 'shadow'].includes(player.region) ? player.region : 'village';
  p.autoHunt = player.autoHunt === true;
  p.playTime = finite(player.playTime, 0, 0, 1e10);
  p.openedChests = [...new Set(Array.isArray(player.openedChests) ? player.openedChests.filter(id => CHEST_IDS.has(id)) : [])].slice(0, 64);
  p.dungeonComplete = player.dungeonComplete === true;
  p.cryptDefeated = [...new Set(Array.isArray(player.cryptDefeated) ? player.cryptDefeated.filter(id => Number.isInteger(id) && id >= 0 && id <= 8) : [])].slice(0, 9);
  p.settings = { autoPotion: player.settings?.autoPotion !== false, sound: player.settings?.sound === true };
  p.quests = {
    kills: Object.fromEntries(Object.entries(player.quests?.kills && typeof player.quests.kills === 'object' ? player.quests.kills : {}).filter(([key]) => /^[a-z][a-z0-9-]{0,39}$/.test(key) && !['constructor', 'prototype'].includes(key)).map(([key, value]) => [key, integer(value, 0, 0, 1e9)])),
    visits: [...new Set(['village', ...(Array.isArray(player.quests?.visits) ? player.quests.visits.filter(v => ['village', 'fields', 'forest', 'crypt', 'shadow'].includes(v)) : [])])],
    claimed: [...new Set(Array.isArray(player.quests?.claimed) ? player.quests.claimed.filter(id => QUESTS.some(q => q.id === id)) : [])],
    dungeonWins: integer(player.quests?.dungeonWins, 0, 0, 1e9),
  };
  return p;
}

function decodeSave(raw) {
  if (!raw) return null;
  const envelope = JSON.parse(raw);
  if (!envelope || typeof envelope !== 'object') throw new Error('Formato de save inválido.');
  const version = envelope.version ?? 1;
  if (![1, SAVE_VERSION].includes(version)) throw new Error('Este save pertence a uma versão mais recente.');
  const source = envelope.player ?? envelope.data;
  if (!source || typeof source !== 'object' || !validClass(source.classId)) throw new Error('Dados do personagem inválidos.');
  if (typeof envelope.savedAt !== 'number' || !Number.isFinite(envelope.savedAt) || envelope.savedAt < 0) throw new Error('Data do save inválida.');
  return { player: persistentPlayer(source), savedAt: envelope.savedAt, migrated: version !== SAVE_VERSION };
}

export function saveGame(player, storage = globalThis.localStorage, now = Date.now()) {
  if (!storage) return { ok: false, error: 'Armazenamento local indisponível.' };
  if (!player || typeof player !== 'object' || !validClass(player.classId)) return { ok: false, error: 'Dados do personagem inválidos.' };
  try {
    const previous = storage.getItem(SAVE_KEY);
    // Keep the last valid snapshot if an interrupted write left corrupt primary data.
    if (previous) { try { decodeSave(previous); storage.setItem(BACKUP_KEY, previous); } catch { /* keep existing backup */ } }
    storage.setItem(SAVE_KEY, JSON.stringify({ version: SAVE_VERSION, savedAt: finite(now, Date.now()), player: persistentPlayer(player) }));
    return { ok: true };
  } catch {
    return { ok: false, error: 'Não foi possível salvar. Verifique o espaço e a permissão do navegador.' };
  }
}

export function loadGame(storage = globalThis.localStorage, now = Date.now()) {
  if (!storage) return { player: null, offline: null, error: 'Armazenamento local indisponível.' };
  let snapshot, recovered = false, lastError;
  try {
    const raw = storage.getItem(SAVE_KEY);
    if (!raw) return { player: null, offline: null };
    try { snapshot = decodeSave(raw); } catch (error) { lastError = error; }
    if (!snapshot) {
      const backup = storage.getItem(BACKUP_KEY);
      if (backup) { try { snapshot = decodeSave(backup); recovered = true; } catch { /* report the original corruption */ } }
    }
    if (!snapshot) return { player: null, offline: null, error: lastError?.message || 'Save inválido.' };
    const elapsed = Math.max(0, (finite(now, Date.now()) - snapshot.savedAt) / 1000);
    const offline = elapsed >= 60 ? calculateOffline(snapshot.player, elapsed) : null;
    const beforeOffline = offline ? persistentPlayer(snapshot.player) : null;
    if (offline) grantRewards(snapshot.player, offline);
    // Claim time is persisted immediately; clock rollback cannot move the timestamp backward.
    const saved = saveGame(snapshot.player, storage, Math.max(finite(now, Date.now()), snapshot.savedAt));
    if (!saved.ok) return { player: beforeOffline || snapshot.player, offline: null, error: `${saved.error} O progresso offline não foi aplicado.` };
    return { player: snapshot.player, offline, recovered, migrated: snapshot.migrated };
  } catch {
    return { player: null, offline: null, error: 'Não foi possível acessar o save do navegador.' };
  }
}
