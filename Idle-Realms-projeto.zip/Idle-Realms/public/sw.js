const CACHE = 'idle-realms-v1';
const CORE = [
  '/', '/index.html', '/src/main.js', '/src/style.css', '/src/world.js',
  '/src/progression.js', '/src/art/sprites.js', '/manifest.webmanifest', '/icon.svg',
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(names => Promise.all(
    names.filter(name => name.startsWith('idle-realms-') && name !== CACHE).map(name => caches.delete(name)),
  )).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const allowed = CORE.includes(url.pathname) || url.pathname.startsWith('/art/');
  if (!allowed) return;
  // Network first allows deployments to refresh code while a complete cached build
  // remains available offline. Game saves live in localStorage and are untouched.
  event.respondWith(fetch(request).then(response => {
    if (response.ok) {
      const copy = response.clone();
      event.waitUntil(caches.open(CACHE).then(cache => cache.put(request, copy)));
    }
    return response;
  }).catch(async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    if (request.mode === 'navigate') return caches.match('/index.html');
    return new Response('Recurso indisponível offline', { status: 503 });
  }));
});
