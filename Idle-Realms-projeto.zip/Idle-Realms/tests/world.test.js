import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, REGIONS, TILE, WORLD_W, WORLD_H, isBlocked, findPath } from '../src/world.js';

function pointIsClear(world, point, label) {
  assert.ok(Number.isFinite(point.x) && Number.isFinite(point.y), `${label}: finite coordinates`);
  assert.ok(point.x >= 0 && point.x < world.width && point.y >= 0 && point.y < world.height, `${label}: inside world`);
  assert.equal(isBlocked(world, point.x, point.y, 10), false, `${label}: no collision at spawn`);
}

function clearPath(world, from, to, label) {
  const path = findPath(world, from, to);
  assert.ok(Array.isArray(path), `${label}: path is an array`);
  assert.ok(path.length > 0, `${label}: destination is reachable`);
  let previous = from;
  for (const point of path) {
    pointIsClear(world, point, label);
    const distance = Math.hypot(point.x - previous.x, point.y - previous.y);
    const steps = Math.max(1, Math.ceil(distance / 4));
    for (let step = 0; step <= steps; step++) {
      const fraction = step / steps;
      assert.equal(isBlocked(world,
        previous.x + (point.x - previous.x) * fraction,
        previous.y + (point.y - previous.y) * fraction, 10), false,
      `${label}: path segment does not cross an obstacle`);
    }
    previous = point;
  }
  assert.ok(Math.hypot(previous.x - to.x, previous.y - to.y) <= TILE * 1.5,
    `${label}: path ends at destination`);
  return path;
}

for (const region of REGIONS) {
  test(`${region.id}: player, portals and enemies have reachable positions`, () => {
    const world = createWorld(region.id);
    assert.equal(world.id, region.id);
    assert.equal(world.width, TILE * WORLD_W);
    assert.equal(world.height, TILE * WORLD_H);
    pointIsClear(world, world.spawn, `${region.id} player`);
    for (const [index, portal] of world.portals.entries()) {
      pointIsClear(world, portal, `${region.id} portal ${index}`);
      clearPath(world, world.spawn, portal, `${region.id} portal ${index}`);
      assert.ok(REGIONS.some(candidate => candidate.id === portal.to), 'portal target exists');
    }
    for (const [index, spawn] of world.enemySpawns.entries()) {
      pointIsClear(world, spawn, `${region.id} enemy ${index}`);
      clearPath(world, world.spawn, spawn, `${region.id} enemy ${index}`);
    }
  });
}

test('world boundaries collide and ordinary floor is traversable', () => {
  const world = createWorld('village');
  assert.equal(isBlocked(world, -1, world.spawn.y), true);
  assert.equal(isBlocked(world, world.width + 1, world.spawn.y), true);
  assert.equal(isBlocked(world, world.spawn.x, -1), true);
  assert.equal(isBlocked(world, world.spawn.x, world.height + 1), true);
  assert.equal(isBlocked(world, world.spawn.x, world.spawn.y), false);
});

test('pathfinding routes around solid obstacles without clipping their corners', () => {
  const world = { ...createWorld('fields'), blocked: new Set() };
  for (let y = 6; y <= 15; y++) world.blocked.add(`20,${y}`);
  const from = { x: 17 * TILE + 16, y: 10 * TILE + 16 };
  const to = { x: 23 * TILE + 16, y: 10 * TILE + 16 };
  const path = clearPath(world, from, to, 'wall detour');
  assert.ok(path.some(point => point.y < 6 * TILE || point.y > 16 * TILE), 'route goes around end of wall');
  assert.equal(isBlocked(world, 20 * TILE + 16, 10 * TILE + 16), true, 'solid tile collides');
  assert.equal(isBlocked(world, 20 * TILE - 8, 10 * TILE + 16, 10), true, 'actor radius collides before center reaches wall');
  assert.equal(isBlocked(world, 20 * TILE - 12, 10 * TILE + 16, 10), false, 'space beyond actor radius stays clear');
});

test('unreachable and blocked destinations stop at reachable floor', () => {
  const world = { ...createWorld('fields'), blocked: new Set() };
  for (let y = 0; y < WORLD_H; y++) world.blocked.add(`30,${y}`);
  const from = { x: 10 * TILE + 16, y: 10 * TILE + 16 };
  const to = { x: 50 * TILE + 16, y: 10 * TILE + 16 };
  const path = findPath(world, from, to);
  assert.ok(path.length > 0, 'path returns closest reachable floor');
  assert.ok(path.every(point => point.x < 30 * TILE), 'disconnected destination never crosses solid wall');
  for (const point of path) pointIsClear(world, point, 'unreachable route');
  assert.ok(Math.hypot(path.at(-1).x - to.x, path.at(-1).y - to.y) > TILE, 'does not append unreachable exact endpoint');

  world.blocked.add('20,10');
  const blocked = { x: 20 * TILE + 16, y: 10 * TILE + 16 };
  const blockedPath = findPath(world, from, blocked);
  assert.ok(blockedPath.length > 0);
  assert.ok(blockedPath.every(point => !isBlocked(world, point.x, point.y)), 'blocked target never creates blocked waypoint');
  assert.notDeepEqual(blockedPath.at(-1), blocked);
});
