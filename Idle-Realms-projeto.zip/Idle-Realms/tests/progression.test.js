import test from 'node:test';
import assert from 'node:assert/strict';
import { CLASSES, SAVE_KEY, BACKUP_KEY, OFFLINE_LIMIT, createPlayer, getStats, grantRewards, xpForLevel, buyItem, equipItem, recordKill, visitRegion, claimQuest, questProgress, calculateOffline, saveGame, loadGame } from '../src/progression.js';

const memory = () => {
  const data = new Map();
  return { getItem: k => data.get(k) ?? null, setItem: (k, v) => data.set(k, v), removeItem: k => data.delete(k) };
};

test('six classes have distinct combat profiles and appropriate resources', () => {
  assert.equal(CLASSES.length, 6);
  assert.equal(new Set(CLASSES.map(c => JSON.stringify(c.stats))).size, 6);
  for (const c of CLASSES) {
    const p = createPlayer({ classId: c.id });
    assert.equal(p.classId, c.id); assert.equal(p.hp, c.stats.hp);
    assert.ok(getStats(p).range > 0); assert.ok(c.resource);
  }
});

test('rewards cross multiple levels, preserve XP remainder and restore health', () => {
  const p = createPlayer(); p.hp = 1;
  const rewards = grantRewards(p, { xp: xpForLevel(1) + xpForLevel(2) + 5, gold: 30 });
  assert.equal(rewards.levels, 2); assert.equal(p.level, 3); assert.equal(p.xp, 5);
  assert.equal(p.gold, 30); assert.equal(p.hp, getStats(p).maxHp);
});

test('equipment requires ownership, charges once and updates actual combat stats', () => {
  const p = createPlayer(); const starter = getStats(p);
  assert.equal(equipItem(p, 'weapon', 2).ok, false);
  assert.equal(buyItem(p, 'armor', 1).ok, false);
  p.gold = 1000;
  for (const slot of ['weapon', 'armor']) for (const tier of [1, 2]) {
    assert.equal(buyItem(p, slot, tier).ok, true);
    assert.equal(equipItem(p, slot, tier).ok, true);
    assert.equal(p[slot], tier);
  }
  assert.ok(getStats(p).attack > starter.attack);
  assert.ok(getStats(p).defense > starter.defense);
  const gold = p.gold;
  assert.equal(buyItem(p, 'weapon', 2).ok, false); assert.equal(p.gold, gold);
  assert.equal(equipItem(p, 'not-a-slot', 0).ok, false);
});

test('exploration, hunt and boss quests require real events and reward only once', () => {
  const p = createPlayer();
  assert.equal(claimQuest(p, 'first-steps').ok, false);
  visitRegion(p, 'fields'); assert.equal(claimQuest(p, 'first-steps').ok, true);
  assert.equal(claimQuest(p, 'first-steps').ok, false);
  for (let i = 0; i < 6; i++) recordKill(p, 'slime');
  assert.equal(questProgress(p, 'slime-watch').complete, true);
  visitRegion(p, 'crypt'); recordKill(p, 'boss'); assert.equal(questProgress(p, 'crypt-king').complete, true);
  recordKill(p, '__proto__'); assert.equal(Object.getPrototypeOf(p.quests.kills), Object.prototype);
});

test('offline aggregation caps eight hours and excludes village, crypt and inactive hunting', () => {
  const p = createPlayer(); p.region = 'fields'; p.autoHunt = true;
  const full = calculateOffline(p, OFFLINE_LIMIT), excessive = calculateOffline(p, OFFLINE_LIMIT * 100);
  assert.equal(excessive.seconds, OFFLINE_LIMIT); assert.equal(excessive.gold, full.gold); assert.ok(excessive.capped);
  assert.ok(full.xp > 0); assert.equal(calculateOffline(p, -1).xp, 0);
  for (const region of ['village', 'crypt']) { p.region = region; assert.equal(calculateOffline(p, 3600).xp, 0); }
  p.region = 'forest'; p.autoHunt = false; assert.equal(calculateOffline(p, 3600).xp, 0);
});

test('save/load preserves all three equipment tiers, appearance and quests without transient combat references', () => {
  const storage = memory(), p = createPlayer({ name: 'Lia', classId: 'mage', skin: 2, hair: 1 });
  p.gold = 1000; p.target = p;
  for (const slot of ['armor', 'weapon']) for (const tier of [1, 2]) buyItem(p, slot, tier);
  equipItem(p, 'armor', 2); equipItem(p, 'weapon', 1); visitRegion(p, 'forest'); recordKill(p, 'wolf');
  assert.equal(saveGame(p, storage, 1000).ok, true);
  const loaded = loadGame(storage, 1000).player;
  assert.equal(loaded.name, 'Lia'); assert.equal(loaded.classId, 'mage');
  assert.equal(loaded.skin, 2); assert.equal(loaded.hair, 1);
  assert.equal(loaded.armor, 2); assert.equal(loaded.weapon, 1);
  assert.deepEqual(loaded.inventory.armor, [0, 1, 2]); assert.equal(loaded.target, undefined);
  assert.equal(loaded.quests.kills.wolf, 1);
});

test('offline rewards are applied exactly once and future timestamps cannot generate rewards', () => {
  const storage = memory(), p = createPlayer(); p.autoHunt = true; p.region = 'fields';
  saveGame(p, storage, 0);
  const first = loadGame(storage, 3600_000);
  assert.ok(first.offline.gold > 0);
  const gold = first.player.gold;
  const second = loadGame(storage, 3600_000);
  assert.equal(second.offline, null); assert.equal(second.player.gold, gold);
  const earlier = loadGame(storage, 1000); assert.equal(earlier.offline, null);
});

test('version-one envelope migrates and corrupt primary recovers last valid backup', () => {
  const storage = memory(), p = createPlayer(); p.gold = 18;
  storage.setItem(SAVE_KEY, JSON.stringify({ version: 1, savedAt: 100, data: p }));
  assert.equal(loadGame(storage, 100).migrated, true);
  p.gold = 22; saveGame(p, storage, 200);
  storage.setItem(SAVE_KEY, '{broken');
  const result = loadGame(storage, 200);
  assert.equal(result.recovered, true); assert.equal(result.player.gold, 18);
  assert.ok(storage.getItem(BACKUP_KEY));
});

test('invalid saves and unavailable storage produce recoverable errors', () => {
  const storage = memory();
  storage.setItem(SAVE_KEY, JSON.stringify({ version: 99, player: createPlayer(), savedAt: 0 }));
  assert.equal(loadGame(storage, 0).player, null); assert.match(loadGame(storage, 0).error, /versão/);
  storage.setItem(SAVE_KEY, JSON.stringify({ version: 2, player: {}, savedAt: 0 }));
  assert.equal(loadGame(storage, 0).player, null);
  assert.equal(saveGame(createPlayer(), null).ok, false);
  assert.equal(loadGame(null).player, null);
});


test('failed offline persistence rolls rewards back instead of allowing repeated claims', () => {
  const storage = memory(), p = createPlayer(); p.autoHunt = true; p.region = 'fields';
  saveGame(p, storage, 0);
  storage.setItem = () => { throw new Error('quota'); };
  const result = loadGame(storage, 3600_000);
  assert.equal(result.player.gold, 0); assert.equal(result.offline, null);
  assert.match(result.error, /offline/);
});

test('backward local clock cannot reopen an already claimed offline interval', () => {
  const storage = memory(), p = createPlayer(); p.autoHunt = true; p.region = 'fields';
  saveGame(p, storage, 0);
  const initial = loadGame(storage, 3600_000).player.gold;
  loadGame(storage, 1000);
  const restored = loadGame(storage, 3600_000);
  assert.equal(restored.player.gold, initial); assert.equal(restored.offline, null);
});


test('opened treasure and dungeon completion survive reload and invalid chest IDs are discarded', () => {
  const storage = memory(), p = createPlayer();
  p.x = 711.5; p.y = 430.25;
  p.openedChests = ['fields:fields-chest', 'forest:forest-chest', 'crypt:crypt-cache', 'crypt:crypt-reward', 'shadow:shadow-chest', 'fields:fields-chest', 'invalid:made-up', '__proto__', null];
  p.dungeonComplete = true;
  assert.equal(saveGame(p, storage, 1000).ok, true);
  const loaded = loadGame(storage, 1000).player;
  assert.deepEqual(loaded.openedChests, ['fields:fields-chest', 'forest:forest-chest', 'crypt:crypt-cache', 'crypt:crypt-reward', 'shadow:shadow-chest']);
  assert.equal(loaded.dungeonComplete, true); assert.equal(loaded.x, 711.5); assert.equal(loaded.y, 430.25);
  assert.equal(createPlayer().dungeonComplete, false); assert.deepEqual(createPlayer().openedChests, []);
});

test('save rejects malformed imports rather than silently creating a replacement character', () => {
  const storage = memory();
  for (const data of [null, {}, { classId: 'unknown' }, 'bad-data']) assert.equal(saveGame(data, storage).ok, false);
  assert.equal(storage.getItem(SAVE_KEY), null);
});


test('a boss outside the crypt cannot complete the crypt quest', () => {
  const p = createPlayer();
  for (const region of ['fields', 'forest', 'shadow']) {
    visitRegion(p, region); recordKill(p, 'boss');
    assert.equal(p.quests.dungeonWins, 0);
    assert.equal(questProgress(p, 'crypt-king').complete, false);
  }
  assert.equal(p.quests.kills.boss, 3);
  visitRegion(p, 'crypt'); recordKill(p, 'boss');
  assert.equal(p.quests.dungeonWins, 1);
  assert.equal(questProgress(p, 'crypt-king').complete, true);
});


test('a saved crypt expedition retains defeated enemy IDs and rejects invalid entries', () => {
  const storage = memory(), p = createPlayer();
  visitRegion(p, 'crypt');
  p.cryptDefeated = [0, 2, 5, 8, 2, -1, 9, 1.5, '3', null];
  assert.equal(saveGame(p, storage, 1000).ok, true);
  const loaded = loadGame(storage, 1000).player;
  assert.deepEqual(loaded.cryptDefeated, [0, 2, 5, 8]);
  assert.equal(loaded.region, 'crypt');
  assert.deepEqual(createPlayer().cryptDefeated, []);
  p.cryptDefeated = Array.from({length: 20}, (_, index) => index);
  saveGame(p, storage, 2000);
  assert.deepEqual(loadGame(storage, 2000).player.cryptDefeated, [0, 1, 2, 3, 4, 5, 6, 7, 8]);
});
