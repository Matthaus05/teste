import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

/** Functional and raster checks against the real page and its original sprite renderer.
 * Fixture rewards/levels are explicitly injected for tests of gated content; regular
 * six-class field hunts start at level 1 with their normal starting equipment.
 */
export async function runRegression(client, root, baseURL) {
  const report = { classes: [], movement: {}, equipment: {}, guards:{},death:{}, dungeon: {}, sprites: {}, pwa: {} };
  const checkpoint = () => writeFile(path.join(root, 'artifacts/regression-report.json'),JSON.stringify(report,null,2));
  const reload = async options => {
    await client.evaluate('globalThis.__beforeTestReload = true');
    await client.send('Page.reload', options);
    await client.waitFor(`!globalThis.__beforeTestReload && document.readyState === 'complete' && !!window.__IDLE_REALMS__`);
  };
  const classes = ['warrior', 'knight', 'mage', 'archer', 'rogue', 'monk'];
  await client.send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  await client.send('Emulation.setTouchEmulationEnabled', { enabled: false });

  for (const classId of classes) {
    const result = await client.evaluate(`(() => {
      const api = window.__IDLE_REALMS__;
      const p = api.start({name:'Teste ${classId}',classId:'${classId}'});
      api.enterRegion('fields');
      p.autoHunt = true;
      api.step(120);
      const state=api.getState();
      return {classId:p.classId,kills:Object.values(p.quests.kills).reduce((a,b)=>a+b,0),gold:p.gold,level:p.level,hp:p.hp,region:p.region,position:{x:p.x,y:p.y},errors:state.errors};
    })()`);
    report.classes.push(result);
    assert(result.kills > 0, `${classId}: auto-hunt must acquire, reach and defeat a target: ${JSON.stringify(result)}`);
    assert(result.gold > 0, `${classId}: kill must grant gold`);
    assert.equal(result.errors.length, 0, `${classId}: runtime errors`);
    console.log(`class ${classId}: ${result.kills} kills, ${result.gold} gold, level ${result.level}`);
  }

  report.movement = await client.evaluate(`(async () => {
    const {createWorld,isBlocked}=await import('/src/world.js');
    const api=window.__IDLE_REALMS__;
    let p=api.start({name:'Movimento',classId:'warrior'});
    p.x=1040;p.y=944;
    const original={x:p.x,y:p.y};
    window.dispatchEvent(new KeyboardEvent('keydown',{key:'d',bubbles:true}));
    api.step(1);
    window.dispatchEvent(new KeyboardEvent('keyup',{key:'d',bubbles:true}));
    const straight=Math.hypot(p.x-original.x,p.y-original.y);
    p=api.start({name:'Diagonal',classId:'warrior'});p.x=1040;p.y=944;
    window.dispatchEvent(new KeyboardEvent('keydown',{key:'d',bubbles:true}));
    window.dispatchEvent(new KeyboardEvent('keydown',{key:'s',bubbles:true}));
    api.step(1);
    window.dispatchEvent(new KeyboardEvent('keyup',{key:'d',bubbles:true}));
    window.dispatchEvent(new KeyboardEvent('keyup',{key:'s',bubbles:true}));
    const diagonal=Math.hypot(p.x-original.x,p.y-original.y);
    p=api.start({name:'Colisão',classId:'warrior'});p.x=48;p.y=944;
    const world=createWorld('village');
    const beforeBlocked=isBlocked(world,p.x,p.y,9);
    window.dispatchEvent(new KeyboardEvent('keydown',{key:'a',bubbles:true}));
    api.step(2);
    window.dispatchEvent(new KeyboardEvent('keyup',{key:'a',bubbles:true}));
    const after={x:p.x,y:p.y,blocked:isBlocked(world,p.x,p.y,9)};
    const atStop={x:p.x,y:p.y};api.step(1);
    return {straight,diagonal,ratio:diagonal/straight,beforeBlocked,after,stopDistance:Math.hypot(p.x-atStop.x,p.y-atStop.y)};
  })()`);
  assert(report.movement.straight > 75, 'Keyboard movement must move player');
  assert(Math.abs(report.movement.ratio - 1) < .04, 'Diagonal input must be normalized');
  assert(!report.movement.beforeBlocked && !report.movement.after.blocked, 'Collision fixture must start/end on walkable ground');
  assert(report.movement.after.x >= 40 && report.movement.after.x < 48, 'Solid border must prevent crossing');
  assert(report.movement.stopDistance < 10, 'Released input must decelerate to a stop');

  await client.send('Emulation.setDeviceMetricsOverride', {width:390,height:844,deviceScaleFactor:1,mobile:true});
  await client.send('Emulation.setTouchEmulationEnabled', {enabled:true});
  const touchStart=await client.evaluate(`(() => {const p=window.__IDLE_REALMS__.start({name:'Toque',classId:'warrior'});p.x=1040;p.y=944;const r=document.querySelector('#joystick').getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,px:p.x,py:p.y};})()`);
  await client.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:touchStart.x,y:touchStart.y}]});
  await client.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:touchStart.x+29,y:touchStart.y}]});
  const touchAfter=await client.evaluate(`(() => {window.__IDLE_REALMS__.step(.9);const p=window.__IDLE_REALMS__.getState().player;return {x:p.x,y:p.y,state:p.state};})()`);
  await client.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  const touchReleased=await client.evaluate(`(() => {window.__IDLE_REALMS__.step(1);const p=window.__IDLE_REALMS__.getState().player;return {x:p.x,y:p.y,state:p.state};})()`);
  report.movement.touch={start:touchStart,after:touchAfter,released:touchReleased};
  assert(touchAfter.x-touchStart.px>50,'Mobile touch joystick must move the hero');
  assert.equal(touchReleased.state,'idle','Releasing joystick must stop the walk animation');
  await client.send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  await client.send('Emulation.setTouchEmulationEnabled',{enabled:false});

  report.guards=await client.evaluate(`(async () => {
    const {createWorld}=await import('/src/world.js');
    const api=window.__IDLE_REALMS__,p=api.start({name:'Pausa',classId:'warrior'}),w=createWorld('village');
    p.x=w.portals[0].x;p.y=w.portals[0].y;p.hp=50;p.gold=100;p.potions=5;api.step(1.1);
    document.querySelector('#pause').click();
    const select=()=>({region:p.region,x:p.x,y:p.y,hp:p.hp,gold:p.gold,potions:p.potions,autoHunt:p.autoHunt});
    const before=select();
    for(const key of ['e','q']){window.dispatchEvent(new KeyboardEvent('keydown',{key,bubbles:true}));window.dispatchEvent(new KeyboardEvent('keyup',{key,bubbles:true}));}
    for(const id of ['interact','skill-heal','auto-hunt'])document.querySelector('#'+id).click();
    api.step(3);const after=select(),paused=api.getState().paused;
    document.querySelector('#pause').click();return{before,after,paused};
  })()`);
  assert(report.guards.paused,'Pause fixture actually paused');
  assert.deepEqual(report.guards.after,report.guards.before,'Paused E/Q and interaction buttons cannot mutate position, health, potions, gold or region');

  report.death.live=await client.evaluate(`(() => {
    const api=window.__IDLE_REALMS__,p=api.start({name:'Resgate',classId:'warrior'});
    api.enterRegion('fields');p.gold=1000;p.potions=0;p.hp=1;
    const enemy=api.getState().enemies[0];p.x=enemy.x+4;p.y=enemy.y;
    const originalRandom=Math.random;Math.random=()=>.5; // Deterministic non-critical, non-dodge hit fixture.
    let elapsed=0;while(p.hp>0&&elapsed<3){api.step(.02);elapsed+=.02;}
    const hit={hp:p.hp,gold:p.gold,region:p.region,elapsed};api.step(.1);
    const deathState=p.state;api.step(2.2);
    Math.random=originalRandom;
    return{hit,deathState,rescued:{hp:p.hp,gold:p.gold,region:p.region,autoHunt:p.autoHunt}};
  })()`);
  assert.equal(report.death.live.hit.hp,0,'A real enemy hit must cause death');
  assert.equal(report.death.live.deathState,'death','Dead player enters death animation');
  assert.equal(report.death.live.rescued.region,'village','Death returns player to healer');
  assert(report.death.live.rescued.hp>0,'Rescue restores health');
  assert.equal(report.death.live.rescued.gold,Math.floor(report.death.live.hit.gold*.95),'Rescue charges exactly 5% gold');
  await client.evaluate(`(() => {const api=window.__IDLE_REALMS__,p=api.start({name:'Resgate salvo',classId:'warrior'});api.enterRegion('fields');document.querySelector('#pause').click();p.hp=0;p.gold=1000;p.autoHunt=true;api.persist();})()`);
  await reload({ignoreCache:false});
  report.death.reloaded=await client.evaluate(`(() => {const p=window.__IDLE_REALMS__.getState().player;return {hp:p.hp,gold:p.gold,region:p.region,autoHunt:p.autoHunt};})()`);
  assert.equal(report.death.reloaded.region,'village','Loading zero HP rescues player to village');
  assert.equal(report.death.reloaded.gold,950,'Saved death applies one 5% rescue charge');
  assert(report.death.reloaded.hp>0&&!report.death.reloaded.autoHunt,'Saved death restores health and stops hunt');

  report.equipment = await client.evaluate(`(async () => {
    const {grantRewards}=await import('/src/progression.js');
    const api=window.__IDLE_REALMS__, p=api.start({name:'Ayla',classId:'warrior',skin:1,hair:2});
    grantRewards(p,{gold:1500}); // Explicit shop fixture; actual earned combat gold was checked above.
    const initial=p.gold;
    api.openPanel('inventory');
    for(const tier of [1,2])for(const slot of ['armor','weapon'])document.querySelector('[data-equip="'+slot+':'+tier+'"]').click();
    const bought={armor:[...p.inventory.armor],weapon:[...p.inventory.weapon],gold:p.gold};
    const equipped=[];
    for(const tier of [0,1,2]){api.equip('armor',tier);api.equip('weapon',tier);equipped.push({tier,armor:p.armor,weapon:p.weapon});}
    document.querySelector('#close-panel').click();p.x=1111.25;p.y=944;api.persist();
    return {initial,bought,equipped,save:JSON.parse(localStorage.getItem('idle-realms.save'))};
  })()`);
  assert.deepEqual(report.equipment.bought.armor, [0,1,2]);
  assert.deepEqual(report.equipment.bought.weapon, [0,1,2]);
  assert.equal(report.equipment.bought.gold, 815, 'Shop must charge exact total price');
  assert.equal(report.equipment.save.player.armor, 2);
  assert.equal(report.equipment.save.player.weapon, 2);
  delete report.equipment.save;
  // A force reload deliberately bypasses service workers in Chromium. A normal
  // navigation is the production save/resume path and retains offline control.
  await reload({ ignoreCache: false });
  await client.waitFor(`window.__IDLE_REALMS__?.getState().player.name === 'Ayla'`);
  report.equipment.reloaded = await client.evaluate(`(() => { const p=window.__IDLE_REALMS__.getState().player;return {armor:p.armor,weapon:p.weapon,skin:p.skin,hair:p.hair,gold:p.gold,x:p.x,y:p.y}; })()`);
  assert.deepEqual(report.equipment.reloaded, { armor: 2, weapon: 2, skin: 1, hair: 2, gold: 815,x:1111.25,y:944 });
  await client.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
  await client.evaluate(`window.__IDLE_REALMS__.openPanel('inventory')`);
  await new Promise(resolve=>setTimeout(resolve,200));
  report.equipment.mobile=await client.evaluate(`(() => {const p=document.querySelector('#panel');return {viewport:innerWidth,document:document.documentElement.scrollWidth,panel:p.clientWidth,content:p.scrollWidth};})()`);
  assert(report.equipment.mobile.document<=report.equipment.mobile.viewport+1&&report.equipment.mobile.content<=report.equipment.mobile.panel+1,'Mobile inventory has no horizontal overflow');
  await client.screenshot(path.join(root,'artifacts/inventory-mobile.png'));
  await client.evaluate(`document.querySelector('#close-panel').click()`);
  await client.send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});

  report.dungeon.midSave=await client.evaluate(`(async () => {
    const {getStats}=await import('/src/progression.js');
    const api=window.__IDLE_REALMS__,p=api.start({name:'Guardião da cripta',classId:'knight'});
    p.level=8;p.inventory={armor:[0,1,2],weapon:[0,1,2]};api.equip('armor',2);api.equip('weapon',2);p.hp=getStats(p).hp;p.potions=30;
    const entered=api.enterRegion('crypt');p.autoHunt=true;api.step(20);p.autoHunt=false;
    const defeated=api.getState().enemies.filter(e=>e.hp<=0).map(e=>e.id);document.querySelector('#pause').click();api.persist();
    return{entered,defeated,position:{x:p.x,y:p.y}};
  })()`);
  assert(report.dungeon.midSave.defeated.length>0,'Mid-dungeon save includes real defeated guards');
  await reload({ignoreCache:false});
  report.dungeon.afterReload=await client.evaluate(`(() => {const s=window.__IDLE_REALMS__.getState();return {region:s.region,defeated:s.enemies.filter(e=>e.hp<=0).map(e=>e.id),position:{x:s.player.x,y:s.player.y}};})()`);
  assert.deepEqual(report.dungeon.afterReload.defeated,report.dungeon.midSave.defeated,'Crypt guards killed before save remain defeated after reload');
  assert.deepEqual(report.dungeon.afterReload.position,report.dungeon.midSave.position,'Mid-dungeon position resumes exactly');
  Object.assign(report.dungeon,await client.evaluate(`(async () => {
    const {claimQuest}=await import('/src/progression.js');
    const api=window.__IDLE_REALMS__,p=api.step(0);p.autoHunt=true;api.step(360);
    const before=p.gold;const quest=claimQuest(p,'crypt-king');
    return {kills:p.quests.kills,dungeonWins:p.quests.dungeonWins,region:p.region,gold:p.gold,rewardGold:p.gold-before,quest,remaining:api.getState().enemies.filter(e=>e.hp>0),position:{x:p.x,y:p.y},hp:p.hp};
  })()`));
  assert(report.dungeon.midSave.entered, 'Leveled dungeon fixture enters crypt');
  assert(report.dungeon.dungeonWins >= 1, `Dungeon must clear guards and boss: ${JSON.stringify(report.dungeon)}`);
  assert.equal(report.dungeon.remaining.length, 0, 'Crypt clear leaves no respawning guards');
  assert(report.dungeon.quest.ok && report.dungeon.rewardGold === 180, 'Dungeon quest delivers its one-time reward');
  console.log(`dungeon: ${report.dungeon.dungeonWins} clear, ${report.dungeon.rewardGold} quest gold`);
  await checkpoint();

  // Actual raster sheets: compare all poses, four directions, equipment independent of color labels.
  const raster = await client.evaluate(`(async () => {
    const {drawActor,buildSpriteSheet,SPRITE_META:m}=await import('/src/art/sprites.js');
    const ids=${JSON.stringify(classes)},names=['Guerreiro','Cavaleiro','Mago','Arqueiro','Ladino','Monge'];
    const hash=data=>{let h=2166136261;for(let i=0;i<data.length;i++){h^=data[i];h=Math.imul(h,16777619);}return (h>>>0).toString(16);};
    const results={},sheets={};
    for(const id of ids){
      const sheet=buildSpriteSheet(id),c=sheet.getContext('2d');results[id]={states:{},armor:[],weapon:[]};
      for(let d=0;d<m.directions.length;d++)for(let s=0;s<m.states.length;s++){
        const hashes=[];
        for(let f=0;f<m.frames;f++)hashes.push(hash(c.getImageData(f*m.width,(d*m.states.length+s)*m.height,m.width,m.height).data));
        results[id].states[m.directions[d]+':'+m.states[s]]=new Set(hashes).size;
      }
      for(const slot of ['armor','weapon'])for(let tier=0;tier<3;tier++){
        const sh=buildSpriteSheet(id,{[slot]:tier});results[id][slot].push(hash(sh.getContext('2d').getImageData(0,0,sh.width,sh.height).data));
      }
      sheets[id]=sheet.toDataURL('image/png');
    }
    const gallery=document.createElement('canvas');gallery.width=1320;gallery.height=1420;
    const g=gallery.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#101b1d';g.fillRect(0,0,gallery.width,gallery.height);
    g.fillStyle='#e4cca0';g.font='28px Georgia';g.fillText('IDLE REALMS — ATLAS DE PERSONAGENS',32,44);
    g.font='14px sans-serif';g.fillStyle='#99b3ab';g.fillText('Renderização real • seis classes • quatro direções • caminhada e ataque • três conjuntos de equipamento',32,72);
    const directions=['down','left','up','right'];
    for(let row=0;row<6;row++){
      const y=100+row*218;g.fillStyle=row%2?'#142628':'#182c2d';g.fillRect(20,y,1280,210);
      g.fillStyle='#e4cca0';g.font='17px Georgia';g.fillText(names[row],32,y+24);
      for(let tier=0;tier<3;tier++){
        const bx=148+tier*380;g.font='12px sans-serif';g.fillStyle=['#b8b7a7','#cdddc2','#dfbc7b'][tier];g.fillText(['FERRO','SOLAR','DRACÔNICO'][tier],bx+100,y+21);
        for(let d=0;d<4;d++)for(let state=0;state<2;state++){
          const x=bx+d*88+30,fy=y+(state?188:102);g.save();g.translate(x,fy);g.scale(1.9,1.9);
          drawActor(g,{classId:ids[row],armor:tier,weapon:tier,direction:directions[d],state:state?'attack':'walk',phase:state?.5:.25,skin:row%3,hair:row%3});g.restore();
        }
      }
      g.font='10px sans-serif';g.fillStyle='#7f9b91';g.fillText('CAMINHAR',32,y+100);g.fillText('ATACAR',32,y+184);
    }
    return {meta:m,results,sheets,gallery:gallery.toDataURL('image/png')};
  })()`);
  report.sprites = { meta: raster.meta, results: raster.results };
  for (const [classId, data] of Object.entries(raster.results)) {
    for (const [action, unique] of Object.entries(data.states)) assert(unique >= 2, `${classId} ${action} requires distinct rendered poses`);
    assert.equal(new Set(data.armor).size, 3, `${classId} three armor rasters differ`);
    assert.equal(new Set(data.weapon).size, 3, `${classId} three weapon rasters differ`);
  }
  await mkdir(path.join(root, 'artifacts/sprites'), { recursive: true });
  await writeFile(path.join(root,'artifacts/equipment-gallery.png'),Buffer.from(raster.gallery.split(',')[1],'base64'));
  for(const [id,url] of Object.entries(raster.sheets))await writeFile(path.join(root,'artifacts/sprites',id+'.png'),Buffer.from(url.split(',')[1],'base64'));
  await checkpoint();

  // Return to actual gameplay and capture fields, then verify an installed SW serves the app offline.
  await client.evaluate(`(async () => {
    const {grantRewards}=await import('/src/progression.js');
    const api=window.__IDLE_REALMS__,p=api.start({name:'Ayla',classId:'warrior'});
    grantRewards(p,{xp:1000,gold:500});p.inventory={armor:[0,1,2],weapon:[0,1,2]};api.equip('armor',1);api.equip('weapon',1);api.enterRegion('fields');p.autoHunt=true;api.step(8);api.persist();
  })()`);
  await new Promise(resolve => setTimeout(resolve, 600));
  await client.screenshot(path.join(root,'artifacts/combat-desktop.png'));
  report.pwa.before=await client.evaluate(`(async () => ({controller:!!navigator.serviceWorker.controller,secure:isSecureContext,registrations:(await navigator.serviceWorker.getRegistrations()).map(r=>({active:r.active?.state,waiting:r.waiting?.state,installing:r.installing?.state}))}))()`);
  await checkpoint();
  await client.waitFor(`!!navigator.serviceWorker.controller`,20000);
  Object.assign(report.pwa,await client.evaluate(`(async () => { const keys=await caches.keys(),cache=await caches.open(keys.find(k=>k.startsWith('idle-realms-')));return {controller:!!navigator.serviceWorker.controller,cache:keys,resources:(await cache.keys()).map(r=>new URL(r.url).pathname)}; })()`));
  assert(report.pwa.resources.includes('/src/main.js'), 'SW caches actual game entry');
  await client.send('Network.enable');
  await client.send('Network.emulateNetworkConditions',{offline:true,latency:0,downloadThroughput:-1,uploadThroughput:-1});
  await reload({ignoreCache:false});
  report.pwa.offlineBoot = await client.evaluate(`({name:window.__IDLE_REALMS__.getState().player.name,canvas:document.querySelector('#game').width,controller:!!navigator.serviceWorker.controller})`);
  assert.equal(report.pwa.offlineBoot.name,'Ayla');
  assert(report.pwa.offlineBoot.canvas > 300, 'Cached game boots while network offline');
  await client.send('Network.emulateNetworkConditions',{offline:false,latency:0,downloadThroughput:-1,uploadThroughput:-1});
  await writeFile(path.join(root, 'artifacts/regression-report.json'),JSON.stringify(report,null,2));
  return report;
}
