import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Script } from 'node:vm';

// Build a browser-openable file with no server, remote assets or module fetches.
// Source modules remain untouched; each module gets its own lexical scope.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const moduleFiles = {
  progression: 'src/progression.js',
  world: 'src/world.js',
  sprites: 'src/art/sprites.js',
};
const moduleNames = {
  './progression.js': 'progression',
  './world.js': 'world',
  './art/sprites.js': 'sprites',
};
const bundled = [];
for (const [name, filename] of Object.entries(moduleFiles)) {
  let source = await readFile(path.join(root, filename), 'utf8');
  const exports = [];
  source = source.replace(/^export\s+(const|let|function|class)\s+([\w$]+)/gm, (_, kind, identifier) => {
    exports.push(identifier);
    return `${kind} ${identifier}`;
  });
  if (!exports.length || /^\s*(?:import|export)\s/m.test(source)) throw new Error(`Unsupported module syntax: ${filename}`);
  bundled.push(`const __portable_${name} = (() => {\n${source}\nreturn {${exports.join(',')}};\n})();`);
}
let main = await readFile(path.join(root, 'src/main.js'), 'utf8');
main = main.replace(/^import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"];?\s*$/gm, (_, names, filename) => {
  const moduleName = moduleNames[filename];
  if (!moduleName) throw new Error(`Unknown module: ${filename}`);
  return `const {${names}} = __portable_${moduleName};`;
});
if (/^\s*(?:import|export)\s/m.test(main)) throw new Error('Unsupported main module syntax');
// The portable document contains every resource. It never registers a worker,
// whether opened as a local file or delivered as a standalone HTML download.
main = main.replace("if('serviceWorker'in navigator)", 'if(false)');
const js = `(() => {\n'use strict';\n${bundled.join('\n')}\n${main}\n})();`.replace(/<\/script/gi, '<\\/script');
new Script(js, { filename: 'Idle-Realms.bundle.js' });
const css = (await readFile(path.join(root, 'src/style.css'), 'utf8')).replace(/<\/style/gi, '<\\/style');
const icon = Buffer.from(await readFile(path.join(root, 'public/icon.svg'))).toString('base64');
let html = await readFile(path.join(root, 'index.html'), 'utf8');
html = html.replace(/<link\b[^>]*\brel="(?:stylesheet|manifest|icon)"[^>]*>\s*/g, '');
html = html.replace('</head>', () => `<link rel="icon" href="data:image/svg+xml;base64,${icon}">\n<style>${css}</style>\n</head>`);
html = html.replace(/<script\s+type="module"\s+src="\/src\/main\.js"><\/script>/, () => `<script>\n${js}\n</script>`);
if (/\b(?:src|href)="\/(?!\/)/.test(html)) throw new Error('Portable HTML still references a server resource');
const output = path.join(root, 'Idle-Realms.html');
await writeFile(output, html);
console.log(`Portable game built: ${output} (${Buffer.byteLength(html)} bytes)`);
