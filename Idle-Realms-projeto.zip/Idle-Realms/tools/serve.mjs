import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { stat, readFile } from 'node:fs/promises';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const argv = process.argv.slice(2);
const value = (name, fallback) => {
  const index = argv.indexOf(name);
  return index < 0 ? fallback : argv[index + 1];
};
const host = value('--host', process.env.HOST || '0.0.0.0');
const port = Number(value('--port', process.env.PORT || '3000'));
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid port');
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.wav': 'audio/wav', '.ogg': 'audio/ogg',
};
const inside = (base, target) => target === base || target.startsWith(base + path.sep);

const server = http.createServer(async (request, response) => {
  try {
    if (!['GET', 'HEAD'].includes(request.method)) {
      response.writeHead(405, { Allow: 'GET, HEAD' }); response.end(); return;
    }
    let pathname;
    try { pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname); }
    catch { response.writeHead(400); response.end('Bad request'); return; }
    if (pathname.includes('\0') || pathname.includes('\\')) {
      response.writeHead(400); response.end('Bad request'); return;
    }
    const source = pathname.startsWith('/src/');
    const base = source ? path.join(ROOT, 'src') : path.join(ROOT, 'public');
    let filename;
    if (pathname === '/' || pathname === '/index.html') filename = path.join(ROOT, 'index.html');
    else {
      filename = path.resolve(base, '.' + (source ? pathname.slice(4) : pathname));
      if (!inside(base, filename)) {
        response.writeHead(403); response.end('Forbidden'); return;
      }
    }
    if (pathname.split('/').some(part => part.startsWith('.'))) {
      response.writeHead(403); response.end('Forbidden'); return;
    }
    const info = await stat(filename);
    if (!info.isFile()) throw Object.assign(new Error('Not found'), { code: 'ENOENT' });
    const data = request.method === 'HEAD' ? null : await readFile(filename);
    response.writeHead(200, {
      'Content-Type': TYPES[path.extname(filename)] || 'application/octet-stream',
      'Content-Length': info.size,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      ...(pathname === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {}),
    });
    response.end(data);
  } catch (error) {
    const missing = error.code === 'ENOENT' || error.code === 'ENOTDIR';
    response.writeHead(missing ? 404 : 500, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end(missing ? 'Not found' : 'Internal server error');
    if (!missing) console.error(error.message);
  }
});
server.listen(port, host, () => console.log(`Idle Realms: port ${port} (${host})`));
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
