import { spawn } from 'node:child_process';
import { mkdir, writeFile, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
import { runRegression } from './browser-regression.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

export class CDP {
  constructor(socket) {
    this.socket = socket;
    this.sequence = 0;
    this.pending = new Map();
    this.listeners = new Map();
    socket.addEventListener('message', event => {
      const packet = JSON.parse(event.data);
      if (packet.id) {
        const pending = this.pending.get(packet.id);
        if (!pending) return;
        this.pending.delete(packet.id);
        clearTimeout(pending.timer);
        if (packet.error) pending.reject(new Error(JSON.stringify(packet.error)));
        else pending.resolve(packet.result);
      } else {
        for (const callback of this.listeners.get(packet.method) || []) callback(packet.params);
      }
    });
    socket.addEventListener('close', () => {
      for (const pending of this.pending.values()) {
        clearTimeout(pending.timer); pending.reject(new Error('Browser connection closed'));
      }
      this.pending.clear();
    });
  }
  static async connect(url) {
    const socket = new WebSocket(url);
    await new Promise((resolve, reject) => {
      socket.addEventListener('open', resolve, { once: true });
      socket.addEventListener('error', reject, { once: true });
    });
    return new CDP(socket);
  }
  send(method, params = {}) {
    const id = ++this.sequence;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id); reject(new Error(`CDP timeout: ${method}`));
      }, 20000);
      this.pending.set(id, { resolve, reject, timer });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }
  on(method, callback) {
    if (!this.listeners.has(method)) this.listeners.set(method, []);
    this.listeners.get(method).push(callback);
  }
  async evaluate(expression) {
    const result = await this.send('Runtime.evaluate', {
      expression, returnByValue: true, awaitPromise: true, userGesture: true,
    });
    if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
    return result.result.value;
  }
  async waitFor(expression, timeout = 15000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      if (await this.evaluate(expression)) return;
      await sleep(100);
    }
    throw new Error(`Browser condition timed out: ${expression}`);
  }
  async screenshot(filename) {
    const { data } = await this.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
    await mkdir(path.dirname(filename), { recursive: true });
    await writeFile(filename, Buffer.from(data, 'base64'));
  }
  close() { this.socket.close(); }
}

export async function launchBrowser({ port = 9222, width = 1440, height = 1000 } = {}) {
  const userData = await mkdtemp(path.join(tmpdir(), 'idle-realms-chromium-'));
  const log = [];
  const process = spawn('/usr/bin/chromium', [
    '--headless=new', '--no-sandbox', '--disable-dev-shm-usage',
    '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${port}`, `--user-data-dir=${userData}`,
    `--window-size=${width},${height}`, 'about:blank',
  ], { stdio: ['ignore', 'pipe', 'pipe'] });
  process.stderr.on('data', chunk => log.push(chunk.toString()));
  process.stdout.on('data', chunk => log.push(chunk.toString()));
  let tabs;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (process.exitCode !== null) throw new Error(`Chromium exited: ${log.join('').slice(-3000)}`);
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json`);
      tabs = await response.json();
      if (tabs.some(tab => tab.type === 'page')) break;
    } catch { /* Chromium is still starting. */ }
    await sleep(100);
  }
  if (!tabs) { process.kill(); throw new Error(`Chromium did not start: ${log.join('').slice(-3000)}`); }
  const page = tabs.find(tab => tab.type === 'page');
  const client = await CDP.connect(page.webSocketDebuggerUrl);
  return {
    client,
    async close() {
      try { await client.send('Browser.close'); } catch { /* Browser may close first. */ }
      client.close(); process.kill();
      await sleep(100);
      await rm(userData, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
    },
  };
}

export async function openPage(client, url, { mobile = false, width = 1440, height = 1000 } = {}) {
  await client.send('Page.enable');
  await client.send('Runtime.enable');
  await client.send('Emulation.setDeviceMetricsOverride', {
    width, height, deviceScaleFactor: 1, mobile,
  });
  if (mobile) await client.send('Emulation.setTouchEmulationEnabled', { enabled: true });
  await client.send('Page.navigate', { url });
  await client.waitFor(`document.readyState === 'complete' && !!document.querySelector('#game')`);
}

async function smoke() {
  const baseURL = process.env.GAME_URL || 'http://127.0.0.1:3000';
  const response = await fetch(baseURL);
  assert.equal(response.status, 200, 'Development server must be running');
  const browser = await launchBrowser();
  const client = browser.client;
  const errors = [];
  client.on('Runtime.exceptionThrown', event => errors.push(event.exceptionDetails.exception?.description || event.exceptionDetails.text));
  try {
    await openPage(client, baseURL);
    await client.waitFor(`typeof window.__IDLE_REALMS__ !== 'undefined'`);
    await client.screenshot(path.join(ROOT, 'artifacts/character-creator.png'));
    await client.send('Emulation.setDeviceMetricsOverride', {width:390,height:844,deviceScaleFactor:1,mobile:true});
    await sleep(200);
    const creatorLayout=await client.evaluate(`(() => {const d=document.querySelector('#creator');return {viewport:innerWidth,document:document.documentElement.scrollWidth,dialog:d.clientWidth,content:d.scrollWidth};})()`);
    assert(creatorLayout.document<=creatorLayout.viewport+1 && creatorLayout.content<=creatorLayout.dialog+1,'Mobile character creator has no horizontal overflow');
    await client.screenshot(path.join(ROOT, 'artifacts/character-creator-mobile.png'));
    await client.send('Emulation.setDeviceMetricsOverride', {width:1440,height:1000,deviceScaleFactor:1,mobile:false});
    await client.evaluate(`(() => {
      const creator = document.querySelector('#creator');
      if (creator && (creator.open || getComputedStyle(creator).display !== 'none')) {
        document.querySelector('#hero-name').value = 'Ayla';
        document.querySelector('[data-class="warrior"]').click();
        document.querySelector('#create-form').requestSubmit();
      }
    })()`);
    await client.waitFor(`!!window.__IDLE_REALMS__.getState().player`);
    await sleep(700);
    const state = await client.evaluate(`window.__IDLE_REALMS__.getState()`);
    assert.equal(state.player.name, 'Ayla');
    assert.equal(state.player.classId, 'warrior');
    const canvas = await client.evaluate(`(() => {
      const canvas = document.querySelector('#game');
      const ctx = canvas.getContext('2d');
      const pixels = ctx.getImageData(0,0,canvas.width,canvas.height).data;
      const colors = new Set();
      for(let i=0;i<pixels.length;i+=200) colors.add(pixels.slice(i,i+3).join(','));
      return { width:canvas.width,height:canvas.height,colors:colors.size };
    })()`);
    assert(canvas.width >= 300 && canvas.height >= 300, 'Canvas has usable dimensions');
    assert(canvas.colors > 30, 'Gameplay canvas contains rendered scene details');
    await client.screenshot(path.join(ROOT, 'artifacts/gameplay-desktop.png'));
    await client.send('Emulation.setDeviceMetricsOverride', {
      width: 390, height: 844, deviceScaleFactor: 1, mobile: true,
    });
    await client.send('Emulation.setTouchEmulationEnabled', { enabled: true });
    await sleep(500);
    const layout = await client.evaluate(`({width:innerWidth,scroll:document.documentElement.scrollWidth,height:innerHeight})`);
    assert(layout.scroll <= layout.width + 1, 'Mobile layout has no horizontal overflow');
    await client.screenshot(path.join(ROOT, 'artifacts/gameplay-mobile.png'));
    assert.equal(errors.length, 0, `Browser exceptions: ${errors.join('\n')}`);
    const report = { passed: true, player: state.player.name, canvas, mobile: layout, creatorMobile:creatorLayout, exceptions: errors };
    await writeFile(path.join(ROOT, 'artifacts/browser-report.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify(report, null, 2));
    const regression = await runRegression(client, ROOT, baseURL);
    assert.equal(errors.length, 0, `Browser exceptions in regression: ${errors.join('\n')}`);
    console.log(JSON.stringify({ regression: 'passed', classes: regression.classes, movement: regression.movement, dungeonWins: regression.dungeon.dungeonWins, offlineBoot: regression.pwa.offlineBoot }, null, 2));
  } finally { await browser.close(); }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  smoke().catch(error => { console.error(error); process.exitCode = 1; });
}
