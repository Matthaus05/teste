/** Optional offline artwork export. Runtime drawing needs only the browser Canvas API.
 * Run: node tools/generate-sprites.mjs
 * Uses the optional @napi-rs/canvas development tool. If absent, install it
 * locally with `npm install --no-save --package-lock=false @napi-rs/canvas`.
 * The exported PNG sheets are committed; this is not needed to run the game.
 */
import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const { createCanvas } = require('@napi-rs/canvas');
globalThis.OffscreenCanvas = class { constructor(w,h){ return createCanvas(w,h); } };
const { buildSpriteSheet, drawActor, drawMonster, SPRITE_META } = await import('../src/art/sprites.js');
const output = fileURLToPath(new URL('../public/art/', import.meta.url));
await mkdir(output,{recursive:true});
const classes=['warrior','knight','mage','archer','rogue','monk'];
for(const classId of classes){
  for(let tier=0;tier<3;tier++){
    const sheet=buildSpriteSheet(classId,{armor:tier,weapon:tier});
    await writeFile(`${output}${classId}-${tier}.png`,sheet.toBuffer('image/png'));
  }
}
await writeFile(`${output}sprite-meta.json`,JSON.stringify({
  ...SPRITE_META,
  rowFormula:'directionIndex * states.length + stateIndex',
  columnFormula:'floor(normalizedPhase * frames)',
  license:'Original artwork for Idle Realms. CC0-1.0.',
  classes,
  variants:[0,1,2],
},null,2)+'\n');
// The atlas is a real raster capture of different walk and attack poses and gear.
const atlas=createCanvas(960,570),ctx=atlas.getContext('2d');
ctx.fillStyle='#142322';ctx.fillRect(0,0,960,570);ctx.imageSmoothingEnabled=false;
ctx.font='16px monospace';ctx.fillStyle='#dec896';ctx.fillText('IDLE REALMS / ORIGINAL CHARACTER SHEETS',24,28);
classes.forEach((classId,row)=>{
  ctx.fillStyle='#c6d0b8';ctx.fillText(classId.toUpperCase(),15,70+row*82);
  for(let col=0;col<9;col++){
    const tier=Math.floor(col/3),state=['idle','walk','attack'][col%3];
    ctx.save();ctx.translate(190+col*86,106+row*82);ctx.scale(2,2);
    drawActor(ctx,{classId,armor:tier,weapon:tier,state,phase:state==='walk'?.25:.4,direction:'down'},0);ctx.restore();
  }
});
await writeFile(`${output}character-atlas.png`,atlas.toBuffer('image/png'));
const directions=createCanvas(920,570),dc=directions.getContext('2d');
dc.fillStyle='#142322';dc.fillRect(0,0,920,570);dc.imageSmoothingEnabled=false;dc.font='16px monospace';
dc.fillStyle='#dec896';dc.fillText('IDLE REALMS / FOUR DIRECTIONS / WALK FRAME 1',24,28);
['down','up','left','right'].forEach((dir,col)=>dc.fillText(dir.toUpperCase(),190+col*180,55));
classes.forEach((classId,row)=>{
  dc.fillStyle='#c6d0b8';dc.fillText(classId.toUpperCase(),15,90+row*78);
  ['down','up','left','right'].forEach((direction,col)=>{
    dc.save();dc.translate(220+col*180,125+row*78);dc.scale(2,2);
    drawActor(dc,{classId,state:'walk',phase:.125,direction});dc.restore();
  });
});
await writeFile(`${output}directional-atlas.png`,directions.toBuffer('image/png'));
const bosses=createCanvas(760,230),bc=bosses.getContext('2d');
bc.fillStyle='#142322';bc.fillRect(0,0,760,230);bc.imageSmoothingEnabled=false;bc.font='14px monospace';bc.fillStyle='#dec896';bc.fillText('IDLE REALMS / ORIGINAL REGIONAL BOSSES',20,24);
['Rei Slime','Guardião da Floresta','Rei Goblin','Arauto do Eclipse'].forEach((name,i)=>{
  bc.fillStyle='#c6d0b8';bc.fillText(name,18+i*188,210);
  bc.save();bc.translate(90+i*188,180);bc.scale(2,2);drawMonster(bc,{kind:'boss',name,state:'idle',phase:.25});bc.restore();
});
await writeFile(`${output}boss-atlas.png`,bosses.toBuffer('image/png'));
console.log(`Exported 18 complete character sheets plus character, directional and boss atlases to ${output}`);
